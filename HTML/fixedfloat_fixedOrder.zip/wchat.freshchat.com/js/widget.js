! function() {
    var e = {
            75749: function(e, t) {
                t.config = {
                    type: "production",
                    cdn: {
                        enabled: {
                            forAssets: !1,
                            forApi: !1
                        },
                        assets: "assetscdn-",
                        api: "apicdn-",
                        domain: {
                            production: "wchat.freshchat.com"
                        },
                        subDomain: "",
                        protocol: {
                            production: "https://"
                        }
                    }
                }
            }
        },
        t = {};

    function n(i) {
        var o = t[i];
        if (void 0 !== o) return o.exports;
        var a = t[i] = {
            exports: {}
        };
        return e[i](a, a.exports, n), a.exports
    }! function() {
        "use strict";
        var e = {
            SAMPLE_TOKEN: "WEB_CHAT_TOKEN",
            frameDivId: "fc_frame",
            frameId: "fc_widget",
            pushFrameDivId: "fc_push_frame",
            pushFrameId: "fc_push",
            modalDivId: "fc_web_modal",
            classes: {
                fullscreenClass: "fc-widget-fullscreen"
            },
            AJAX_URL: {
                canary: "/app/services/app/webchat/{token}/canary"
            },
            canaryRoutes: {
                feature: "canary",
                rts: "rtscanary"
            },
            config: {
                model: "config",
                url: "/app/services/app/webchat/{token}/config?domain={domainName}"
            },
            impostor: {
                getFreshChatConfigs: "get_freshchat_configs",
                activityEvents: ["click", "dblclick", "mousemove", "mouseover", "mousewheel", "mouseout", "contextmenu", "mousedown", "mouseup", "touchstart", "touchmove", "touchend", "touchcancel", "keydown", "keypress", "keyup", "focus", "blur", "change", "submit", "scroll", "resize"],
                timeoutForFetchingConfigInMillis: 3e3,
                tagName: "freshchat-widget"
            }
        };
        var t = function() {
            ! function(e, t) {
                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
            }(this, undefined);
            var e = !1,
                t = !1,
                n = !1,
                i = !1,
                o = [],
                a = {};
            return {
                isLoaded: function() {
                    return e
                },
                loaded: function(t) {
                    e = t
                },
                isInitialized: function() {
                    return t
                },
                initialized: function(e) {
                    t = e
                },
                isOpened: function() {
                    return n
                },
                opened: function(e) {
                    n = e
                },
                doOpen: function() {
                    return i
                },
                openOnLoad: function(e) {
                    i = e
                },
                getTags: function() {
                    return o
                },
                setTags: function(e) {
                    o = e
                },
                getFaqTags: function() {
                    return a
                },
                setFaqTags: function(e) {
                    a = e
                },
                reset: function() {
                    e = !1, t = !1, n = !1, i = !1, o = [], a = {}
                }
            }
        }.bind(void 0)();

        function i(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }
        var o, a, s, r, d, c, u, l, f, h = function() {
                i(this, undefined);
                var e = null,
                    t = null,
                    n = null,
                    o = null,
                    a = null,
                    s = !1,
                    r = null,
                    d = {},
                    c = {},
                    u = {},
                    l = ["firstName", "lastName", "email", "phone", "phoneCountry", "locale"];
                return {
                    getIntegrations: function() {
                        return d
                    },
                    getcampaignRuleIds: function() {
                        return r
                    },
                    setcampaignRuleIds: function(e) {
                        r = e
                    },
                    setIntegrations: function(e) {
                        d = e
                    },
                    getFlowId: function() {
                        return n
                    },
                    setFlowId: function(e) {
                        n = e
                    },
                    getFlowVersionId: function() {
                        return o
                    },
                    setFlowVersionId: function(e) {
                        o = e
                    },
                    getPreviewMode: function() {
                        return a
                    },
                    setPreviewMode: function(e) {
                        a = e
                    },
                    getExternalId: function() {
                        return e
                    },
                    setExternalId: function(t) {
                        e = t
                    },
                    getRestoreId: function() {
                        return t
                    },
                    setRestoreId: function(e) {
                        t = e
                    },
                    setIdentifyByReferenceId: function(e) {
                        s = e
                    },
                    getIdentifyByReferenceId: function() {
                        return s
                    },
                    getConfig: function() {
                        return c
                    },
                    setConfig: function(e) {
                        c = e
                    },
                    getProperties: function() {
                        return u
                    },
                    setProperties: function(e) {
                        var t = this;
                        e && (l.forEach(function(n) {
                            i(this, t), e[n] && (u[n] = e[n])
                        }.bind(this)), e.meta && this.setUserMeta(e.meta))
                    },
                    setFirstName: function(e) {
                        u.firstName = e
                    },
                    setLastName: function(e) {
                        u.lastName = e
                    },
                    setEmail: function(e) {
                        u.email = e
                    },
                    setPhone: function(e) {
                        u.phone = e
                    },
                    setPhoneCountry: function(e) {
                        u.phoneCountry = e
                    },
                    setUserMeta: function(e) {
                        if (u.meta = u.meta || {}, e)
                            for (var t in e) e.hasOwnProperty(t) && (u.meta[t] = e[t])
                    },
                    setLocale: function(e) {
                        u.locale = e
                    },
                    reset: function() {
                        e = null, t = null, c = {}, u = {}
                    },
                    getJSON: function() {
                        return {
                            externalId: e,
                            restoreId: t,
                            customConfig: c,
                            properties: u
                        }
                    }
                }
            }.bind(void 0)(),
            p = n(75749),
            g = {
                url_domain: function(e) {
                    var t = document.createElement("a");
                    return t.href = e, t.origin
                },
                getElementStyle: function(e, t) {
                    return window.getComputedStyle(e)[t]
                },
                setAttr: function(e, t) {
                    for (var n in t) t.hasOwnProperty(n) && e.setAttribute(n, t[n]);
                    return e
                },
                remove: function(e) {
                    var t = document,
                        n = t.body,
                        i = t.getElementById(e);
                    i && (this.purge(i), n.removeChild(i))
                },
                purge: function(e) {
                    var t, n, i, o = e.attributes;
                    if (o)
                        for (t = o.length - 1; t >= 0; t -= 1) "function" == typeof e[i = o[t].name] && (e[i] = null);
                    if (o = e.childNodes)
                        for (n = o.length, t = 0; t < n; t += 1) this.purge(e.childNodes[t])
                },
                cdn_url: function() {
                    if (p && p.config) {
                        var e = p.config.type,
                            t = p.config.cdn;
                        return t.protocol[e] + (t.enabled.forAssets ? t.assets : "") + t.domain[e]
                    }
                },
                bindEvent: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                    window.addEventListener ? window.addEventListener(e, t, n) : window.attachEvent(e, t, n)
                },
                unbindEvent: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                    window.removeEventListener ? window.removeEventListener(e, t, n) : window.detachEvent(e, t, n)
                },
                parseJSON: function(e) {
                    var t;
                    if (e) {
                        try {
                            t = JSON.parse(e)
                        } catch (e) {}
                        return t
                    }
                },
                stringifyJSON: function(e) {
                    var t = null;
                    if (e) {
                        try {
                            var n = window.ItilUtil && window.ItilUtil.jsonStringifyWrapper;
                            t = n && "function" == typeof n && n(e) || JSON.stringify(e)
                        } catch (e) {}
                        return t
                    }
                },
                storageAvailable: function(e) {
                    var t;
                    try {
                        var n = "__storage_test__";
                        return (t = window.localStorage).setItem(n, n), t.removeItem(n), !0
                    } catch (e) {
                        return e instanceof DOMException && (22 === e.code || 1014 === e.code || "QuotaExceededError" === e.name || "NS_ERROR_DOM_QUOTA_REACHED" === e.name) && 0 !== t.length
                    }
                }(),
                isPushSupportedByBrowser: function() {
                    var e, t, n, i, o, a, s, r, d = !1,
                        c = !1;
                    i = window.chrome, o = window.navigator, a = o.vendor, s = o.userAgent.indexOf("OPR") > -1, r = o.userAgent.indexOf("Edge") > -1, null != i && "Google Inc." === a && !1 === s && !1 === r && (e = !!(n = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./)) && parseInt(n[2], 10)) && (d = e >= 50), navigator.userAgent.toLowerCase().indexOf("firefox") > -1 && (t = function() {
                        var e = navigator.userAgent,
                            t = e.indexOf("Firefox"),
                            n = e.substring(t + 8).split(".");
                        return !(!n || !n.length) && parseInt(n[0], 10)
                    }(), t && (c = t >= 44));
                    var u = "serviceWorker" in navigator,
                        l = function() {
                            var e = !1;
                            try {
                                ServiceWorkerRegistration && "showNotification" in ServiceWorkerRegistration.prototype && (e = !0)
                            } catch (e) {}
                            return e
                        }(),
                        f = "PushManager" in window;
                    return u && l && f && (d || c)
                },
                getAgent: (d = navigator.appVersion, c = navigator.userAgent, u = navigator.appName, l = "" + parseFloat(d), f = parseInt(d, 10), -1 !== c.indexOf("Station") && (r = "Station"), -1 !== (a = c.indexOf("Opera")) ? (u = "Opera", l = c.substring(a + 6), -1 !== (a = c.indexOf("Version")) && (l = c.substring(a + 8))) : -1 !== (a = c.indexOf("MSIE")) ? (u = "Microsoft Internet Explorer", l = c.substring(a + 5)) : -1 !== (a = c.indexOf("Edge")) ? (u = "Edge", l = c.substring(a + 5)) : -1 !== (a = c.indexOf("Trident")) ? (u = "Trident", l = c.substring(a + 8)) : -1 !== (a = c.indexOf("Chrome")) ? (u = "Chrome", l = c.substring(a + 7)) : -1 !== (a = c.indexOf("Safari")) ? (u = "Safari", l = c.substring(a + 7), -1 !== (a = c.indexOf("Version")) && (l = c.substring(a + 8))) : -1 !== (a = c.indexOf("Firefox")) ? (u = "Firefox", l = c.substring(a + 8)) : -1 === (a = c.indexOf("Mobile")) || -1 === c.indexOf("iPad") && -1 === c.indexOf("iPhone") && -1 === c.indexOf("iPod") && -1 === c.indexOf("wv") ? (o = c.lastIndexOf(" ") + 1) < (a = c.lastIndexOf("/")) && (u = c.substring(o, a), l = c.substring(a + 1), u.toLowerCase() === u.toUpperCase() && (u = navigator.appName)) : (u = "WebView", l = c.substring(a + 8)), -1 !== (s = l.indexOf(";")) && (l = l.substring(0, s)), -1 !== (s = l.indexOf(" ")) && (l = l.substring(0, s)), f = parseInt("" + l, 10), isNaN(f) && (l = "" + parseFloat(d), f = parseInt(d, 10)), {
                    name: u,
                    appName: r,
                    version: f,
                    versionx: l,
                    os: navigator.platform
                }),
                isSafariBrowser: function() {
                    return !(!this.getAgent || "Safari" !== this.getAgent.name)
                }
            };

        function m(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }
        var v = function() {
            m(this, undefined);
            var t = null,
                n = null,
                i = null,
                o = null,
                a = null,
                s = null,
                r = !1,
                d = !1,
                c = null,
                u = !1,
                l = null,
                f = null,
                p = null,
                v = null,
                w = null,
                b = ["get_user_uuid"],
                y = null;
            return {
                getHost: function() {
                    return a
                },
                getToken: function() {
                    return n
                },
                getReferrer: function() {
                    return i
                },
                getSiteId: function() {
                    return o
                },
                getSettings: function() {
                    return s
                },
                setSettings: function(e) {
                    r = !!((s = e).userAuthConfig && s.userAuthConfig.jwtAuthEnabled && s.userAuthConfig.strictModeEnabled), d = !(!s.userAuthConfig || !s.userAuthConfig.jwtAuthEnabled)
                },
                isJWTStrictMode: function() {
                    return r
                },
                isJWTEnabled: function() {
                    return d
                },
                getJWTAuthToken: function() {
                    return c
                },
                setJWTAuthToken: function(e) {
                    c = e
                },
                isLoaded: function() {
                    return u
                },
                loaded: function(e) {
                    u = e
                },
                loadingActions: function() {
                    return b
                },
                init: function(e) {
                    n = e.token, i = e.referrer, a = e.host, o = e.siteId, r = !1, d = !1, c = e.jwtAuthToken, u = !1, l = e.flowId, f = e.flowVersionId, p = e.previewMode, v = e.cspNonce, w = e.omniCookie, y = e.eagerLoad
                },
                reset: function() {
                    n = i = a = o = r = d = c = u = l = f = p = w = void 0
                },
                getJSON: function() {
                    return {
                        token: n,
                        flowId: l,
                        flowVersionId: f,
                        previewMode: p,
                        referrer: i,
                        host: a,
                        siteId: o,
                        jwtStrictMode: r,
                        jwtEnabled: d,
                        jwtAuthToken: c,
                        loaded: u,
                        omniCookie: w
                    }
                },
                load: function(e, n, i) {
                    if (g.isSafariBrowser() && v) {
                        var o = document.createElement("script");
                        o.nonce = v, o.textContent = 'window.location = "'.concat(e, '"'), t = i.contentWindow, i.contentDocument.body.appendChild(o)
                    } else t = window.open(e, n)
                },
                postMessage: function(e) {
                    t && t.postMessage(e, a)
                },
                dispatch: function(e, t) {
                    e && t && "function" == typeof e && e(t)
                },
                unload: function() {
                    this.postMessage({
                        action: "push_subscribe_destroy"
                    })
                },
                add: function() {
                    var t = document,
                        n = t.body,
                        i = t.getElementById(e.frameDivId),
                        o = t.createElement("IFRAME"),
                        a = h.getConfig(),
                        s = a && a.cssNames;
                    i && "DIV" === i.tagName || (i = t.createElement("DIV"), n.appendChild(i)), g.setAttr(i, {
                        id: e.frameDivId,
                        class: s && s.widget || ""
                    }), i.classList.add("fc_dn"), a && a.headerProperty ? ("ltr" === a.headerProperty.direction && i.classList.add("fc_l2r"), a.headerProperty.hideChatButton || i.classList.remove("fc_dn")) : i.classList.remove("fc_dn"), g.setAttr(o, {
                        id: e.frameId,
                        name: e.frameId,
                        title: "Chat",
                        frameborder: "0",
                        allowFullScreen: "true",
                        webkitallowfullscreen: "true",
                        mozallowfullscreen: "true"
                    }), i.appendChild(o);
                    var r = a && a.widgetCanary ? e.canaryRoutes.feature : "";
                    this.loadCanaryWidget(r, o)
                },
                loadRTSCanaryWidget: function(t) {
                    var i = this,
                        o = new XMLHttpRequest,
                        s = e.AJAX_URL.canary.replace("{token}", n);
                    s = a + s, o.open("GET", s, !0), o.onreadystatechange = function() {
                        if (m(this, i), 4 === o.readyState) {
                            var n = g.parseJSON(o.response),
                                a = n && n.canary_enabled ? e.canaryRoutes.rts : "";
                            this.loadCanaryWidget(a, t)
                        }
                    }.bind(this), o.send()
                },
                loadCanaryWidget: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        o = arguments.length > 1 ? arguments[1] : void 0,
                        s = "";
                    s = !p || "botflow" !== p && "autofaq" !== p ? "".concat(a, "/widget/").concat(t, "?token=").concat(n, "&referrer=").concat(i) : "".concat(a, "/widget/").concat(t, "?token=").concat(n, "&referrer=").concat(i, "&previewMode=").concat(p), y && (s += "&eagerLoad=true"), this.load(s, e.frameId, o)
                },
                remove: function(e) {
                    g.remove(e), t = null
                },
                setFrameSize: function() {
                    var t = this.getSettings(),
                        n = h.getConfig();
                    if (null === t) return "";
                    var i = t.widgetSize,
                        o = !(!n || !n.fullscreen) && n.fullscreen,
                        a = "fc-widget-normal",
                        s = document.getElementById(e.frameDivId);
                    !0 === o && s.classList.add(e.classes.fullscreenClass), i && i.length > 0 && (a = "fc-widget-" + i.toLowerCase()), s.classList.add(a)
                },
                setWidgetDisplayStyle: function() {
                    var t = document.body,
                        n = document.getElementById(e.frameDivId),
                        i = g.getElementStyle(t, "display");
                    i && -1 !== ["flex"].indexOf(i) && g.setAttr(n, {
                        style: "display: ".concat(i)
                    })
                }
            }
        }.bind(void 0)();
        var w = function() {
            ! function(e, t) {
                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
            }(this, undefined);
            var e = [],
                t = !1;
            return {
                enque: function(n) {
                    t || (void 0 === e && (e = []), e.push(n))
                },
                deque: function() {
                    if (e && e.length) return e.shift()
                },
                toggleLock: function(e) {
                    t = e
                },
                isLocked: function() {
                    return t
                },
                isEmpty: function() {
                    return !e || !e.length
                }
            }
        }.bind(void 0)();
        var b = function() {
                ! function(e, t) {
                    if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
                }(this, undefined);
                var e = {};
                return {
                    subscribe: function(n, i, o) {
                        t.isLoaded() || v.isLoaded() && -1 !== v.loadingActions().indexOf("get_user_uuid") ? (e[n + "_ack"] = o, v.postMessage({
                            action: n,
                            payload: i
                        })) : w.enque({
                            action: n,
                            payload: i,
                            handler: o
                        })
                    },
                    publish: function(t, n) {
                        v.dispatch(e[t], {
                            success: n.success,
                            status: n.status,
                            data: n.data
                        })
                    }
                }
            }.bind(void 0)(),
            y = function(e, t) {
                return new Promise((function(n, i) {
                    b.subscribe(e, t, (function(e) {
                        var t = e && e.status,
                            o = e && e.success;
                        200 === t || o ? n(e) : i(e)
                    }))
                }))
            },
            C = function(e, t, n) {
                t && "function" == typeof t && (n = t, t = null), b.subscribe(e, t, n)
            },
            k = function(e) {
                return !(!e || "function" != typeof e)
            };
        var _ = function() {
            ! function(e, t) {
                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
            }(this, undefined);
            var e = {},
                t = ["widget:opened", "widget:closed", "widget:loaded", "dialog:opened", "dialog:closed", "widget:destroyed", "frame:statechange", "user:statechange", "user:created", "user:cleared", "user:authenticated", "message:sent", "message:received", "unreadCount:notify", "push:subscribed", "readReceipts:update", "csat:received", "csat:updated", "csat:show", "anchorLink:clicked", "faq:clicked", "download:file", "rts:connected", "rts:disconnected"];
            return {
                clear: function() {
                    e = {}
                },
                valid: function(e) {
                    return !(!e || !t) && -1 !== t.indexOf(e)
                },
                subscribe: function(t, n) {
                    this.valid(t) && (void 0 === e[t] && (e[t] = []), e[t].push(n))
                },
                unsubscribe: function(t, n) {
                    if (this.valid(t)) {
                        var i, o = e && e[t];
                        if (o)
                            for (var a = 0, s = o.length; a < s; a++)
                                if (i = o[a], k(i) && (!n || i.name === n.name)) {
                                    e[t].splice(a, 1);
                                    break
                                }
                    }
                },
                publish: function(t, n, i) {
                    if (this.valid(t)) {
                        var o = e && e[t];
                        if (o)
                            for (var a = function(e) {
                                    return function() {
                                        n ? e(n) : e()
                                    }
                                }, s = 0, r = o.length; s < r; s++) {
                                var d = a(o[s]);
                                i ? setTimeout(d, 0) : d()
                            }
                        if ("function" == typeof window.CustomEvent) {
                            var c = new CustomEvent("fwcrm_event_consume", {
                                detail: {
                                    name: t,
                                    origin: window.origin,
                                    args: n
                                }
                            });
                            window.dispatchEvent(c)
                        }
                    }
                }
            }
        }.bind(void 0)();
        var E = function() {
            ! function(e, t) {
                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
            }(this, undefined);
            var t = null,
                n = null,
                i = null,
                o = !1,
                a = null,
                s = null,
                r = null;
            return {
                isLoaded: function() {
                    return o
                },
                loaded: function(e) {
                    o = e
                },
                getSource: function() {
                    return r
                },
                setSource: function(e) {
                    r = e
                },
                getHost: function() {
                    return t
                },
                getHostOrigin: function() {
                    return n
                },
                getLogoPath: function() {
                    return i
                },
                init: function(e) {
                    t = e.host, n = e.hostOrigin, i = e.appLogoPath, a = e.locale, s = e.sales360App, this.load()
                },
                reset: function() {
                    t = null, n = null, i = null, a = null, s = null, o = !1, r = null
                },
                postMessage: function(e) {
                    e.openWindow ? window.open(t + "&action=" + btoa(e.action) + "&appLogoPath=" + btoa(i) + "&locale=" + btoa(a) + "&sales360App=" + btoa(s), "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400") : o && this.post({
                        action: e.action,
                        payload: e.payload
                    })
                },
                post: function(e) {
                    r.postMessage(e, n)
                },
                add: function() {
                    var n = document,
                        i = n.body,
                        o = n.getElementById(e.pushFrameDivId),
                        a = n.createElement("IFRAME");
                    o && "DIV" === o.tagName || (o = n.createElement("DIV"), i.appendChild(o)), o.setAttribute("id", e.pushFrameDivId), g.setAttr(a, {
                        id: e.pushFrameId,
                        src: t,
                        title: "Chat",
                        frameborder: "0"
                    }), o.appendChild(a)
                },
                load: function() {
                    g.isPushSupportedByBrowser() && this.add()
                },
                unload: function() {
                    g.remove(e.pushFrameDivId), this.reset()
                }
            }
        }.bind(void 0)();
        var I = function() {
            ! function(e, t) {
                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
            }(this, undefined);
            var t = function(e) {
                27 === e.keyCode && this.destroy()
            };
            return {
                create: function(n) {
                    var i = document,
                        o = i.body,
                        a = i.createElement("DIV"),
                        s = i.createElement("IMG"),
                        r = i.createElement("DIV"),
                        d = i.createElement("DIV");
                    a.setAttribute("id", e.modalDivId), a.onclick = this.destroy, s.setAttribute("src", n), s.onclick = this.destory, d.appendChild(s), d.className = "image-cell", r.appendChild(d), r.className = "image-wrapper", a.appendChild(r), o.appendChild(a), window.addEventListener ? window.addEventListener("keydown", t.bind(this), !1) : window.attachEvent("keydown", t.bind(this), !1)
                },
                destroy: function() {
                    var n = document,
                        i = n.body,
                        o = n.getElementById(e.modalDivId);
                    o && (g.purge(o), i.removeChild(o)), window.removeEventListener ? window.removeEventListener("keydown", t.bind(this)) : window.detachEvent("keydown", t.bind(this))
                }
            }
        }.bind(void 0)();
        var x = function() {
            ! function(e, t) {
                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
            }(this, undefined);
            var e = {},
                t = "_fc_observer";
            return {
                attach: function(n, i, o) {
                    var a = "".concat(i).concat(t);
                    n[i] && o && (void 0 === n[a] || n[a] !== o) && (n[a] = o, function(n, i) {
                        e[i] = n[i], n[i] = function() {
                            var o = e[i].apply(n, arguments),
                                a = n["".concat(i).concat(t)];
                            return "function" == typeof a && a(), o
                        }
                    }(n, i))
                },
                detach: function(n, i) {
                    var o = "".concat(i).concat(t);
                    n[i] && n[o] && (n[o] = void 0, function(t, n) {
                        e[n] && (delete t[n], t[n] = e[n], delete e[n])
                    }(n, i))
                }
            }
        }.bind(void 0)();
        var L = function() {
            ! function(e, t) {
                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
            }(this, undefined);
            var e, t, n, i = function(i) {
                    e = i.oldValue, t = i.newValue, n = i.title, v.postMessage({
                        action: "track_location",
                        payload: {
                            pageUrl: i
                        }
                    })
                },
                o = function() {
                    var o = window.location.href;
                    t !== o && (e = t, t = o, n = document.title, i({
                        oldValue: e,
                        newValue: t,
                        title: n
                    }))
                };
            return {
                start: function() {
                    t = window.location.href, i({
                        newValue: t,
                        title: document.title
                    }), x.attach(window.history, "pushState", o), x.attach(window.history, "replaceState", o), window.addEventListener ? (window.addEventListener("hashchange", o, !1), window.addEventListener("popstate", o, !1)) : (window.attachEvent("hashchange", o, !1), window.attachEvent("popstate", o, !1))
                },
                stop: function() {
                    e = t = void 0, x.detach(window.history, "pushState"), x.detach(window.history, "replaceState"), window.removeEventListener ? (window.removeEventListener("hashchange", o), window.removeEventListener("popstate", o)) : (window.detachEvent("hashchange", o), window.detachEvent("popstate", o))
                },
                track: i
            }
        }.bind(void 0)();

        function S(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }
        var T = function() {
                var e = this;
                S(this, undefined);
                var t = null,
                    n = null,
                    i = null,
                    o = function() {
                        S(this, e), v.postMessage({
                            action: "track_activity",
                            payload: {
                                seen: n
                            }
                        })
                    }.bind(this),
                    a = function() {
                        S(this, e), n = (new Date).getTime()
                    }.bind(this),
                    s = function(t) {
                        S(this, e), g.unbindEvent("keypress", a), g.unbindEvent("mousemove", a), g.unbindEvent("click", a), t && (g.bindEvent("keypress", a), g.bindEvent("mousemove", a), g.bindEvent("click", a))
                    }.bind(this),
                    r = function() {
                        S(this, e);
                        var a = (new Date).getTime();
                        null === i || null === n || t && (a < t || n < t || a - t < 59e3 || n > t && n < a && o()), t = a
                    }.bind(this),
                    d = function() {
                        S(this, e), i && clearInterval(i), i = null, n = null, t = null
                    }.bind(this),
                    c = function() {
                        S(this, e), d(), s(!0), t = (new Date).getTime(), i = setInterval(r, 6e4)
                    }.bind(this),
                    u = function() {
                        S(this, e), n = (new Date).getTime(), o(), d(), s(!1)
                    }.bind(this),
                    l = function() {
                        S(this, e), "hidden" === document.visibilityState && u()
                    }.bind(this);
                return {
                    start: function() {
                        c(), g.bindEvent("focus", c), g.bindEvent("blur", u), g.bindEvent("beforeunload", u), g.bindEvent("visibilitychange", l)
                    },
                    stop: function() {
                        u(), g.unbindEvent("focus", c), g.unbindEvent("blur", u), g.unbindEvent("beforeunload", u), g.unbindEvent("visibilitychange", l)
                    }
                }
            }.bind(void 0)(),
            B = function() {
                L.start(), T.start()
            },
            O = function() {
                L.stop(), T.stop()
            };

        function P(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }
        var D = {
            start: function() {
                w.isEmpty() || w.isLocked() || (w.toggleLock(!0), this.run())
            },
            run: function() {
                var e = w.deque();
                e ? this.process(e) : w.toggleLock(!1)
            },
            process: function(e) {
                var t = this;
                e.handler ? b.subscribe(e.action, e.payload, function(n) {
                    P(this, t), "function" == typeof e.handler && e.handler(n), this.run()
                }.bind(this)) : (b.subscribe(e.action, e.payload), setTimeout(function() {
                    P(this, t), this.run()
                }.bind(this), 0))
            }
        };
        var M = function() {
                return function(e, t) {
                    if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
                }(this, undefined), {
                    init: function(e) {
                        var t = document.createElement("script"),
                            n = g.cdn_url() ? g.cdn_url() : e.host;
                        t.type = "text/javascript", t.src = n + "/js/co-browsing.js", (document.body ? document.body : document.getElementsByTagName("head")[0]).appendChild(t), window.fc_cobrowse = {
                            host: e.host,
                            locale: e.locale
                        }
                    }
                }
            }.bind(void 0)(),
            A = {
                setCookie: function(e, t, n) {
                    var i = n || 31536e6,
                        o = new Date(+new Date + i),
                        a = t || "_fw_crm_v";
                    return document.cookie = a + "=" + e + ";domain=." + location.hostname + ";path=/;expires=" + o.toUTCString() + ";SameSite=Lax;", e
                },
                removeCookie: function(e) {
                    var t = e || "_fw_crm_v";
                    document.cookie = t + "=;domain=." + location.hostname + ";path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;SameSite=Lax;"
                },
                getCookie: function() {
                    if (document.cookie) {
                        for (var e, t, n, i = "freshworks-s360-vid", o = {}, a = document.cookie.split(";"), s = 0, r = a.length; s < r; s++)(e = a[s] && a[s].split("=")) && e.length && (o[e[0].trim()] = e[1]);
                        return o[i] ? (n = o[i], this.removeCookie(i)) : n = o._fw_crm_v, t = n || this.generateUUID(), this.setCookie(t)
                    }
                },
                generateUUID: function() {
                    var e = (new Date).getTime(),
                        t = performance && performance.now && 1e3 * performance.now() || 0;
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(n) {
                        var i = 16 * Math.random();
                        return e > 0 ? (i = (e + i) % 16 | 0, e = Math.floor(e / 16)) : (i = (t + i) % 16 | 0, t = Math.floor(t / 16)), ("x" == n ? i : 7 & i | 8).toString(16)
                    }))
                }
            };

        function W(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }

        function N(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e
        }
        var F = {
                onMessageCB: function() {
                    var e;
                    return function() {
                        return e || (e = this.onMessage.bind(this))
                    }
                }(),
                onCustomEventCB: function() {
                    var e;
                    return function() {
                        return e || (e = this.onCustomMessage.bind(this))
                    }
                }(),
                onVisibilityChangeCB: function() {
                    var e;
                    return function() {
                        return e || (e = this.onVisibilityChange.bind(this))
                    }
                }(),
                subscribe: function() {
                    window.addEventListener ? (window.addEventListener("message", this.onMessageCB(), !1), window.addEventListener("focus", this.onVisibilityChangeCB(), !1), window.addEventListener("blur", this.onVisibilityChangeCB(), !1)) : (window.attachEvent("onmessage", this.onMessageCB()), window.attachEvent("focus", this.onVisibilityChangeCB()), window.attachEvent("blur", this.onVisibilityChangeCB())), this.subscribeSales360Event()
                },
                unsubscribe: function() {
                    window.removeEventListener ? (window.removeEventListener("message", this.onMessageCB(), !1), window.removeEventListener("focus", this.onVisibilityChangeCB(), !1), window.removeEventListener("blur", this.onVisibilityChangeCB(), !1)) : (window.detachEvent("onmessage", this.onMessageCB()), window.detachEvent("focus", this.onVisibilityChangeCB()), window.detachEvent("blur", this.onVisibilityChangeCB())), this.unsubscribeSales360Event()
                },
                subscribeSales360Event: function() {
                    window.addEventListener ? window.addEventListener("fwcrm_event", this.onCustomEventCB(), !1) : window.attachEvent("fwcrm_event", this.onCustomEventCB())
                },
                unsubscribeSales360Event: function() {
                    window.removeEventListener ? window.removeEventListener("fwcrm_event", this.onCustomEventCB(), !1) : window.detachEvent("fwcrm_event", this.onCustomEventCB())
                },
                onVisibilityChange: function(e) {
                    switch (e.type) {
                        case "focus":
                            v.postMessage({
                                action: "widget_focus"
                            });
                            break;
                        case "blur":
                            v.postMessage({
                                action: "widget_blur",
                                payload: {
                                    title: document.title,
                                    location: window.location.href
                                }
                            }), E.postMessage({
                                action: "widget_location",
                                openWindow: !1,
                                payload: window.location.href
                            })
                    }
                },
                onUserCreate: function(e) {
                    _.publish("user:created", e)
                },
                loadWidget: function() {
                    if (!1 === t.isInitialized()) {
                        t.initialized(!0);
                        var e = v.getJSON(),
                            n = h.getProperties(),
                            i = h.getConfig(),
                            o = t.getTags(),
                            a = t.getFaqTags();
                        if (e.integrations = h.getIntegrations(), e.campaignRuleIds = h.getcampaignRuleIds(), e.externalId = h.getExternalId(), e.restoreId = h.getRestoreId(), e.flowId = h.getFlowId(), e.flowVersionId = h.getFlowVersionId(), e.previewMode = h.getPreviewMode(), e.identifyByReferenceId = h.getIdentifyByReferenceId(), n && (e.properties = n), i && (e.config = i), o && (e.tags = o), a && (e.faqTags = a), e.userAgent = g.getAgent, g.storageAvailable) {
                            var s = e.token,
                                r = localStorage.getItem(s),
                                d = e.siteId ? "".concat(e.token, "_").concat(e.siteId) : null,
                                c = d ? localStorage.getItem(d) : null;
                            if ((r || d && c) && (e.storage = {}, e.storage[s] = r || JSON.stringify({}), d && (e.storage[d] = c || JSON.stringify({}))), i && i.overrideDS) {
                                var u = "lsds_".concat(d || s),
                                    l = localStorage.getItem(u);
                                l ? e.lsds = N({}, u, l) : (e.lsds = N({}, u, JSON.stringify({})), e.migrateLFDS = !0)
                            }
                        }
                        v.setFrameSize(), v.setWidgetDisplayStyle(), v.postMessage({
                            action: "load_widget",
                            payload: e
                        })
                    }
                },
                unloadWidget: function() {
                    E.isLoaded() && E.unload(), t.reset(), h.reset(), O(), v.reset(), v.remove(e.frameDivId), this.unsubscribe(), _.publish("widget:destroyed", null, !0), _.clear()
                },
                updateFrameSettings: function(e) {
                    if (null !== v.getSettings() || void 0 === e) return !1;
                    v.setSettings(e)
                },
                onCustomMessage: function(e) {},
                onMessage: function(n) {
                    var i = this,
                        o = n.origin || n.originalEvent.origin,
                        a = h.getConfig(),
                        s = a && a.cssNames;
                    if (o === v.getHost() || o === E.getHostOrigin()) {
                        var r = n.data,
                            d = r && r.action;
                        if (this.updateFrameSettings(r.settingsPayload), d) {
                            var c = document.getElementById(e.frameDivId),
                                u = s && s.expanded || "expanded";
                            switch (d) {
                                case "push_subscribe_destroy_response":
                                    this.unloadWidget();
                                    break;
                                case "push_user_meta":
                                    _.publish("push:subscribed", r.data), v.postMessage(r);
                                    break;
                                case "toggle_dialog":
                                    r.data ? _.publish("dialog:opened") : _.publish("dialog:closed");
                                    break;
                                case "reset_user_cookie":
                                    A.removeCookie(), v.postMessage({
                                        action: "update_cookie",
                                        payload: {
                                            omniCookie: A.getCookie()
                                        }
                                    });
                                    break;
                                case "restore_user_cookie":
                                    A.removeCookie(), A.setCookie(r.alias), v.postMessage({
                                        action: "restore_cookie",
                                        payload: {
                                            alias: r.alias
                                        }
                                    });
                                    break;
                                case "notify_frame":
                                    var l = r.data,
                                        f = document.getElementById(e.frameDivId),
                                        p = s && s.open || "fc-open";
                                    "expand" === l ? (f.removeAttribute("style"), f.classList.add("h-open-notify"), f.classList.add(p), f.classList.add(l)) : "close" === l ? (f.removeAttribute("style"), f.classList.remove("h-open-notify"), f.classList.remove(p), f.classList.remove("expand")) : "mobile-view" === l ? f.classList.add("fc-mobile-view") : (f.classList.add("h-open-notify"), f.classList.add(p));
                                    break;
                                case "resize_frame":
                                    var m = document.getElementsByTagName("BODY")[0],
                                        w = s && s.open || "fc-open";
                                    t.opened(r.isOpen), t.isOpened() ? (c.classList.add("h-open-container"), c.classList.add(w), c.classList.add("widget-open-animate"), _.publish("widget:opened"), setTimeout(function() {
                                        W(this, i), c.classList.remove("widget-open-animate")
                                    }.bind(this), 1e3), m && m.classList.add("fc-widget-open")) : (c.removeAttribute("style"), c.classList.remove("h-open-container"), c.classList.remove(w), _.publish("widget:closed"), m && m.classList.remove("fc-widget-open"));
                                    break;
                                case "toggle_frame":
                                    r.show ? c.classList.remove("hide") : -1 === c.className.trim().indexOf("hide") && c.classList.add("hide");
                                    break;
                                case "push_frame_loaded":
                                    E.loaded(!0), E.setSource(n && n.source), E.postMessage({
                                        action: "widget_location",
                                        openWindow: !1,
                                        payload: window.location.href
                                    }), v.postMessage({
                                        action: "widget_location",
                                        payload: {
                                            title: document.title,
                                            location: window.location.href
                                        }
                                    });
                                    break;
                                case "frame_state_change":
                                    var y = document.getElementById(e.frameDivId),
                                        C = r && r.data,
                                        k = C && C.frameState,
                                        x = v.getSettings() && v.getSettings().enabledFeatures,
                                        L = h.getConfig();
                                    _.publish("frame:statechange", r), "initialized" === k && (v.isJWTEnabled() && v.isJWTStrictMode() && y.classList.add("fc_dn"), null != L && L.eagerLoad && y.classList.add("hide"), this.loadWidget(), x && -1 !== x.indexOf("COBROWSING") && M.init({
                                        host: v.getHost(),
                                        locale: h.getProperties().locale
                                    })), "loaded" === k && v.loaded(!0), "authenticated" !== k && "not_authenticated" !== k || v.isJWTEnabled() && v.isJWTStrictMode() && (r.success ? y.classList.remove("fc_dn") : 304 !== r.status && this.unloadWidget());
                                    break;
                                case "widget_loaded":
                                    t.loaded(!0), _.publish("widget:loaded");
                                    var S = h.getConfig(),
                                        T = document.getElementById(e.frameDivId);
                                    null != S && S.eagerLoad && T.classList.remove("hide"), E.isLoaded() || E.init({
                                        host: r.pushDomain + "?ref=" + btoa(window.location.origin),
                                        hostOrigin: g.url_domain(r.pushDomain),
                                        appLogoPath: r.appLogoPath,
                                        locale: r.locale,
                                        sales360App: r.sales360App
                                    }), t.doOpen() && v.postMessage({
                                        action: "open_chat"
                                    }), v.postMessage({
                                        action: "widget_location",
                                        payload: {
                                            title: document.title,
                                            location: window.location.href
                                        }
                                    });
                                    break;
                                case "datastore_loaded":
                                    v.postMessage({
                                        action: "load_rules"
                                    });
                                    break;
                                case "rules_loaded":
                                    B(), D.start();
                                    break;
                                case "enlarge_image":
                                    I.create(r.picUrl);
                                    break;
                                case "expand_all":
                                    document.getElementById(e.frameDivId).classList.add("expanded-modal"), document.getElementById(e.frameDivId).classList.add(u);
                                    break;
                                case "expand_article_view":
                                    document.getElementById(e.frameDivId).classList.add("expanded-article_view"), document.getElementById(e.frameDivId).classList.remove("collapsed-article_view");
                                    break;
                                case "collapse_article_view":
                                    document.getElementById(e.frameDivId).classList.remove("expanded-article_view"), document.getElementById(e.frameDivId).classList.add("collapsed-article_view");
                                    break;
                                case "collapse_all_article_view":
                                    document.getElementById(e.frameDivId).classList.remove("expanded-article_view"), document.getElementById(e.frameDivId).classList.remove("collapsed-article_view");
                                    break;
                                case "set_bubble_height":
                                    document.getElementById(e.frameDivId).style.height = r.height + "px";
                                    break;
                                case "collapse_all":
                                    document.getElementById(e.frameDivId).classList.remove("expanded-modal"), document.getElementById(e.frameDivId).classList.remove(u), document.getElementById(e.frameDivId).classList.add("avoid-jitter"), setTimeout(function() {
                                        W(this, i), document.getElementById(e.frameDivId).classList.remove("avoid-jitter")
                                    }.bind(this), 300);
                                    break;
                                case "user_state_change":
                                    _.publish("user:statechange", r);
                                    break;
                                case "user_authenticated":
                                    _.publish("user:authenticated", r);
                                    break;
                                case "user_created":
                                    var O = r.data;
                                    if (t.isLoaded()) O && h.setRestoreId(O.restoreId), this.onUserCreate(r);
                                    else if (r.success) {
                                        var P = O && O.externalId,
                                            N = O && O.restoreId,
                                            F = h.getExternalId();
                                        F ? F === P && (h.setRestoreId(N), this.onUserCreate(r)) : this.onUserCreate(r)
                                    } else this.onUserCreate(r);
                                    break;
                                case "user_cleared":
                                    _.publish("user:cleared"), E.postMessage({
                                        action: "clear:subscription",
                                        openWindow: !1
                                    }), h.reset();
                                    break;
                                case "message_sent":
                                    _.publish("message:sent", r);
                                    break;
                                case "message_received":
                                    _.publish("message:received", r);
                                    break;
                                case "read_receipts_update":
                                    _.publish("readReceipts:update", r);
                                    break;
                                case "csat_updated":
                                    _.publish("csat:updated", r);
                                    break;
                                case "csat_received":
                                    _.publish("csat:received", r);
                                    break;
                                case "anchor_link_clicked":
                                    _.publish("anchorLink:clicked", r);
                                    break;
                                case "faq_clicked":
                                    _.publish("faq:clicked", r);
                                    break;
                                case "download_file":
                                    _.publish("download:file", r);
                                    break;
                                case "ask_permission":
                                    E.postMessage({
                                        action: "ask:permission",
                                        openWindow: !0
                                    });
                                    break;
                                case "clear_subscription":
                                    E.postMessage({
                                        action: "clear:subscription",
                                        openWindow: !1
                                    });
                                    break;
                                case "unread_count_notify":
                                    _.publish("unreadCount:notify", r.data);
                                    break;
                                case "message_from_agent":
                                    _.publish("message:received", r.data);
                                    break;
                                case "message_from_user":
                                    _.publish("message:sent", r.data);
                                    break;
                                case "set_storage_item":
                                    if (g.storageAvailable) {
                                        var R = r.data;
                                        R && R.key && R.value && localStorage.setItem(R.key, JSON.stringify(R.value))
                                    }
                                    break;
                                case "remove_storage_item":
                                    if (g.storageAvailable) {
                                        var V = r.data;
                                        V && V.key && localStorage.removeItem(V.key)
                                    }
                                    break;
                                case "startScreenShare":
                                    window.fc_cobrowse && window.fc_cobrowse.allowScreenShare(n);
                                    break;
                                case "set_lsds_item":
                                    if (g.storageAvailable) {
                                        var j = r.data,
                                            q = j && j.key;
                                        if (q) {
                                            var U = j && j.value;
                                            localStorage.setItem(q, g.stringifyJSON(U))
                                        }
                                    }
                                    break;
                                case "get_lsds_item":
                                    if (g.storageAvailable) {
                                        var J = r.data,
                                            z = J && J.key;
                                        z && localStorage.getItem(z)
                                    }
                                    break;
                                case "remove_lsds_item":
                                    if (g.storageAvailable) {
                                        var H = r.data,
                                            G = H && H.key;
                                        G && localStorage.removeItem(G)
                                    }
                                    break;
                                case "requestForAudioCall":
                                    window.fc_cobrowse && window.fc_cobrowse.requestForAudioCall(n);
                                    break;
                                case "rts_connected":
                                    _.publish("rts:connected", r.data);
                                    break;
                                case "rts_disconnected":
                                    _.publish("rts:disconnected", r.data);
                                    break;
                                case "stack_max_height":
                                    var K = screen.height <= 568 ? screen.height : screen.height - 250;
                                    document.getElementById(e.frameDivId).style.maxHeight = K + "px", v.postMessage({
                                        action: "stacked_max_height",
                                        payload: {
                                            height: K
                                        }
                                    });
                                    break;
                                default:
                                    b.publish(d, r)
                            }
                        }
                    }
                },
                syncResponse: function(e, t) {
                    var n = e && e.status;
                    n ? v.dispatch(t, {
                        success: 200 === n,
                        status: n
                    }) : v.dispatch(t, {
                        success: !1,
                        status: 400
                    })
                }
            },
            R = {
                track: function(e, t) {
                    b.subscribe("track_event", {
                        eventName: e,
                        data: t
                    })
                }
            };

        function V(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }

        function j(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e
        }
        var q = function() {
                function e(t) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), j(this, "listenToConfigDataCB", void 0), j(this, "payload", void 0), j(this, "resolve", void 0), j(this, "iframeWindow", void 0), this.payload = t
                }
                var t, n, i;
                return t = e, n = [{
                    key: "fetch",
                    value: function() {
                        var e = this;
                        return new Promise(function(t) {
                            ! function(e, t) {
                                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
                            }(this, e);
                            var n = document.createElement("iframe");
                            n.id = "config-load-iframe", n.style.display = "none", n.src = "".concat(this.payload.host, "/static/html/config_iframe.html?host=").concat(this.payload.host, "&token=").concat(this.payload.token, "&origin=").concat(window.location.origin), document.body.append(n), this.iframeWindow = n.contentWindow, this.resolve = t, this.listenToConfigDataCB = this.listenToConfigData.bind(this), window.addEventListener("message", this.listenToConfigDataCB)
                        }.bind(this))
                    }
                }, {
                    key: "cleanUp",
                    value: function() {
                        this.iframeWindow = null, document.querySelector("#config-load-iframe").remove(), window.removeEventListener("message", this.listenToConfigDataCB)
                    }
                }, {
                    key: "listenToConfigData",
                    value: function(e) {
                        e.source === this.iframeWindow && (this.cleanUp(), this.resolve(JSON.parse(e.data)))
                    }
                }], n && V(t.prototype, n), i && V(t, i), e
            }(),
            U = q;

        function J(e) {
            return J = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            }, J(e)
        }

        function z(e, t) {
            if (t && ("object" === J(t) || "function" == typeof t)) return t;
            if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
            return H(e)
        }

        function H(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function G(e) {
            var t = "function" == typeof Map ? new Map : void 0;
            return G = function(e) {
                if (null === e || (n = e, -1 === Function.toString.call(n).indexOf("[native code]"))) return e;
                var n;
                if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
                if (void 0 !== t) {
                    if (t.has(e)) return t.get(e);
                    t.set(e, i)
                }

                function i() {
                    return K(e, arguments, Y(this).constructor)
                }
                return i.prototype = Object.create(e.prototype, {
                    constructor: {
                        value: i,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }
                }), Q(i, e)
            }, G(e)
        }

        function K(e, t, n) {
            return K = X() ? Reflect.construct : function(e, t, n) {
                var i = [null];
                i.push.apply(i, t);
                var o = new(Function.bind.apply(e, i));
                return n && Q(o, n.prototype), o
            }, K.apply(null, arguments)
        }

        function X() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
            } catch (e) {
                return !1
            }
        }

        function Q(e, t) {
            return Q = Object.setPrototypeOf || function(e, t) {
                return e.__proto__ = t, e
            }, Q(e, t)
        }

        function Y(e) {
            return Y = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                return e.__proto__ || Object.getPrototypeOf(e)
            }, Y(e)
        }

        function Z(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function $(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }

        function ee(e, t, n) {
            return t && $(e.prototype, t), n && $(e, n), e
        }

        function te(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e
        }
        var ne = function() {
                function t(e) {
                    Z(this, t), te(this, "impostorConfig", void 0), this.impostorConfig = e
                }
                return ee(t, [{
                    key: "create",
                    value: function() {
                        var t, n, i, o = this,
                            a = (t = this.impostorConfig, n = t.background, i = t.foreground, {
                                content: '\n            <div class="freshdesk_messaging">\n                <div id="loading"><div class="flexbox">\n                    <div class="dot-loader"></div>\n                    <div class="dot-loader"></div>\n                    <div class="dot-loader"></div>\n                </div>\n                </div>\n                    <div id="static-bubble" class="d-hotline">\n                    <div id="chat-icon">\n                    </div>\n                </div>\n            </div>\n        ',
                                styles: "\n        :host {\n            --background: ".concat(n, ";\n            --foreground: ").concat(i, ';\n        }\n\n        .freshdesk_messaging .d-hotline {\n                display: none;\n                border-radius: 34px 8px 34px 34px;\n                position: fixed !important;\n                bottom: 21px;\n                box-shadow: 0 5px 4px 0 rgba(0, 0, 0, 0.26) !important;\n                color: #fff;\n                cursor: pointer;\n                display: table;\n                position: absolute;\n                right: 20px;\n                z-index: 3147483602 !important;\n                height: 60px;\n                width: 60px;\n                background-color: var(--background) !important;\n                color: #ffffff !important;\n                border-color: var(--background) !important;\n                -webkit-animation: 0.5s zoomIn;\n                animation: 0.5s zoomIn;\n            }\n            .freshdesk_messaging.fullscreen #static-bubble {\n                bottom: 6px !important; \n            }\n            .freshdesk_messaging.fullscreen #loading {\n                bottom: 62px;\n            }\n            .freshdesk_messaging.l2r #static-bubble {\n                left: 20px;\n            }\n            .freshdesk_messaging.l2r #loading {\n                left: 85px;\n            }\n            .freshdesk_messaging.l2r.fullscreen #static-bubble {\n                left: 5px !important;\n            }\n            .freshdesk_messaging.r2l.fullscreen #static-bubble {\n                right: 5px !important;\n            }\n            .freshdesk_messaging.r2l.fullscreen #loading {\n                right: 64px;\n            }\n            .freshdesk_messaging.l2r.fullscreen #loading {\n                left: 72px;\n            }\n            .freshdesk_messaging #chat-icon {\n                width: 38%;\n                height: 17px;\n                border-radius: 6px 6px 6px 2px;\n                position: absolute;\n                background: var(--foreground) !important;\n                top: 37%;\n                left: 32%;\n            }\n            .freshdesk_messaging #chat-icon:before {\n                border-radius: 2px 2px 2px 2px;\n                height: 2px;\n                content: "";\n                border-top: 5px;\n                background: var(--background) !important;\n                width: 65%;\n                position: absolute;\n                top: 5px;\n                left: 4px;\n            }\n            .freshdesk_messaging #chat-icon:after {\n                border-radius: 2px 2px 2px 2px;\n                height: 2px;\n                content: "";\n                border-top: 5px;\n                background: var(--background) !important;\n                width: 44%;\n                position: absolute;\n                top: 10px;\n                left: 4px;\n            }\n            .freshdesk_messaging #loading {\n                visibility: hidden;\n                position: absolute;\n                bottom: 76px;\n                right: 76px;\n                min-width: 55px !important;\n            }\n            .freshdesk_messaging .flexbox {\n                position: fixed;\n                opacity: 0.7;\n                display: -webkit-box;\n                display: -ms-flexbox;\n                display: flex;\n                -ms-flex-wrap: wrap;\n                flex-wrap: wrap;\n            }\n            .freshdesk_messaging .dot-loader {\n                height: 10px;\n                width: 10px;\n                border-radius: 50%;\n                background-color: var(--background) !important;\n                position: relative;\n                -webkit-animation: 1.2s scaleDown ease-in-out infinite;\n                animation: 1.2s scaleDown ease-in-out infinite;\n            }\n            .freshdesk_messaging .dot-loader:nth-child(2) {\n                margin: 0 10px;\n                -webkit-animation: 1.2s scaleDown ease-in-out infinite 0.15555s;\n                animation: 1.2s scaleDown ease-in-out infinite 0.15555s;\n            }\n            .freshdesk_messaging .dot-loader:nth-child(3) {\n                -webkit-animation: 1.2s scaleDown ease-in-out infinite 0.3s;\n                animation: 1.2s scaleDown ease-in-out infinite 0.3s;\n            }\n            @-webkit-keyframes scaleDown {\n                0%,\n                80%,\n                100% {\n                    -webkit-transform: scale(0);\n                    transform: scale(0);\n                }\n                40% {\n                    -webkit-transform: scale(1);\n                    transform: scale(1);\n                }\n            }\n            @keyframes scaleDown {\n                0%,\n                80%,\n                100% {\n                    -webkit-transform: scale(0);\n                    transform: scale(0);\n                }\n                40% {\n                    -webkit-transform: scale(1);\n                    transform: scale(1);\n                }\n            }\n            @-webkit-keyframes zoomIn {\n            0% {\n                -webkit-transform: scale(0);\n                transform: scale(0);\n            }\n            \n            100% {\n                -webkit-transform: scale(1);\n                transform: scale(1);\n            }\n            }\n            \n            @keyframes zoomIn {\n            0% {\n                -webkit-transform: scale(0);\n                transform: scale(0);\n            }\n            \n            100% {\n                -webkit-transform: scale(1);\n                transform: scale(1);\n            }\n            }\n\n            @media only screen and (min-device-width: 320px) and (max-device-width: 480px) {\n              .mobile .d-hotline {\n                  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .2) !important;\n            \n                  width: 50px;\n                  height: 50px;\n            }\n\n            .mobile #chat-icon {\n                width: 43% !important;\n                top: 32% !important;\n            }\n        ')
                            });
                        return function(t) {
                            var n = t.onDemandWidgetCB,
                                i = t.fullscreen,
                                s = t.l2r,
                                r = t.isMobile;
                            ! function(e, t) {
                                if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
                            }(this, o);
                            var d = e.impostor.tagName,
                                c = function() {
                                    var e = document.createElement("template");
                                    return e.innerHTML = '\n              <style id="widget-style">'.concat(a.styles.toString(), "</style>\n              ").concat(a.content, "\n            "), e
                                }(),
                                u = function(e) {
                                    ! function(e, t) {
                                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                                        e.prototype = Object.create(t && t.prototype, {
                                            constructor: {
                                                value: e,
                                                writable: !0,
                                                configurable: !0
                                            }
                                        }), t && Q(e, t)
                                    }(u, e);
                                    var t, o, a = (t = u, o = X(), function() {
                                        var e, n = Y(t);
                                        if (o) {
                                            var i = Y(this).constructor;
                                            e = Reflect.construct(n, arguments, i)
                                        } else e = n.apply(this, arguments);
                                        return z(this, e)
                                    });

                                    function u() {
                                        var e, t;
                                        Z(this, u), te(H(t = a.call(this)), "onDemandCB", void 0), t.attachShadow({
                                            mode: "open"
                                        }).appendChild(c.content.cloneNode(!0)), t.onDemandCB = t.onDemand.bind(H(t)), null === (e = t.shadowRoot) || void 0 === e || e.querySelector("#static-bubble").addEventListener("mousedown", t.onDemandCB);
                                        var n, o, d = [];
                                        (i && d.push("fullscreen"), s ? d.push("l2r") : d.push("r2l"), r && d.push("mobile"), d.length) && (null === (n = t.shadowRoot) || void 0 === n || (o = n.querySelector(".freshdesk_messaging").classList).add.apply(o, d));
                                        return t
                                    }
                                    return ee(u, [{
                                        key: "onDemand",
                                        value: function() {
                                            this.removeMouseDownHandler(), this.showLoading(), n()
                                        }
                                    }, {
                                        key: "removeMouseDownHandler",
                                        value: function() {
                                            var e, t = null === (e = this.shadowRoot) || void 0 === e ? void 0 : e.querySelector("#static-bubble");
                                            t && t.removeEventListener("mousedown", this.onDemandCB)
                                        }
                                    }, {
                                        key: "removeBubble",
                                        value: function() {
                                            this.shadowRoot.querySelector("#static-bubble").style.display = "none", this.removeMouseDownHandler()
                                        }
                                    }, {
                                        key: "removeImpostor",
                                        value: function() {
                                            this.removeLoading(), this.shadowRoot.querySelector(".freshdesk_messaging").style.display = "none", document.querySelector(d).remove()
                                        }
                                    }, {
                                        key: "removeLoading",
                                        value: function() {
                                            var e;
                                            (null === (e = this.shadowRoot) || void 0 === e ? void 0 : e.querySelector(".freshdesk_messaging #loading")).style.visibility = "hidden"
                                        }
                                    }, {
                                        key: "showLoading",
                                        value: function() {
                                            var e;
                                            (null === (e = this.shadowRoot) || void 0 === e ? void 0 : e.querySelector(".freshdesk_messaging #loading")).style.visibility = "visible"
                                        }
                                    }]), u
                                }(G(HTMLElement));
                            customElements.get(d) || customElements.define(d, u);
                            var l = document.createElement(d, {
                                is: d
                            });
                            return document.body.appendChild(l), l
                        }.bind(this)(this.impostorConfig)
                    }
                }]), t
            }(),
            ie = ne;

        function oe(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }

        function ae(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }

        function se(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }

        function re(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e
        }
        var de = function() {
                function t(e) {
                    var n;
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), re(this, "payload", void 0), re(this, "eagerLoad", void 0), re(this, "onWidgetLoadedCB", void 0), re(this, "onWidgetOpenedCB", void 0), re(this, "listenToConfigDataCB", void 0), re(this, "sendConfigsToFreshChatCB", void 0), re(this, "appConfig", void 0), re(this, "appConfigService", void 0), re(this, "impostorConfig", void 0), re(this, "impostor", void 0), re(this, "openWidgetOnLoad", void 0), re(this, "isWidgetBeingLoaded", void 0), re(this, "loadFreshChatCB", void 0), re(this, "unbindBrowserEventsCB", void 0), re(this, "rejectLoadingFreshchat", void 0), re(this, "activityEvents", void 0), re(this, "dontLoadWithImpostor", !0), this.payload = e, this.eagerLoad = null == e || null === (n = e.config) || void 0 === n ? void 0 : n.eagerLoad
                }
                var n, i, o;
                return n = t, i = [{
                    key: "init",
                    value: function() {
                        var e = this;
                        return new Promise(function(t, n) {
                            var i, o;
                            ae(this, e), this.loadFreshChatCB = t, this.rejectLoadingFreshchat = n, null !== (i = this.payload) && void 0 !== i && null !== (o = i.config) && void 0 !== o && o.eagerLoad ? this.processImpostor() : this.loadFreshChat()
                        }.bind(this))
                    }
                }, {
                    key: "onDemand",
                    value: function() {
                        this.isWidgetBeingLoaded ? this.openWidgetOnLoad = !0 : (this.payload.open = !0, this.loadFreshChat())
                    }
                }, {
                    key: "processImpostor",
                    value: function() {
                        var t = this;
                        this.appConfigService = new U(this.payload),
                            function(e, t) {
                                var n = this,
                                    i = new Promise(function(e, i) {
                                        var o = this;
                                        oe(this, n), setTimeout(function() {
                                            oe(this, o), i(new Error("Timeout triggered"))
                                        }.bind(this), t)
                                    }.bind(this));
                                return Promise.race([e, i])
                            }(this.appConfigService.fetch(), e.impostor.timeoutForFetchingConfigInMillis).then(function(e) {
                                var n, i;
                                ae(this, t), this.appConfig = e, this.impostorConfig = this.getImpostorConfig(), null !== (n = this.impostorConfig) && void 0 !== n && n.hideMessenger ? this.rejectLoadingFreshchat() : (this.listenToWidgetAndBrowserEvents(), null !== (i = this.impostorConfig) && void 0 !== i && i.show && (this.impostor = new ie(this.impostorConfig).create()))
                            }.bind(this), function() {
                                ae(this, t), this.appConfigService.cleanUp(), this.loadFreshChat({
                                    dontLoadWithEagerLoad: !0
                                })
                            }.bind(this))
                    }
                }, {
                    key: "getImpostorConfig",
                    value: function() {
                        var e, t, n, i, o, a, s, r, d, c, u, l, f, h, p, g, m, v = (null === (e = this.payload) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.headerProperty) || void 0 === n ? void 0 : n.hideChatButton) || !1;
                        return {
                            hideChatButton: v,
                            hideMessenger: this.appConfig.hideMessenger || !1,
                            background: (null === (i = this.payload) || void 0 === i || null === (o = i.config) || void 0 === o || null === (a = o.headerProperty) || void 0 === a ? void 0 : a.backgroundColor) || (null === (s = this.appConfig) || void 0 === s || null === (r = s.headerProperty) || void 0 === r ? void 0 : r.backgroundColor),
                            foreground: (null === (d = this.payload) || void 0 === d || null === (c = d.config) || void 0 === c || null === (u = c.headerProperty) || void 0 === u ? void 0 : u.foregroundColor) || (null === (l = this.appConfig) || void 0 === l || null === (f = l.headerProperty) || void 0 === f ? void 0 : f.foregroundColor) || "white",
                            show: !v,
                            fullscreen: (null === (h = this.payload) || void 0 === h ? void 0 : h.config.fullscreen) || !1,
                            l2r: "ltr" === (null === (p = this.payload) || void 0 === p || null === (g = p.config) || void 0 === g || null === (m = g.headerProperty) || void 0 === m ? void 0 : m.direction),
                            onDemandWidgetCB: this.onDemand.bind(this),
                            isMobile: /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)
                        }
                    }
                }, {
                    key: "loadFreshChat",
                    value: function(e) {
                        this.isWidgetBeingLoaded = !0, this.loadFreshChatCB(e), this.eagerLoad && (this.sendConfigsToFreshChatCB = this.sendConfigsToFreshChat.bind(this), window.addEventListener("message", this.sendConfigsToFreshChatCB))
                    }
                }, {
                    key: "sendConfigsToFreshChat",
                    value: function(t) {
                        t.data.action === e.impostor.getFreshChatConfigs && (v.postMessage({
                            action: "config_data",
                            payload: this.appConfig
                        }), this.appConfig = null, window.removeEventListener("message", this.sendConfigsToFreshChatCB))
                    }
                }, {
                    key: "listenToWidgetAndBrowserEvents",
                    value: function() {
                        this.onWidgetOpenedCB = this.onWidgetOpened.bind(this), this.onWidgetLoadedCB = this.onWidgetLoaded.bind(this), window.fcWidget.on("widget:loaded", this.onWidgetLoadedCB), window.fcWidget.on("widget:opened", this.onWidgetOpenedCB), this.activityEvents = e.impostor.activityEvents, this.unbindBrowserEventsCB = this.unbindBrowserEvents.bind(this, !1), this.bindBrowserEvents.bind(this)()
                    }
                }, {
                    key: "unbindBrowserEvents",
                    value: function() {
                        var e = this,
                            t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        this.activityEvents.forEach(function(t) {
                            ae(this, e), document.removeEventListener(t, this.unbindBrowserEventsCB, !0)
                        }.bind(this)), t || this.loadFreshChat()
                    }
                }, {
                    key: "bindBrowserEvents",
                    value: function() {
                        var e = this;
                        this.activityEvents.forEach(function(t) {
                            ae(this, e), document.addEventListener(t, this.unbindBrowserEventsCB, !0)
                        }.bind(this))
                    }
                }, {
                    key: "onWidgetOpened",
                    value: function() {
                        this.cleanUp()
                    }
                }, {
                    key: "onWidgetLoaded",
                    value: function() {
                        this.openWidgetOnLoad ? window.fcWidget.open() : this.cleanUp()
                    }
                }, {
                    key: "cleanUp",
                    value: function() {
                        var e, t;
                        null === (e = this.impostor) || void 0 === e || e.removeBubble(), this.isWidgetBeingLoaded = !1, this.unbindBrowserEvents(!0), window.fcWidget.off("widget:opened", this.onWidgetOpenedCB), window.fcWidget.off("widget:loaded", this.onWidgetLoadedCB), null === (t = this.impostor) || void 0 === t || t.removeImpostor()
                    }
                }], i && se(n.prototype, i), o && se(n, o), t
            }(),
            ce = de;

        function ue(e, t) {
            if (e !== t) throw new TypeError("Cannot instantiate an arrow function")
        }
        var le = function() {
            ue(this, undefined);
            var n = function(e) {
                    var n;
                    t.reset(), h.reset(), O(), F.unsubscribe(), v.init({
                        host: e.host.trim(),
                        token: e.token.trim(),
                        referrer: e.referrer,
                        siteId: e.siteId,
                        flowId: e.flowId,
                        flowVersionId: e.flowVersionId,
                        campaignRuleIds: e.campaignRuleIds,
                        previewMode: e.previewMode,
                        jwtAuthToken: e.jwtAuthToken,
                        cspNonce: e.cspNonce,
                        omniCookie: A.getCookie() || e.omniCookie,
                        eagerLoad: (null == e || null === (n = e.config) || void 0 === n ? void 0 : n.eagerLoad) || null
                    }), t.openOnLoad(e.open), e.identifyByReferenceId && h.setIdentifyByReferenceId(!0), e.flowId && h.setFlowId(e.flowId), e.integrations && h.setIntegrations(e.integrations), e.campaignRuleIds && h.setcampaignRuleIds(e.campaignRuleIds), e.flowVersionId && h.setFlowVersionId(e.flowVersionId), e.previewMode && h.setPreviewMode(e.previewMode), e.externalId && (h.setExternalId(e.externalId), h.setRestoreId(e.restoreId)), e.tags && e.tags.length && t.setTags(e.tags), e.faqTags && t.setFaqTags(e.faqTags), h.setProperties({
                        firstName: e.firstName,
                        lastName: e.lastName,
                        email: e.email,
                        phone: e.phone,
                        phoneCountry: e.phoneCountryCode,
                        locale: e.locale,
                        meta: e.meta
                    }), h.setConfig(e.config), e.onLoad && _.subscribe("widget:loaded", e.onLoad), v.add(), F.subscribe()
                },
                i = function() {
                    var e = document,
                        t = e.createElement("link"),
                        n = g.cdn_url() ? g.cdn_url() : v.getHost();
                    t.href = n + "/css/widget.css?t=" + (new Date).getTime(), t.rel = "stylesheet", e.getElementsByTagName("head")[0].appendChild(t)
                };
            return {
                init: function(t) {
                    window.fcWidgetMessengerConfig && (t = Object.assign(t, window.fcWidgetMessengerConfig));
                    var o = function() {
                        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        o.dontLoadWithImpostor && (t.config.eagerLoad = !1);
                        var a = -1 !== ["Chrome", "Firefox", "Safari", "Edge", "Trident", "WebView"].indexOf(g.getAgent.name),
                            s = -1 !== ["Station"].indexOf(g.getAgent.appName);
                        if (a && !s && !this.isInitialized()) {
                            var r = t && t.token;
                            r && r.toUpperCase() !== e.SAMPLE_TOKEN && (window.location.origin || (window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":" + window.location.port : "")), t.referrer = btoa(window.location.origin), void 0 === t.open && (t.open = !1), n(t), i())
                        }
                    }.bind(this);
                    window.Promise ? new ce(t).init(t).then(o, (function() {})) : o()
                },
                destroy: function() {
                    E.unload(), v.unload()
                },
                isOpen: function() {
                    return t.isOpened()
                },
                isInitialized: function() {
                    return !!v.getToken()
                },
                isLoaded: function() {
                    return t.isLoaded()
                },
                on: function(e, t) {
                    _.subscribe(e, t)
                },
                off: function(e, t) {
                    _.unsubscribe(e, t)
                },
                open: function(e) {
                    e ? b.subscribe("open_channel", e) : b.subscribe("open_chat")
                },
                close: function() {
                    b.subscribe("close_chat")
                },
                show: function() {
                    b.subscribe("show_chat")
                },
                hide: function() {
                    b.subscribe("hide_chat")
                },
                setTags: function(e) {
                    t.isLoaded() && (e && e.length ? t.setTags(e) : t.setTags([]), b.subscribe("set_tags", {
                        tags: t.getTags(),
                        force: !0
                    }))
                },
                setFaqTags: function(e) {
                    t.isLoaded() && (e ? t.setFaqTags(e) : t.setFaqTags({}), b.subscribe("set_faq_tags", {
                        faqTags: t.getFaqTags(),
                        force: !0
                    }))
                },
                setExternalId: function(e, t) {
                    var n = {};
                    if (e) {
                        if ("string" == typeof e ? n.externalId = e : n = e, !(void 0 === window.Promise || t && "function" == typeof t)) return y("set_external_id", n);
                        C("set_external_id", n, t)
                    }
                },
                setConfig: function(t) {
                    var n = document.getElementById(e.frameDivId);
                    n && t && (void 0 !== t.fullscreen && (n.classList.remove(e.classes.fullscreenClass), !0 === t.fullscreen && n.classList.add(e.classes.fullscreenClass)), t.headerProperty && (void 0 !== t.headerProperty.direction && (n.classList.remove("fc_l2r"), "ltr" === t.headerProperty.direction && n.classList.add("fc_l2r")), void 0 !== t.headerProperty.hideChatButton && (n.classList.remove("fc_dn"), t.headerProperty.hideChatButton && n.classList.add("fc_dn")))), b.subscribe("set_custom_config", t)
                },
                user: {
                    get: function(e) {
                        if (!(void 0 === window.Promise || e && "function" == typeof e)) return y("get_user");
                        C("get_user", e)
                    },
                    isExists: function(e) {
                        if (!(void 0 === window.Promise || e && "function" == typeof e)) return y("user_exists");
                        C("user_exists", e)
                    },
                    update: function(e, t) {
                        if (e.jwtAuthToken ? v.setJWTAuthToken(e.jwtAuthToken) : (e.firstName && h.setFirstName(e.firstName), e.lastName && h.setLastName(e.lastName), e.email && h.setEmail(e.email), e.phone && h.setPhone(e.phone), e.phoneCountry && h.setPhoneCountry(e.phoneCountry), e.meta && h.setUserMeta(e.meta)), !(void 0 === window.Promise || t && "function" == typeof t)) return y("update_user", e);
                        C("update_user", e, t)
                    },
                    setProperties: function(e, t) {
                        var n = {};
                        if (e.jwtAuthToken ? (v.setJWTAuthToken(e.jwtAuthToken), n = e) : (e.firstName && (n.firstName = e.firstName, delete e.firstName), e.lastName && (n.lastName = e.lastName, delete e.lastName), e.email && (n.email = e.email, delete e.email), e.phone && (n.phone = e.phone, delete e.phone), e.phoneCountryCode && (n.phoneCountry = e.phoneCountryCode, delete e.phoneCountryCode), e.locale && (n.locale = e.locale, delete e.locale), n.meta = e, h.setProperties(n)), !(void 0 === window.Promise || t && "function" == typeof t)) return y("set_user_properties", n);
                        C("set_user_properties", n, t)
                    },
                    setFirstName: function(e, t) {
                        var n = {};
                        if (e) {
                            if ("string" == typeof e ? n.firstName = e : n = e, !t) return this.setProperties(n);
                            this.setProperties(n, t)
                        }
                    },
                    setLastName: function(e, t) {
                        var n = {};
                        if (e) {
                            if ("string" == typeof e ? n.lastName = e : n = e, !t) return this.setProperties(n);
                            this.setProperties(n, t)
                        }
                    },
                    setEmail: function(e, t) {
                        var n = {};
                        if (e) {
                            if ("string" == typeof e ? n.email = e : n = e, !t) return this.setProperties(n);
                            this.setProperties(n, t)
                        }
                    },
                    setPhone: function(e, t) {
                        var n = {};
                        if (e) {
                            if ("string" == typeof e ? n.phone = e : n = e, !t) return this.setProperties(n);
                            this.setProperties(n, t)
                        }
                    },
                    setPhoneCountryCode: function(e, t) {
                        var n = {};
                        if (e) {
                            if ("string" == typeof e ? n.phoneCountryCode = e : n = e, !t) return this.setProperties(n);
                            this.setProperties(n, t)
                        }
                    },
                    setMeta: function(e, t) {
                        if (!t) return this.setProperties(e);
                        this.setProperties(e, t)
                    },
                    setLocale: function(e, t) {
                        var n = {};
                        if (e) {
                            if ("string" == typeof e ? n.locale = e : n = e, !t) return this.setProperties(n);
                            this.setProperties(n, t)
                        }
                    },
                    clear: function(e) {
                        if (!(void 0 === window.Promise || e && "function" == typeof e)) return y("reset_user");
                        C("reset_user", e)
                    },
                    create: function(e, t) {
                        if ("function" == typeof e && (t = e, e = null), !(void 0 === window.Promise || t && "function" == typeof t)) return y("create_user", e);
                        C("create_user", e, t)
                    },
                    clone: function(e, t) {
                        if ("function" == typeof e && (t = e, e = null), !(void 0 === window.Promise || t && "function" == typeof t)) return y("clone_user", e);
                        C("clone_user", e, t)
                    },
                    getUUID: function(e) {
                        if (!(void 0 === window.Promise || e && "function" == typeof e)) return y("get_user_uuid");
                        C("get_user_uuid", e)
                    },
                    generateUUID: function(e) {
                        if (!(void 0 === window.Promise || e && "function" == typeof e)) return y("generate_user_uuid");
                        C("generate_user_uuid", e)
                    }
                },
                track: R.track,
                trackPage: function(e, t) {
                    L.track({
                        newValue: e,
                        title: t,
                        force: !0
                    })
                },
                authenticate: function(e) {
                    var t = this;
                    if (v.isJWTEnabled()) {
                        var n = function() {
                                ue(this, t), v.setJWTAuthToken(e), v.postMessage({
                                    action: "authenticate_user",
                                    payload: e
                                })
                            }.bind(this),
                            i = function(i) {
                                ue(this, t), i && 200 === i.status ? this.user.update({
                                    jwtAuthToken: e
                                }) : n()
                            }.bind(this);
                        this.isLoaded() ? void 0 === window.Promise ? this.user.get(i) : this.user.get().then(i, i) : n()
                    }
                }
            }
        }.bind(void 0)();
        if (window.fcWidget || (window.fcWidget = le), window.fcSettings)
            if ("complete" === document.readyState) {
                var fe = window.fcSettings.onInit;
                fe && "function" == typeof fe && fe(), le.init(window.fcSettings)
            } else document.onreadystatechange = function(e) {
                return function() {
                    if ("complete" === document.readyState) {
                        var t = window.fcSettings.onInit;
                        t && "function" == typeof t && t(), e.init(window.fcSettings)
                    }
                }
            }(le)
    }()
}();