(self.webpackChunkhotline_web = self.webpackChunkhotline_web || []).push([
    [8098], {
        8098: function(e, t, n) {
            var i = window.define;
            i("hotline-web/templates/home/channel", (function() {
                return n(88237)
            })), i("hotline-web/controllers/home/channel", (function() {
                return n(96750)
            })), i("hotline-web/routes/home/channel", (function() {
                return n(93244)
            }))
        },
        93589: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(78933),
                s = n(43436),
                o = n(80033),
                a = n(62588),
                l = n(16874);
            t.default = Ember.Component.extend(a.default, o.default, s.default, l.default, {
                tagName: "ul",
                classNames: ["fc-app-conversation-message"],
                classNameBindings: ["isFeedbackMessage:feedback-message"],
                notification: Ember.inject.service(),
                liveTranslation: Ember.inject.service(),
                localStorage: Ember.inject.service("local-storage"),
                pushPermissionOffered: !1,
                channelWrapedMessage: Ember.computed("channelMessage", {
                    get: function() {
                        var e = [];
                        return e.push(this.channelMessage), e
                    }
                }),
                currentAgent: Ember.computed("lastAgentMessage.messageId", {
                    get: function() {
                        var e = this.lastAgentMessage,
                            t = e && e.get("messageUserAlias");
                        return !!t && this.agentService.getAgentInfo(t)
                    }
                }),
                calendarMessages: Ember.computed.alias("conversationCalendarMessages"),
                messagesWithAppId: Ember.computed("messages.[]", {
                    get: function() {
                        var e = this,
                            t = this.messages.filter(function(t) {
                                return (0, i.Z)(this, e), t.get("appId")
                            }.bind(this));
                        return t && t.length
                    },
                    set: function(e, t) {
                        return t
                    }
                }),
                messageAppIdObserver: Ember.observer("messages.@each.createdMillis", (function() {
                    var e = this,
                        t = this.messages ? this.messages.filter(function(t) {
                            return (0, i.Z)(this, e), t.get("appId")
                        }.bind(this)) : null;
                    t && t.length > this.messagesWithAppId && this.set("messagesWithAppId", t.length)
                })),
                screenShare: Ember.computed.reads("session.fcCbstart"),
                showPushOptions: Ember.computed("hotline.ui.push.{subscription,permission}", "pushPermissionOffered", "messagesCount", {
                    get: function() {
                        var e, t, n = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.push,
                            i = this.messages,
                            s = i && i.findBy("messageUserType", 0),
                            o = this.messagesCount,
                            a = n && n.subscription,
                            l = "denied" === (n && n.permission),
                            r = this.pushPermissionOffered,
                            u = (new Date).getTime(),
                            c = this.localStorage.getItemLS("lastPushActionMillis"),
                            d = this.notification.isPushSupportedByBrowser(),
                            p = !1;
                        return c = parseInt(c), u - (c = isNaN(c) ? 0 : c) > 6048e5 && (p = !0), !l && !a && p && !r && o && d && s
                    }
                }),
                setLastPushActionMillis: function() {
                    var e, t, n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    !n && null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isFirefoxMobile || (this.localStorage.setItemLS("lastPushActionMillis", (new Date).getTime()), this.set("pushPermissionOffered", !0))
                },
                actions: {
                    askPermission: function() {
                        this.notification.requestPermission(), this.setLastPushActionMillis()
                    },
                    clearPermission: function() {
                        this.notification.clearPermission(), this.setLastPushActionMillis(!0)
                    },
                    openCalendarPickerMaximized: function(e) {
                        this.openCalendarPickerMaximized(e)
                    },
                    sendMessage: function(e, t) {
                        this.sendMessage(e, t)
                    },
                    resendMessage: function(e) {
                        this.resendMessage(e)
                    },
                    sendOfflineMessage: function(e) {
                        this.sendOfflineMessage(e)
                    }
                }
            })
        },
        33144: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return k
                }
            });
            var i = n(77963),
                s = n(78933),
                o = n(67117),
                a = n(62588),
                l = n(72887),
                r = n(43436),
                u = n(80033),
                c = n(17067),
                d = n(5016),
                p = n(46377),
                m = n(66235),
                h = n(61230),
                f = n(8797),
                g = n(8543),
                v = n(23798),
                b = n(37271),
                y = n(92429),
                w = n(51535),
                E = n(10218),
                T = n(52340),
                S = n.p + "ic_offline.e15c54b5fa2b3da7577b7869b850722d.svg",
                C = n.p + "briefcase-regular.1fb32179dcc50beeba1a21747ce7a539.svg",
                M = n(99538);

            function _(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function O(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? _(Object(n), !0).forEach((function(t) {
                        (0, i.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : _(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var k = Ember.Component.extend(a.default, u.default, r.default, l.default, c.default, m.default, {
                PLACEHOLDERS: o.default.CONVERSATION.PLACEHOLDERS,
                CONVERSATION: o.default.CONVERSATION,
                DOM_ID: o.default.DOM_ID,
                notification: Ember.inject.service(),
                hotline: Ember.inject.service(),
                conversationService: Ember.inject.service("conversation"),
                localStorage: Ember.inject.service("local-storage"),
                responseTime30Mins: !1,
                responseTime7Days: !1,
                cdnUrl: g.default.EmberENV.cdnUrl,
                isOldConvRequestPending: !1,
                showUnreadToast: !1,
                focusAfterOfflineMessage: !1,
                isLoadedAllOlderMessages: !1,
                extraParams: {},
                images: Ember.Object.create({
                    FCLine: T.Z,
                    ICOffline: S,
                    BCReg: C,
                    ValidationErrorIcon: M.Z
                }),
                transitionDelays: 100,
                hideHeader: Ember.computed.alias("session.config.headerProperty.hideHeader"),
                isConversationsLoaded: Ember.computed.alias("hotline.ui.isConversationsLoaded"),
                classNames: ["h-conv"],
                classNameBindings: ["hideHeader:hide-header"],
                allowRR: !0,
                fileId: "fileUploadInput",
                blockedFileTypes: o.default.ExcludedFileExtensions,
                fileType: o.default.FILETYPE,
                isTextLimitExceeded: !1,
                pendingUploadTextFileObject: null,
                isValueInEditor: !1,
                appConversationEditorNode: null,
                editorHasContent: !1,
                chatWindowClass: Ember.computed("defaultComposer", "conversation.resolvedConversation", "shouldHideReplyEditor", "quickActionButtons", {
                    get: function() {
                        var e = "";
                        return this.defaultComposer ? this.quickActionButtons && (e = "".concat(e, " actions-composer")) : e = "".concat(e, " button-composer"), this.conversation && this.conversation.resolvedConversation && (e = "".concat(e, " fixed-scroll")), this.shouldHideReplyEditor && (e = "".concat(e, " offline-form")), e
                    }
                }),
                agentProfileClass: Ember.computed("currentAgent.{title,bio}", {
                    get: function() {
                        var e = "",
                            t = Ember.get(this, "currentAgent");
                        return t && t.get("title") && (e = "".concat(e, " agent-section")), t && t.get("bio") && (e = "".concat(e, " agent-bio")), e
                    }
                }),
                isSingleChannel: Ember.computed("isFAQAvailable", "channelsCount", {
                    get: function() {
                        return !this.isFAQAvailable && 1 === this.channelsCount
                    }
                }),
                chatSectionClass: Ember.computed("showAgentProfile", "showCalPicker", "channelEventReminder.eventDateTime", "isAgentProfileExpand", "isFocusInput", "shouldHideReplyEditor", "conversation.resolvedConversation", {
                    get: function() {
                        var e = "";
                        return this.showAgentProfile && (e = "".concat(e, " profile")), this.showCalPicker && (e = "".concat(e, " show-calendar-picker")), this.channelEventReminder && this.channelEventReminder.eventDateTime && (e = "".concat(e, " cal-notif-active")), this.isAgentProfileExpand && (e = "".concat(e, " profile-expand")), this.shouldHideReplyEditor && (e = "".concat(e, " offline-form")), this.conversation && this.conversation.resolvedConversation && (e = "".concat(e, " csat-fix")), this.showAgentProfile && !this.isFocusInput || (e = "".concat(e, " no-profile")), e
                    }
                }),
                replyWrapperClass: Ember.computed("defaultComposer", "shouldHideReplyEditor", {
                    get: function() {
                        var e = "";
                        return this.defaultComposer || (e = "".concat(e, " custom-reply-composer")), this.shouldHideReplyEditor && (e = "".concat(e, " offline-form")), e
                    }
                }),
                replyEditorClass: Ember.computed("hasFileAttachment", "data.fileContent", "hotline.ui.onLine", "shouldHideReplyEditor", {
                    get: function() {
                        var e = "";
                        return this.hasFileAttachment && (e = "".concat(e, " has-file-attachment")), this.data && this.data.fileContent && (e = "".concat(e, " preview")), this.hotline && this.hotline.ui && !this.hotline.ui.onLine && (e = "".concat(e, " is-disabled")), this.shouldHideReplyEditor && (e = "".concat(e, " offline-form")), e
                    }
                }),
                hasValueInEditor: Ember.computed("isValueInEditor", "data.fileContent", "hasFileAttachment", {
                    get: function() {
                        return this.isValueInEditor || this.data && this.data.fileContent || this.hasFileAttachment
                    }
                }),
                doesUserExists: Ember.computed({
                    get: function() {
                        return !0
                    },
                    set: function(e, t) {
                        return t
                    }
                }),
                validationMsg: Ember.computed("hotline.ui.validationMessage", {
                    get: function() {
                        var e, t;
                        return null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.validationMessage
                    }
                }),
                channelResponseTime: Ember.computed("channelId", "hotline.ui.rspTime.{channelResponseTime,channelResponseTimesFor7Days}", {
                    get: function() {
                        var e, t, n, i, s, o, a, l, r = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.rspTime) || void 0 === n ? void 0 : n.channelResponseTime,
                            u = null === (i = this.hotline) || void 0 === i || null === (s = i.ui) || void 0 === s || null === (o = s.rspTime) || void 0 === o ? void 0 : o.channelResponseTimesFor7Days,
                            c = this.channelId,
                            d = [];
                        return r && r.length && (a = r.find((function(e) {
                            return e.channelId === c
                        }))), u && u.length && (l = u.find((function(e) {
                            return e.channelId === c
                        }))), a ? (this.set("responseTime30Mins", !0), d = a) : l && (this.set("responseTime7Days", !0), d = l), d
                    }
                }),
                customResponseTime: Ember.computed("channelId", "hotline.ui.rspTime.channelCustomResponse", {
                    get: function() {
                        var e, t, n, i, s = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.rspTime) || void 0 === n ? void 0 : n.channelCustomResponse,
                            o = this.channelId;
                        return s && s.length && (i = s.findBy("channelId", o)), i
                    }
                }),
                checkIfRtlIE: Ember.computed("hotline.ui.browser.name", {
                    get: function() {
                        var e, t, n, i = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.browser) || void 0 === n ? void 0 : n.name,
                            s = document.body.attributes.dir;
                        return "rtl" === (s && s.value) && ("Trident" === i || "Microsoft Internet Explorer" === i)
                    }
                }),
                showAgentProfile: Ember.computed("currentAgent.{firstName,lastName}", "hideName", {
                    get: function() {
                        var e = Ember.get(this, "currentAgent");
                        return !!e && (Ember.get(e, "firstName") || Ember.get(e, "lastName"))
                    }
                }),
                isSocialLinkPresent: Ember.computed("currentAgent.socialInfo.{twitter,facebook,linkedIn,skype}", {
                    get: function() {
                        var e = Ember.get(this, "currentAgent.socialInfo");
                        return !!e && (e.twitter || e.facebook || e.linkedIn || e.skype)
                    }
                }),
                handleLoadingOlderMessages: function() {
                    document.getElementsByClassName("h-conv-chat")[0].scrollTop <= 30 ? this.send("fetchOlderMessages") : this.getScrollDistanceFromBottom() < 90 && this.resetUnreadCount()
                },
                onScroll: function() {
                    this.set("isAgentProfileExpand", !1), this.handleLoadingOlderMessages()
                },
                onScrollWithDebounce: function() {
                    Ember.run.debounce(this, this.onScroll, o.default.Debounce.SCROLL_DELAY)
                },
                scrollCallback: Ember.computed({
                    get: function() {
                        return this.onScrollWithDebounce.bind(this)
                    }
                }),
                willDestroyElement: function() {
                    var e, t;
                    this._super.apply(this, arguments), (0, h.unbindEvent)(document, "selectionchange", this.setSelectionCallback), Ember.removeListener(this.hotline, "conversationsLoadedEvent", this.conversationsLoadedEventCB), (0, h.unbindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback), null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isDesktop || ((0, h.unbindEvent)(this.element.querySelector("#app-conversation-editor"), "focus"), (0, h.unbindEvent)(this.element.querySelector("#app-conversation-editor"), "blur"), (0, h.unbindEvent)(window, "resize")), this.isJWTStrictMode && Ember.removeListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB), this.messages && this.messages.length > 100 && this.set("messages", this.getLatestNMessages(this.messages))
                },
                isAwayMessage: Ember.computed("lastAgentMessage.source", {
                    get: function() {
                        var e = this.lastAgentMessage,
                            t = e && e.get("source");
                        return t === o.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE || t === o.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE_THANK_MESSAGE || t === o.default.CONVERSATION.MESSAGE_SOURCE.BH_AWAY_MESSAGE
                    }
                }),
                isLastAgentMessageFromBot: Ember.computed("lastAgentMessage.messageType", {
                    get: function() {
                        var e, t = null === (e = this.lastAgentMessage) || void 0 === e ? void 0 : e.messageType;
                        return t === o.default.CONVERSATION.MESSAGE_TYPE.BOT || t === o.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT
                    }
                }),
                currentAgent: Ember.computed("CONVERSATION.MESSAGE_TYPE.BOT", "agentService", "isAwayMessage", "lastAgentMessage.messageId", {
                    get: function() {
                        var e, t, n = this.lastAgentMessage,
                            i = n && n.get("messageUserAlias"),
                            s = this.isAwayMessage;
                        return i && n.get("messageType") === (null === (e = this.CONVERSATION) || void 0 === e || null === (t = e.MESSAGE_TYPE) || void 0 === t ? void 0 : t.BOT) ? Ember.Object.create({
                            firstName: n.get("userFirstName"),
                            lastName: n.get("userLastName"),
                            id: n.get("messageUserId"),
                            alias: i,
                            profilePicUrl: n.get("messageUserProfilePic") || E.Z
                        }) : !(!i || s) && this.agentService.getAgentInfo(i)
                    }
                }),
                freshIdAgentPic: Ember.computed("currentAgent.alias", {
                    get: function() {
                        var e, t, n, i = this.currentAgent,
                            s = i && i.get("alias");
                        return null !== (e = this.hotlineUI) && void 0 !== e && null !== (t = e.config) && void 0 !== t && t.sales360App ? (0, w.freshIdAgentPicUrl)(null === (n = this.session) || void 0 === n ? void 0 : n.token, s) : ""
                    }
                }),
                showAgentBio: Ember.computed("currentAgent", {
                    get: function() {
                        return this.currentAgent.get("bio") && !this.hideBio && !this.hideName
                    }
                }),
                dropDownOpen: function() {
                    b.default.moveFocusTo(".input__search"), b.default.onDropDownOpen(".fc-emoji-picker-emoji", ".input__search", !1)
                },
                getResponseMinutes: function(e) {
                    var t, n, i, s, o, a = null === (t = this.session) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.content) || void 0 === i || null === (s = i.headers) || void 0 === s || null === (o = s.channel_response) || void 0 === o ? void 0 : o.online;
                    if (a && a.minutes) {
                        if (a.minutes.one && 1 === e) return this.replaceWithResponseTime(a.minutes.one, e);
                        if (a.minutes.more && e > 1) return this.replaceWithResponseTime(a.minutes.more, e)
                    }
                    return null
                },
                getResponseHours: function(e) {
                    var t, n, i, s, o, a = null === (t = this.session) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.content) || void 0 === i || null === (s = i.headers) || void 0 === s || null === (o = s.channel_response) || void 0 === o ? void 0 : o.online;
                    if (a && a.hours) {
                        if (a.hours.one && 1 === e) return this.replaceWithResponseTime(a.hours.one, e);
                        if (a.hours.more && e > 1) return this.replaceWithResponseTime(a.hours.more, e)
                    }
                    return null
                },
                responseTime: Ember.computed("channelResponseTime", "customResponseTime", "intl", "responseTime30Mins", "session.config.content.headers.channel_response.online", {
                    get: function() {
                        var e, t, n, i, s, o, a = this.channelResponseTime,
                            l = a && a.responseTime,
                            r = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.headers) || void 0 === i || null === (s = i.channel_response) || void 0 === s ? void 0 : s.online,
                            u = this.responseTime30Mins,
                            c = this.customResponseTime;
                        if (c) return c.customRespMsg;
                        if (l) {
                            if (l < 3600) {
                                if ((l = Math.ceil(l / 60)) > 10) {
                                    if ((o = 5 * Math.ceil(l / 5)) < 60) {
                                        var d = this.getResponseMinutes(o);
                                        return d || (u ? this.intl.t("conversation.response_time.minutes_other", {
                                            count: o
                                        }) : this.intl.t("conversation.response_time_7days.minutes_other", {
                                            count: o
                                        }))
                                    }
                                    return r && r.hours && r.hours.one ? r.hours.one : u ? this.intl.t("conversation.response_time.hours_one") : this.intl.t("conversation.response_time_7days.hours_one")
                                }
                                var p = this.getResponseMinutes(l);
                                return p || (u ? l > 1 ? this.intl.t("conversation.response_time.minutes_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time.minutes_one") : l > 1 ? this.intl.t("conversation.response_time_7days.minutes_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time_7days.minutes_one"))
                            }
                            if ((l = Math.ceil(l / 3600)) <= 2) {
                                var m = this.getResponseHours(l);
                                return m || (u ? l > 1 ? this.intl.t("conversation.response_time.hours_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time.hours_one") : l > 1 ? this.intl.t("conversation.response_time_7days.hours_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time_7days.hours_one"))
                            }
                            return r && r.hours && r.hours.more ? this.replaceWithResponseTime(r.hours.more, l) : u ? this.intl.t("conversation.response_time.more") : this.intl.t("conversation.response_time_7days.more")
                        }
                        return r && r.default
                    }
                }),
                conversationDescription: Ember.computed("intl", "isChannelOffline", "isChannelOutsideBusinessHour", "responseTime", "session.config.content.headers.channel_response.offline", {
                    get: function() {
                        var e, t, n, i, s, o = this.isChannelOutsideBusinessHour,
                            a = this.responseTime,
                            l = this.intl,
                            r = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.headers) || void 0 === i || null === (s = i.channel_response) || void 0 === s ? void 0 : s.offline,
                            u = this.isChannelOffline;
                        return o ? u ? l.t("channel.offline_message") : r ? (0, p.sanitizeHTML)(this, r, "strict") : l.t("channel.away_message") : a || null
                    }
                }),
                onConversationFetch: Ember.observer("isConversationsLoaded", (function() {
                    var e = this;
                    this.isConversationsLoaded && (this.beforeChannelEnter(), setTimeout(function() {
                        (0, s.Z)(this, e), this.scrollToBottom()
                    }.bind(this), this.transitionDelays))
                })),
                shouldDisableUserInput: Ember.computed("isConversationsLoaded", "channelInfo", "hotline.ui.userBehaviour", {
                    get: function() {
                        var e, t, n, i, o = this,
                            a = null === (e = this.channelInfo) || void 0 === e ? void 0 : e.channelId,
                            l = null === (t = this.hotline.ui) || void 0 === t || null === (n = t.userBehaviour) || void 0 === n ? void 0 : n.eventRules,
                            r = Array.isArray(l) ? l.find(function(e) {
                                var t;
                                (0, s.Z)(this, o);
                                var n = null == e || null === (t = e.command) || void 0 === t ? void 0 : t.commandValue;
                                return n && n.channelId == a && n.flowId
                            }.bind(this)) : void 0,
                            u = null === (i = this.channelInfo) || void 0 === i ? void 0 : i.flowMessages;
                        return !(!r && !u) && !this.isConversationsLoaded
                    }
                }),
                quickActionsMenu: Ember.computed("channelInfo", "showQuickActions", {
                    get: function() {
                        var e = o.default.QUICK_ACTIONS_TYPE.menu;
                        return this.getQuickActions(e)
                    }
                }),
                quickActionsSlashCommandOptions: Ember.computed("channelInfo", "showQuickActions", {
                    get: function() {
                        var e = o.default.QUICK_ACTIONS_TYPE.slashCommand;
                        return this.getQuickActions(e)
                    }
                }),
                quickActionButtons: Ember.computed("lastMessage", "showQuickActions", {
                    get: function() {
                        var e = this;
                        if (this.showQuickActions) {
                            var t, n, i, a, l = this.getMessageQuickActions(null === (t = this.lastMessage) || void 0 === t ? void 0 : t.replyFragments);
                            if (l) n = null == l || null === (i = l.sections) || void 0 === i || null === (a = i.find(function(t) {
                                return (0, s.Z)(this, e), t.name === o.default.RICH_MESSAGES.SECTION_NAMES.ACTIONS
                            }.bind(this))) || void 0 === a ? void 0 : a.fragments;
                            return n
                        }
                        return !1
                    }
                }),
                showQuickActions: Ember.computed("conversation.status", {
                    get: function() {
                        var e, t = null === (e = this.conversation) || void 0 === e ? void 0 : e.status;
                        return Ember.isEmpty(t) || t === o.default.CONVERSATION.CONVERSATION_STATUS.FREDDY_BOT || t === o.default.CONVERSATION.CONVERSATION_STATUS.BOT
                    }
                }),
                shouldHideReplyEditor: Ember.computed("lastMessage", "shouldDisableUserInput", {
                    get: function() {
                        var e = this.lastMessage;
                        return !(!e || !e.get("offlineMessage")) || (!(!e || !e.get("flowStepId") || e.get("messageType") !== o.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT) || !!this.shouldDisableUserInput)
                    }
                }),
                getPlaceholderMessage: Ember.computed("lastMessage", {
                    get: function() {
                        var e, t, n = this,
                            i = {},
                            a = null == this || null === (e = this.lastMessage) || void 0 === e ? void 0 : e.replyFragments;
                        null != a && a.length && (i = O(O({}, i = a.find(function(e) {
                            return (0, s.Z)(this, n), o.default.VALIDATION_PLACEHOLDER_MESSAGE[e.inputType]
                        }.bind(this))), o.default.VALIDATION_PLACEHOLDER_MESSAGE[null === (t = i) || void 0 === t ? void 0 : t.inputType]));
                        return i.placeholder || "conversation.ce.placeholders.default"
                    }
                }),
                isChannelOffline: Ember.computed("isChannelOutsideBusinessHour", "offlineExperienceEnabledChannel", "model.offlineExperience.offlineExpEnabled", {
                    get: function() {
                        var e, t;
                        return !!(null !== (e = this.model) && void 0 !== e && null !== (t = e.offlineExperience) && void 0 !== t && t.offlineExpEnabled && this.offlineExperienceEnabledChannel && this.isChannelOutsideBusinessHour)
                    }
                }),
                getQuickActions: function(e) {
                    var t;
                    return !!this.showQuickActions && (this.channelInfo && (null === (t = this.channelInfo.quick_actions) || void 0 === t ? void 0 : t[e]))
                },
                isAwayExperienceEligible: function() {
                    var e, t, n, i;
                    if ((null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.triggerTimerForBusinessHours) === o.default.messengerVisibilityOptions.businessHours) return !1;
                    if (this.isChannelOffline && this.offlineExperienceEnabledChannel && null !== (n = this.model) && void 0 !== n && null !== (i = n.offlineExperience) && void 0 !== i && i.offlineExpEnabled) {
                        var s = this.conversation,
                            a = this.currentConversationhasPendingCsat,
                            l = this.isLastUserMessageTimeExceeded(),
                            r = this.repliedToLastOfflineMessage,
                            u = this.currentConversationStatus,
                            c = this.conversationOfflineMessagesCount;
                        if (!s) return !0;
                        if (s && c < 1 && s && !s.conversationId) return !0;
                        if (!a && (l || u === o.default.CONVERSATION.CONVERSATION_STATUS.RESOLVED) && (r || 0 === c)) return !0
                    }
                    return !1
                },
                beforeChannelEnter: function() {
                    var e, t, n = this;
                    this.isDestroyed || this.isDestroying || this.parentView && !this.parentView.get("isOpen") || null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isConversationsLoaded && Ember.run.later(function() {
                        (0, s.Z)(this, n), this.channelEnter()
                    }.bind(this), 1)
                },
                updateUnrepliedFlowMsgs: function() {
                    var e = this,
                        t = this.messages && this.messages.filter(function(t) {
                            return (0, s.Z)(this, e), t.flowId && !t.messageId && !t.hasBeenRepliedTo
                        }.bind(this));
                    this.session && this.session.user && this.session.user.alias && !this.messagesCountWithMessageId && t.forEach(function(t) {
                        (0, s.Z)(this, e), Ember.set(t, "needsUpdation", !1)
                    }.bind(this))
                },
                channelEnter: function() {
                    var e = this;
                    if (this.hasUnrepliedFlowMessages)
                        if (this.canTriggerFlow()) this.triggerChannelEnter();
                        else {
                            var t, n = this.messages && this.messages.filter(function(t) {
                                return (0, s.Z)(this, e), t.flowId && !t.messageId && !t.hasBeenRepliedTo
                            }.bind(this));
                            (null === (t = this.channelInfo) || void 0 === t ? void 0 : t.flowId) === n.firstObject.flowId ? this.updateUnrepliedFlowMsgs() : this.triggerChannelEnter()
                        }
                    else this.isOngoingConversation || (this.hasUnrepliedOfflineMessage ? this.triggerChannelEnter() : this.currentConversationStatus !== o.default.CONVERSATION.CONVERSATION_STATUS.RESOLVED && this.messagesCountWithMessageId ? this.isAwayExperienceEligible() && (this.hasUnrepliedOfflineMessage && this.removelastOfflineMessage(), this.showAwayExperience()) : this.triggerChannelEnter())
                },
                triggerChannelEnter: function() {
                    var e;
                    if (this.hasUnrepliedFlowMessages) {
                        var t = this.unrepliedFlowMessages.firstObject && this.unrepliedFlowMessages.firstObject.autoRuleId;
                        this.removeBotMessages(t)
                    }
                    if (this.hasUnrepliedOfflineMessage && this.removelastOfflineMessage(), this.isAwayExperienceEligible()) this.showAwayExperience();
                    else if (this.channelInfo && null !== (e = this.channelInfo) && void 0 !== e && e.flowId && this.canShowChannelFlowForBusinessHourSetting) {
                        if (this.isFdInitiatedWidget()) return;
                        this.triggerChannelFlow()
                    }
                },
                triggerChannelFlow: function() {
                    var e, t, n = this,
                        i = null === (e = this.channelInfo) || void 0 === e ? void 0 : e.flowMessages,
                        a = null === (t = this.channelInfo) || void 0 === t ? void 0 : t.serviceAccount;
                    i && i.forEach(function(e) {
                        var t, i;
                        (0, s.Z)(this, n);
                        var l = e.messageFragments,
                            r = e.placeholderMeta;
                        r && this.updatePlaceholders(l, r), this.send("updateMessage", {
                            flowId: null === (t = this.channelInfo) || void 0 === t ? void 0 : t.flowId,
                            flowVersionId: null === (i = this.channelInfo) || void 0 === i ? void 0 : i.flowVersionId,
                            campaignMessageId: e.campaignMessageId,
                            flowStepId: e.flowStepId,
                            hasBeenRepliedTo: !1,
                            needsUpdation: this.getNeedUpdationValue(e),
                            messageFragments: e.messageFragments,
                            replyFragments: e.replyFragments,
                            messageUserName: a.firstName,
                            userFirstName: a.firstName,
                            messageUserType: 1,
                            internalMeta: e.internalMeta,
                            messageType: e.messageType || o.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT,
                            messageUserId: a.id,
                            messageUserAlias: a.alias,
                            read: !1,
                            createdMillis: (new Date).getTime(),
                            messageUserProfilePic: a.profilePicUrl
                        })
                    }.bind(this))
                },
                offlineExperienceEnabledChannel: Ember.computed("model.offlineExperience.channelIds.[]", "channel.channelId", {
                    get: function() {
                        var e, t, n, i = null === (e = this.model) || void 0 === e || null === (t = e.offlineExperience) || void 0 === t ? void 0 : t.channelIds,
                            s = null === (n = this.channel) || void 0 === n ? void 0 : n.channelId;
                        return i && i.find((function(e) {
                            return e === s
                        }))
                    }
                }),
                isChannelOutsideBusinessHour: Ember.computed("hotline.ui.awayMessage", "channel.operatingHoursId", {
                    get: function() {
                        var e, t, n, i = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.awayMessage,
                            s = null === (n = this.channel) || void 0 === n ? void 0 : n.operatingHoursId,
                            o = i && i.findBy("operatingHoursId", s);
                        return (!o || o && !o.enabled) && (o = i && i.findBy("defaultBhr", !0)), o && o.awayMessage
                    }
                }),
                triggerInConversationAwayExperiance: Ember.observer("isChannelOffline", "lastAgentMessage.createdMillis", "conversation.hasPendingCsat", (function() {
                    !this.isAwayExperienceEligible() || this.lastAgentMessage && !this.conversationService.isLastAgentMessageTimeExceeded(this.lastAgentMessage.createdMillis) || Ember.run.once(this, "showAwayExperience")
                })),
                showAwayExperience: function() {
                    var e, t, n, i, s, o = null === (e = this.model) || void 0 === e || null === (t = e.offlineExperience) || void 0 === t || null === (n = t.awayMessage) || void 0 === n ? void 0 : n.messageFragments,
                        a = null === (i = this.CONVERSATION) || void 0 === i || null === (s = i.MESSAGE_SOURCE) || void 0 === s ? void 0 : s.OFFLINE;
                    this.send("updateMessage", {
                        messageFragments: o,
                        messageUserType: 1,
                        messageType: 1,
                        read: !1,
                        needsUpdation: !0,
                        source: a,
                        createdMillis: (new Date).getTime(),
                        offlineMessage: !0,
                        hasBeenRepliedToOffline: !1
                    })
                },
                createText: function(e) {
                    var t = document.createElement("p");
                    t.innerHTML = "\r\n" === e || "\n" === e ? "<br>" : e, this.insertContentToEditor(t), this.set("height", this.element.offsetHeight)
                },
                channelEventReminder: Ember.computed("upcomingCalendarEventMessage", {
                    get: function() {
                        var e = this.upcomingCalendarEventMessage;
                        if (e) {
                            var t = e.internalMeta && e.internalMeta.calendarMessageMeta && e.internalMeta.calendarMessageMeta.calendarEventLink,
                                n = e.messageFragments && e.messageFragments[0],
                                i = n && n.startMillis;
                            return {
                                eventLink: t,
                                eventDateTime: i && (0, d.default)(i).format("LLL")
                            }
                        }
                        return null
                    }
                }),
                insertContentToEditor: function(e) {
                    var t = document.getElementById(this.DOM_ID.appConversationEditor);
                    t && e && t.appendChild(e)
                },
                prepopulateText: Ember.observer("hotline.ui.channelReplyText", (function() {
                    var e, t, n, i, o = this,
                        a = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.channelReplyText,
                        l = null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.channelSendMessage;
                    a && (this.emptyContentEditor(), this.set("height", this.element.offsetHeight), this.createText(a), this.set("editorHasContent", !0), this.set("hotline.ui.channelReplyText", null), Ember.run.later(this, function() {
                        (0, s.Z)(this, o), this.set("editorHasContent", !1)
                    }.bind(this)), l && (this.set("hotline.ui.channelSendMessage", !1), this.send("beforeSendMessage")))
                })),
                isCompact: Ember.computed({
                    get: function() {
                        var e, t, n, i;
                        return "small" === (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.widgetSize) || void 0 === i ? void 0 : i.toLowerCase())
                    }
                }),
                didAuthUserCB: Ember.computed("didAuthenticateUser", {
                    get: function() {
                        return this.didAuthenticateUser.bind(this)
                    }
                }),
                conversationsLoadedEventCB: Ember.computed("beforeChannelEnter", {
                    get: function() {
                        return this.beforeChannelEnter.bind(this)
                    }
                }),
                didAuthenticateUser: function() {
                    var e, t;
                    if (!this.hasUserToCreate || this.isJwtExpired() || null !== (e = this.session) && void 0 !== e && null !== (t = e.user) && void 0 !== t && t.alias || this.localStorage.getItemLS("isUserCreateSent") || this.send("createNewUser"), this.jwt.auth.expired) this.disableReplyContainer(), this.send("updateMessageAsNotAuthenticated");
                    else if (this.jwt.auth.expiredAt || this.jwt.auth.scheduled) this.enableReplyContainer();
                    else if (this.jwt.auth.user) {
                        var n, i, s, o;
                        if (this.enableReplyContainer(), null !== (n = this.hotline) && void 0 !== n && null !== (i = n.ui) && void 0 !== i && i.offlineMessagesFragments) this.send("sendOfflineMessages", null === (s = this.hotline) || void 0 === s || null === (o = s.ui) || void 0 === o ? void 0 : o.offlineMessagesFragments), this.set("hotline.ui.offlineMessagesFragments", null);
                        this.send("updateMessageAsPending"), this.send("sendPendingMessagesAfterAuthenticated")
                    }
                },
                userHeader: function(e) {
                    this.set("isFocusInput", e), e ? (0, h.addCSSInline)(this.element.querySelector(".fc-agent-profile"), "display", "none") : (0, h.addCSSInline)(this.element.querySelector(".fc-agent-profile"), "display", "block")
                },
                didUpdate: function() {
                    this._super.apply(this, arguments);
                    var e = document.querySelector(".h-reply-smiley");
                    e && ((0, h.bindEvent)(document, "selectionchange", this.setSelectionCallback), this.set("appConversationEditorNode", document.getElementById(this.DOM_ID.appConversationEditor)))
                },
                didInsertElement: function() {
                    var e, t, n = this;
                    this._super.apply(this, arguments);
                    var i = document.querySelector(".h-reply-smiley");
                    if (i && ((0, h.bindEvent)(document, "selectionchange", this.setSelectionCallback), this.set("appConversationEditorNode", document.getElementById(this.DOM_ID.appConversationEditor))), Ember.addListener(this.hotline, "conversationsLoadedEvent", this.conversationsLoadedEventCB), this.isJWTStrictMode && Ember.addListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB), Ember.run.scheduleOnce("afterRender", this, this.renderFunction), (0, h.bindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback), null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || !t.isDesktop) {
                        (0, h.bindEvent)(this.element.querySelector("#app-conversation-editor"), "focus", function() {
                            (0, s.Z)(this, n), this.userHeader(!0)
                        }.bind(this)), (0, h.bindEvent)(this.element.querySelector("#app-conversation-editor"), "blur", function() {
                            (0, s.Z)(this, n), this.userHeader(!1)
                        }.bind(this));
                        var o = window.outerHeight;
                        (0, h.bindEvent)(window, "resize", function() {
                            (0, s.Z)(this, n), this.userHeader(window.outerHeight !== o)
                        }.bind(this))
                    }
                    Ember.run.later(function() {
                        (0, s.Z)(this, n);
                        var e = document.querySelector(".custom-reply-composer div.h-reply-dropdown div.ember-basic-dropdown-trigger"),
                            t = document.querySelector(".custom-message-wrapper");
                        e ? e.focus() : t && t.focus()
                    }.bind(this), 100)
                },
                setSelectionForTextInEditor: function(e) {
                    if (this.appConversationEditorNode && e.target.activeElement.isSameNode(this.appConversationEditorNode)) {
                        var t = window.getSelection();
                        Ember.setProperties(this, {
                            sel: t,
                            range: t.getRangeAt(0)
                        })
                    }
                },
                renderFunction: function() {
                    this.scrollToBottom(), this.send("toggleView", this), "phone" !== this.hotline.device() && this.focusOnTextarea(), this.prepopulateText()
                },
                willMessageSent: function() {
                    this.lastMessage && this.lastMessage.messageUserType === o.default.CONVERSATION.USER_TYPE.USER && this.send("scrollToRecentMessages")
                },
                getMessages: (0, y.task)(regeneratorRuntime.mark((function e() {
                    var t, n, i, a, l, r, u, c, d, p, m, h, g, v, b, y, w, E = this,
                        T = arguments;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = T.length > 0 && void 0 !== T[0] ? T[0] : "", n = !(T.length > 1 && void 0 !== T[1]) || T[1], i = T.length > 2 && void 0 !== T[2] && T[2], a = o.default.EmberModelUrl, l = a.conversations, r = this.session, u = r && r.user, c = r && r.siteId, d = u && u.alias, p = r && r.token, m = this.notification, h = this.localds, g = h && h.get("messageAfter"), v = {
                                    src: o.default.CONVERSATION.FETCH.USER_CREATED,
                                    limit: o.default.CONVERSATION.LIMIT
                                }, b = l.url.replace("{token}", p).replace("{userAlias}", d), y = document.getElementsByClassName("h-conv-chat")[0], g && (v.messageAfter = g), i && (v.conversationId = t, v.messageBefore = this.messages.objectAt(0).createdMillis, v.messageAfter = 0, w = y.scrollHeight, this.set("isLoadingOldMessages", !0)), c && (b = (0, f.addQueryParams)(b, {
                                    siteId: c
                                })), e.next = 9, this.store.getRequest(l.model, b, v).then(function(e) {
                                    if ((0, s.Z)(this, E), e || !e.errorCode) {
                                        var t = e && e.conversations,
                                            o = t && t[0],
                                            a = o && o.messages;
                                        if (a)
                                            if (i)
                                                for (var l = a.length - 1; l >= 0; l--) this.send("updateMessage", a[l]);
                                            else
                                                for (var r = 0, u = a.length; r < u; r++) this.send("updateMessage", a[r]);
                                        i && (Ember.run.later(this, (function() {
                                            y.scrollTop = y.scrollHeight - w
                                        }), 0), (Ember.isEmpty(a) || a.length < 100) && this.set("isLoadedAllOlderMessages", !0)), n && m.playSound()
                                    }
                                }.bind(this)).finally(function() {
                                    (0, s.Z)(this, E), this.set("isOldConvRequestPending", !1)
                                }.bind(this));
                            case 9:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))).enqueue(),
                didMessageSent: function() {
                    this.doesUserExists || (this.set("doesUserExists", !0), this.getMessages.perform()), this.parentView && !this.parentView.get("isOpen") && this.parentView.send("toggleChat", this)
                },
                init: function() {
                    this._super.apply(this, arguments), this.setTimer = null, Ember.set(this, "showCustomReplyOptions", !1), Ember.set(this, "setSelectionCallback", this.setSelectionForTextInEditor.bind(this)), this.beforeChannelEnter()
                },
                hideCustomReplyOptions: Ember.computed.not("showCustomReplyOptions"),
                displayUnreadToastBubble: Ember.computed.and("showUnreadToast", "hideCustomReplyOptions"),
                scrollToBottom: function() {
                    var e = this,
                        t = document.querySelectorAll(".body .h-chat-window .h-conv-chat");
                    t && t.length && (v.default.scrollTo(t[0], t[t.length - 1].scrollHeight, 1), clearTimeout(this.setTimer), this.setTimer = setTimeout(function() {
                        (0, s.Z)(this, e), v.default.scrollTo(t[0], t[t.length - 1].scrollHeight, 100)
                    }.bind(this), 1e3))
                },
                focusOnTextarea: function() {
                    var e = this;
                    this.element.querySelector(".editable") ? this.focusTextArea() : Ember.run.later(this, function() {
                        (0, s.Z)(this, e), this.focusTextArea()
                    }.bind(this), 0)
                },
                focusTextArea: function() {
                    if (this.element) {
                        var e = document.createRange(),
                            t = window.getSelection(),
                            n = this.element.querySelector(".editable p:last-child");
                        if (n && n[0]) e.setStart(n[0], 1), e.collapse(!0), t.removeAllRanges(), t.addRange(e);
                        else if (this.isJWTStrictMode && this.jwt.auth.expired);
                        else {
                            var i = this.element.querySelector(".editable"),
                                s = this.lastMessage;
                            i && !this.focusAfterOfflineMessage && s && !s.get("offlineMessage") && (this.focusAfterOfflineMessage = !0), i && i.focus()
                        }
                    }
                },
                disableReplyContainer: function() {
                    var e = this.element.querySelector(".editable"),
                        t = this.element.querySelector(".away-experience-form");
                    window.getSelection().removeAllRanges(), (0, h.addCSSInline)(this.element.querySelector(".h-reply"), "pointer-events", "none"), e && (e.blur(), (0, h.addCSSInline)(e, "background-color", "grey"), (0, h.addCSSInline)(e, "pointer-events", "none")), t && (t.blur(), (0, h.addCSSInline)(t, "pointer-events", "none"))
                },
                enableReplyContainer: function() {
                    var e = this.element.querySelector(".editable"),
                        t = this.element.querySelector(".away-experience-form");
                    (0, h.addCSSInline)(this.element.querySelector(".h-reply"), "pointer-events", "auto"), e && ((0, h.addCSSInline)(e, "background-color", ""), (0, h.addCSSInline)(e, "pointer-events", "auto"), e.focus()), t && (0, h.addCSSInline)(t, "pointer-events", "auto")
                },
                replaceWithResponseTime: function(e, t) {
                    return e = (e = e.replace("{{time}}", t)).replace("{!time!}", t)
                },
                calculatePosition: function(e, t) {
                    var n = document.getElementsByClassName("fc-emoji-picker ")[0],
                        i = e.getBoundingClientRect(),
                        s = i.top,
                        o = i.left,
                        a = i.width,
                        l = document.getElementsByTagName("body")[0],
                        r = o + e.parentElement.offsetWidth - n.offsetWidth,
                        u = {
                            width: a,
                            top: s - 10
                        };
                    return "rtl" === l.getAttribute("dir") ? u.right = r : u.left = o - n.offsetWidth / 1.22, {
                        style: u
                    }
                },
                getScrollDistanceFromBottom: function() {
                    var e = document.getElementsByClassName("h-conv-chat")[0],
                        t = 0;
                    return e && (t = e.scrollHeight - (e.scrollTop + e.clientHeight)), t
                },
                unreadChanged: (0, y.task)(regeneratorRuntime.mark((function e() {
                    var t, n = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, (0, y.waitForProperty)(this, "unreadCount", function(e) {
                                    return (0, s.Z)(this, n), e > 0
                                }.bind(this));
                            case 2:
                                t = e.sent, this.parentView && this.parentView.get("isOpen") && Ember.run.later(function() {
                                    if ((0, s.Z)(this, n), t) {
                                        var e = document.getElementsByClassName("h-conv-chat")[0];
                                        e && e.scrollHeight <= e.clientHeight + 30 ? this.resetUnreadCount() : this.getScrollDistanceFromBottom() > 300 ? this.set("showUnreadToast", !0) : this.scrollToBottom()
                                    }
                                }.bind(this));
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))).on("didRender"),
                resetUnreadCount: function() {
                    Ember.set(this, "unreadCount", 0), this.send("updateReadReceipt"), this.set("showUnreadToast", !1)
                },
                actions: {
                    menuPosition: function() {
                        return {
                            style: this.isCompact ? {
                                top: "9%",
                                left: "10%"
                            } : {
                                top: "7%",
                                left: "21%"
                            }
                        }
                    },
                    setNextFocus: function() {
                        var e = document.querySelector(".fc-carousel"),
                            t = document.querySelector(".fc_web_modal");
                        event && event.keyCode === o.default.KEYCODES.TAB && !event.shiftKey && e && !t && (event.preventDefault(), e.focus())
                    },
                    emojiKeyboardEvent: function(e) {
                        b.default.hideDropDownOnFocusOut(event, e, this, ".h-reply-smiley"), b.default.changeFocusOnArrowKeyPress(event, e, {
                            sourceElem: ".input__search",
                            optionsSelector: ".fc-emoji-picker-emoji",
                            scrollContainer: ".fc-emoji-picker__body",
                            arrowTypes: "left-right",
                            isDropDown: !0
                        })
                    },
                    setAriaSelected: function() {
                        var e = document.querySelector('.fc-emoji-picker-emoji[aria-selected="true"]');
                        event.target && (e && e.setAttribute("aria-selected", !1), event.target.classList.contains("fc-emoji-picker-emoji") ? event.target.setAttribute("aria-selected", !0) : event.target.parentElement && event.target.parentElement.classList.contains("fc-emoji-picker-emoji") && event.target.parentElement.setAttribute("aria-selected", !0))
                    },
                    setIsTextLimitExceeded: function(e) {
                        this.set("isTextLimitExceeded", e)
                    },
                    hasValueInEditor: function(e) {
                        this.set("isValueInEditor", e)
                    },
                    toggleProfileSize: function() {
                        this.hideBio || this.toggleProperty("isAgentProfileExpand")
                    },
                    onOpen: function() {
                        var e = this;
                        this.beforeChannelEnter(), setTimeout(function() {
                            (0, s.Z)(this, e), this.scrollToBottom(), this.setFocus()
                        }.bind(this), this.transitionDelays)
                    },
                    toggleView: function(e) {
                        this.parentView && this.parentView.send("updateView", e)
                    },
                    toggleBack: function() {
                        var e = this;
                        Ember.run.later(function() {
                            (0, s.Z)(this, e), this.send("toggleView", void 0), this.gotoHome(), b.default.moveFocusTo(".hotline-launcher")
                        }.bind(this), 0)
                    },
                    sendButtonMessage: function(e, t) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                        b.default.moveFocusTo("#app-conversation-editor"), this.send("resizeChatWindow", !0), this.send("beforeSendMessage", e, t, n)
                    },
                    resizeChatWindow: function(e) {
                        var t, n = document.querySelector(".h-chat-window"),
                            i = null === (t = document.querySelector(".custom-reply-composer")) || void 0 === t ? void 0 : t.offsetHeight,
                            s = n.style;
                        Ember.isEmpty(i) || e || !i ? (Ember.set(this, "showCustomReplyOptions", !1), s.removeProperty("height")) : (Ember.set(this, "showCustomReplyOptions", !0), s.height = "calc(100% - " + i + "px)", this.scrollToBottom())
                    },
                    sendMessageFromMobile: function() {
                        this.set("isValueInEditor", !1);
                        var e = this.element.querySelector("#app-conversation-editor");
                        e.blur(), this.send("beforeSendMessage")
                    },
                    sendOfflineMessage: function(e) {
                        this.send("sendOfflineMessages", e)
                    },
                    openCalendarPickerMaximized: function(e) {
                        Ember.setProperties(this, {
                            slotsData: e && e.slotsData,
                            meetingLength: e && e.meetingLength,
                            showCalPicker: !0,
                            calendarMessage: e && e.message
                        })
                    },
                    closeCalendarPicker: function() {
                        this.set("showCalPicker", !1), b.default.moveFocusTo(".calendar-picker-minified")
                    },
                    openConfirmationScreenForCalPicker: function(e, t) {
                        Ember.set(t, "internalMeta.meetingStartTime", e && e.from), this.send("closeCalendarPicker")
                    },
                    setConfig: function(e) {
                        var t = e.actions;
                        this.set("dropdownActions", t)
                    },
                    updateEditorContent: function(e) {
                        var t, n = this,
                            i = document.getElementById(this.DOM_ID.appConversationEditor),
                            o = e,
                            a = this.sel,
                            l = this.range;
                        if (a.rangeCount >= 0) {
                            var r = l.startContainer,
                                u = l.startOffset,
                                c = l.cloneRange(),
                                d = document.createTextNode(o),
                                p = document.createTextNode("");
                            c.collapse(!1), c.insertNode(p), c.setStart(r, u), c.collapse(!0), c.insertNode(d), l.setStartAfter(d), l.setEndBefore(p), a.removeAllRanges(), a.addRange(l)
                        }
                        setTimeout(function() {
                            (0, s.Z)(this, n), i.focus()
                        }.bind(this)), null === (t = this.dropdownActions) || void 0 === t || t.close()
                    },
                    fetchOlderMessages: function() {
                        var e, t = null === (e = this.conversation) || void 0 === e ? void 0 : e.conversationId;
                        this.isOldConvRequestPending || this.isLoadedAllOlderMessages || !t || t < 0 ? this.logger.log("Message lazy loading cancelled.") : (this.set("isOldConvRequestPending", !0), b.default.readOutDynamicUpdates(this.intl.t("aria_labels.loading_past_conv")), this.getMessages.perform(t, !1, !0))
                    },
                    scrollToRecentMessages: function() {
                        this.scrollToBottom(), this.resetUnreadCount()
                    },
                    focusTextEditor: function() {
                        this.focusAfterOfflineMessage || (this.focusAfterOfflineMessage = !0, this.send("focusIn"))
                    }
                }
            })
        },
        95617: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return H
                }
            });
            var i, s, o, a, l, r, u, c, d, p, m, h, f, g, v, b, y, w, E, T, S = n(78933),
                C = n(1522),
                M = n(76227),
                _ = n(75330),
                O = n(55365),
                k = n(39806),
                A = n(58880),
                I = n(53234),
                N = n(63537),
                R = n(77963),
                P = n(65888),
                x = n(21951),
                D = n(81387),
                Z = n(67117),
                F = n(80033),
                B = n(43436),
                L = n(86907),
                U = n(17067),
                V = n(37271);

            function j(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, N.Z)(e);
                    if (t) {
                        var s = (0, N.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, I.Z)(this, n)
                }
            }
            var H = (i = (0, x.tagName)(""), s = Ember.inject.service("post-message"), o = Ember.computed.or("showCsat", "feedbackSubmitted"), a = Ember.computed("paramsOfPendingCsat.{flag,cross}"), l = Ember.computed("allowCsatSubmit", "csatRatings.comment"), r = Ember.computed("allowCsatSubmit", "csatRatings.star"), u = Ember.computed("session.config.content.placeholders.csat_reply"), c = Ember.computed, d = (0, D.observes)("rating_value"), p = Ember.computed("conversation.hasPendingCsat"), m = Ember.computed, h = Ember._action, f = Ember._action, g = Ember._action, v = Ember._action, b = Ember._action, i((w = function(e) {
                (0, A.Z)(n, e);
                var t = j(n);

                function n() {
                    var e;
                    (0, M.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(s)), (0, C.Z)((0, O.Z)(e), "postMessage", E, (0, O.Z)(e)), (0, R.Z)((0, O.Z)(e), "feedbackSubmitted", !1), (0, R.Z)((0, O.Z)(e), "allowCsatSubmit", !0), (0, R.Z)((0, O.Z)(e), "disableCsatVoting", !1), (0, R.Z)((0, O.Z)(e), "csatTimer", null), (0, C.Z)((0, O.Z)(e), "showCsatForm", T, (0, O.Z)(e)), e
                }
                return (0, _.Z)(n, [{
                    key: "init",
                    value: function() {
                        (0, k.Z)((0, N.Z)(n.prototype), "init", this).apply(this, arguments), Ember.set(this, "paramsOfPendingCsat", {
                            flag: null,
                            cross: null
                        })
                    }
                }, {
                    key: "isJwtAuthInProgressing",
                    get: function() {
                        var e, t;
                        return null != (null === (e = this.paramsOfPendingCsat) || void 0 === e ? void 0 : e.flag) && null != (null === (t = this.paramsOfPendingCsat) || void 0 === t ? void 0 : t.cross)
                    }
                }, {
                    key: "enableSubmitButtonForResolvedConversationNo",
                    get: function() {
                        var e;
                        return this.allowCsatSubmit && !Ember.isBlank(null === (e = this.csatRatings) || void 0 === e ? void 0 : e.comment)
                    }
                }, {
                    key: "enableSubmitButtonForResolvedConversationYes",
                    get: function() {
                        var e;
                        return this.allowCsatSubmit && (null === (e = this.csatRatings) || void 0 === e ? void 0 : e.star) > 0
                    }
                }, {
                    key: "csatComments",
                    get: function() {
                        var e, t, n, i;
                        return (null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.placeholders) || void 0 === i ? void 0 : i.csat_reply) || this.intl.t("csat.enter_comments")
                    }
                }, {
                    key: "csatRatings",
                    get: function() {
                        return this.store.createRecord("csatValues", {
                            star: 0,
                            comment: ""
                        })
                    }
                }, {
                    key: "ratingObserve",
                    value: function() {
                        var e = this.csatRatings,
                            t = this.rating_value;
                        Ember.set(e, "star", t)
                    }
                }, {
                    key: "showCsat",
                    get: function() {
                        var e, t, n = this,
                            i = this.conversation,
                            s = i && i.get("hasPendingCsat"),
                            o = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.config,
                            a = o && o.csatSettings,
                            l = i && i.get("csat"),
                            r = a && a.userCsatViewTimer,
                            u = a && a.maximumUserSurveyViewMillis,
                            c = l && l.get("initiated"),
                            d = (new Date).getTime(),
                            p = l && s ? c + u - d : 0;
                        return this.resetCsat(), r ? p > 0 ? (s && (this.csatTimer = Ember.run.later(function() {
                            (0, S.Z)(this, n), this.resetCsat(), Ember.set(i, "hasPendingCsat", !1)
                        }.bind(this), p), this.postMessage.post({
                            action: "csat_received",
                            status: 200,
                            success: !0,
                            data: {
                                csatId: l.get("csatId")
                            }
                        }), V.default.moveFocusTo(".csat-rating")), s) : (i && (Ember.set(i, "hasPendingCsat", !1), Ember.set(i, "csat", null), this.send("save")), !1) : (s && (this.postMessage.post({
                            action: "csat_received",
                            status: 200,
                            success: !0,
                            data: {
                                csatId: l.get("csatId")
                            }
                        }), V.default.moveFocusTo(".csat-rating")), s)
                    }
                }, {
                    key: "didInsertElement",
                    value: function() {
                        (0, k.Z)((0, N.Z)(n.prototype), "didInsertElement", this).apply(this, arguments), this.isJWTStrictMode && Ember.addListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB)
                    }
                }, {
                    key: "willDestroyElement",
                    value: function() {
                        (0, k.Z)((0, N.Z)(n.prototype), "willDestroyElement", this).apply(this, arguments), this.isJWTStrictMode && Ember.removeListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB)
                    }
                }, {
                    key: "didAuthUserCB",
                    get: function() {
                        return this.didAuthenticateUser.bind(this)
                    }
                }, {
                    key: "didAuthenticateUser",
                    value: function() {
                        if (this.set("disableCsatVoting", !this.jwt.auth.user), this.isJwtAuthInProgressing) {
                            var e, t;
                            if (this.jwt.auth.user) this.send("submitCsatRating", null === (e = this.paramsOfPendingCsat) || void 0 === e ? void 0 : e.flag, null === (t = this.paramsOfPendingCsat) || void 0 === t ? void 0 : t.cross);
                            this.resetParamsOfPendingCsat()
                        }
                    }
                }, {
                    key: "resetParamsOfPendingCsat",
                    value: function() {
                        this.set("paramsOfPendingCsat.flag", null), this.set("paramsOfPendingCsat.cross", null)
                    }
                }, {
                    key: "canVoteForCsat",
                    value: function() {
                        return this.jwt.auth.expiredAt || this.jwt.auth.scheduled || this.jwt.auth.expired ? (this.set("disableCsatVoting", !0), !1) : !this.isJwtExpired() || (this.initiateSendingMode(), this.set("disableCsatVoting", !0), !1)
                    }
                }, {
                    key: "resetCsat",
                    value: function() {
                        this.csatTimer && (Ember.run.cancel(this.csatTimer), this.csatTimer = null)
                    }
                }, {
                    key: "setCsatStars",
                    value: function(e) {
                        var t = this.csatRatings;
                        Ember.set(t, "star", e)
                    }
                }, {
                    key: "csatKeyboardEvent",
                    value: function(e) {
                        V.default.changeFocusOnArrowKeyPress(e, null, {
                            sourceElem: ".star-rating",
                            optionsSelector: ".star-label",
                            arrowTypes: "both",
                            isDropDown: !1,
                            isReverse: !0
                        });
                        var t = document.querySelector(".d_hotline"),
                            n = document.querySelector(".csat-rating");
                        n && e && e.keyCode === Z.default.KEYCODES.TAB && e.shiftKey && e.target === n && t && (e.preventDefault(), V.default.moveFocusTo(".d_hotline"))
                    }
                }, {
                    key: "submitCsatRating",
                    value: function(e, t) {
                        var n = this;
                        if (Ember.run.later(function() {
                                (0, S.Z)(this, n), V.default.moveFocusTo(".d_hotline")
                            }.bind(this), 1e3), e = "true" === String(e), t = "true" === String(t), this.isJWTStrictMode && !this.canVoteForCsat()) return this.set("paramsOfPendingCsat.flag", e), void this.set("paramsOfPendingCsat.cross", t);
                        this.set("allowCsatSubmit", !1);
                        var i = this.conversation,
                            s = this.csatRatings,
                            o = i.get("csat"),
                            a = this.session,
                            l = a && a.siteId,
                            r = this.localds,
                            u = Z.default.EmberModelUrl.csatRating.url.replace("{token}", a.token).replace("{conversationId}", i.get("conversationId")).replace("{csatId}", o.get("csatId")),
                            c = {
                                csatResponse: {
                                    issueResolved: e
                                }
                            };
                        t || (Ember.set(c.csatResponse, "stars", s.get("star")), Ember.set(c.csatResponse, "response", s.get("comment"))), l && (u += "?siteId=".concat(l)), this.axios.makeRequest({
                            method: "POST",
                            url: u,
                            data: c,
                            dataType: "json",
                            contentType: "application/json"
                        }).then(function(e) {
                            var a = this;
                            if ((0, S.Z)(this, n), this.set("allowCsatSubmit", !0), !e || !e.errorCode) {
                                if (t) Ember.set(i, "hasPendingCsat", !1), Ember.set(i, "resolvedConversationYes", !1), Ember.set(i, "resolvedConversationNo", !1), this.set("feedbackSubmitted", !1), Ember.set(s, "star", 0), Ember.set(s, "comment", ""), r.save(), Ember.set(i, "csat", null);
                                else {
                                    var l = "".concat(this.intl.t("csat.submitted"), ". ").concat(this.intl.t("csat.thank_you"));
                                    this.set("feedbackSubmitted", !0), V.default.readOutDynamicUpdates(l), Ember.set(i, "resolvedConversationYes", !1), Ember.set(i, "resolvedConversationNo", !1), setTimeout(function() {
                                        (0, S.Z)(this, a), this.isDestroyed && this.isDestroying || (this.set("feedbackSubmitted", !1), Ember.set(i, "hasPendingCsat", !1), Ember.set(s, "star", 0), Ember.set(s, "comment", ""), r.save(), Ember.set(i, "csat", null))
                                    }.bind(this), 2e3)
                                }
                                this.resetParamsOfPendingCsat(), Ember.set(c.csatResponse, "csatId", o.get("csatId")), Ember.set(c.csatResponse, "conversationId", i.get("conversationId")), this.postMessage.post({
                                    action: "csat_updated",
                                    status: 200,
                                    success: !0,
                                    data: {
                                        message: c
                                    }
                                })
                            }
                        }.bind(this), function(e) {
                            (0, S.Z)(this, n), this.set("allowCsatSubmit", !0), this.logger.log(e.response), Ember.set(s, "star", 0), Ember.set(s, "comment", ""), this.set("feedbackSubmitted", !1), Ember.set(i, "hasPendingCsat", !1), Ember.set(i, "resolvedConversationYes", !1), Ember.set(i, "resolvedConversationNo", !1), Ember.set(i, "csat", null), this.resetParamsOfPendingCsat(), this.postMessage.post({
                                action: "csat_updated",
                                status: 400,
                                success: !1,
                                data: {
                                    message: e.response
                                }
                            }), r.save()
                        }.bind(this))
                    }
                }, {
                    key: "csatVotingNo",
                    value: function() {
                        this.isJWTStrictMode && this.canVoteForCsat(), this.conversation.set("resolvedConversationNo", !0), V.default.moveFocusTo(".csat-rating")
                    }
                }, {
                    key: "csatVotingYes",
                    value: function() {
                        this.isJWTStrictMode && this.canVoteForCsat(), this.conversation.set("resolvedConversationYes", !0), V.default.moveFocusTo(".csat-rating")
                    }
                }]), n
            }(Ember.Component.extend(F.default, B.default, L.default, U.default)), E = (0, P.Z)(w.prototype, "postMessage", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), T = (0, P.Z)(w.prototype, "showCsatForm", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, P.Z)(w.prototype, "isJwtAuthInProgressing", [a], Object.getOwnPropertyDescriptor(w.prototype, "isJwtAuthInProgressing"), w.prototype), (0, P.Z)(w.prototype, "enableSubmitButtonForResolvedConversationNo", [l], Object.getOwnPropertyDescriptor(w.prototype, "enableSubmitButtonForResolvedConversationNo"), w.prototype), (0, P.Z)(w.prototype, "enableSubmitButtonForResolvedConversationYes", [r], Object.getOwnPropertyDescriptor(w.prototype, "enableSubmitButtonForResolvedConversationYes"), w.prototype), (0, P.Z)(w.prototype, "csatComments", [u], Object.getOwnPropertyDescriptor(w.prototype, "csatComments"), w.prototype), (0, P.Z)(w.prototype, "csatRatings", [c], Object.getOwnPropertyDescriptor(w.prototype, "csatRatings"), w.prototype), (0, P.Z)(w.prototype, "ratingObserve", [d], Object.getOwnPropertyDescriptor(w.prototype, "ratingObserve"), w.prototype), (0, P.Z)(w.prototype, "showCsat", [p], Object.getOwnPropertyDescriptor(w.prototype, "showCsat"), w.prototype), (0, P.Z)(w.prototype, "didAuthUserCB", [m], Object.getOwnPropertyDescriptor(w.prototype, "didAuthUserCB"), w.prototype), (0, P.Z)(w.prototype, "setCsatStars", [h], Object.getOwnPropertyDescriptor(w.prototype, "setCsatStars"), w.prototype), (0, P.Z)(w.prototype, "csatKeyboardEvent", [f], Object.getOwnPropertyDescriptor(w.prototype, "csatKeyboardEvent"), w.prototype), (0, P.Z)(w.prototype, "submitCsatRating", [g], Object.getOwnPropertyDescriptor(w.prototype, "submitCsatRating"), w.prototype), (0, P.Z)(w.prototype, "csatVotingNo", [v], Object.getOwnPropertyDescriptor(w.prototype, "csatVotingNo"), w.prototype), (0, P.Z)(w.prototype, "csatVotingYes", [b], Object.getOwnPropertyDescriptor(w.prototype, "csatVotingYes"), w.prototype), y = w)) || y)
        },
        40715: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return N
                }
            });
            var i, s, o, a, l, r, u, c, d, p, m, h = n(1522),
                f = n(76227),
                g = n(75330),
                v = n(55365),
                b = n(39806),
                y = n(58880),
                w = n(53234),
                E = n(63537),
                T = n(77963),
                S = n(65888),
                C = n(21951),
                M = n(8797),
                _ = n(67117),
                O = n.p + "valid_input.2fce7536ea57220d988b66cfc58d7130.svg",
                k = n.p + "invalid_input.d1bc033c6444ce115dd212169fbb0402.svg",
                A = n.p + "ic_not_sent.29dca8318044041034480959c2f29c41.svg";

            function I(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, E.Z)(e);
                    if (t) {
                        var s = (0, E.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, w.Z)(this, n)
                }
            }
            var N = (i = (0, C.classNames)("away-experience-form"), s = (0, C.classNameBindings)("isIOS:ios-device"), o = Ember.computed.readOnly("hotline.ui.isIOS"), a = Ember.computed("hotline.ui.offlineExperience.contactInfo"), l = Ember.computed("contactInfo"), r = Ember._action, u = Ember._action, c = Ember._action, i(d = s((p = function(e) {
                (0, y.Z)(n, e);
                var t = I(n);

                function n() {
                    var e;
                    (0, f.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(s)), (0, T.Z)((0, v.Z)(e), "CONVERSATION", _.default.CONVERSATION), (0, T.Z)((0, v.Z)(e), "images", {
                        ValidInput: O,
                        InvalidInput: k,
                        ICNotSent: A
                    }), (0, h.Z)((0, v.Z)(e), "isIOS", m, (0, v.Z)(e)), e
                }
                return (0, g.Z)(n, [{
                    key: "init",
                    value: function() {
                        var e, t, i, s, o, a, l, r, u, c, d, p, m, h;
                        (0, b.Z)((0, E.Z)(n.prototype), "init", this).apply(this, arguments), this.setProperties({
                            invalidContactInfo: !1,
                            invalidUserMessage: !1,
                            showValidationMark: !1,
                            offlineFormSubmitted: !1
                        }), this.set("extraParams.isOfflineSendingFailed", !1);
                        var f = (null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) || (null === (i = this.session) || void 0 === i || null === (s = i.user) || void 0 === s ? void 0 : s.workEmail),
                            g = (null === (o = this.session) || void 0 === o || null === (a = o.user) || void 0 === a ? void 0 : a.phone) || (null === (l = this.session) || void 0 === l || null === (r = l.user) || void 0 === r ? void 0 : r.workNumber);
                        (null === (u = this.hotline) || void 0 === u || null === (c = u.ui) || void 0 === c || null === (d = c.offlineExperience) || void 0 === d ? void 0 : d.contactInfo) === this.CONVERSATION.CONTACT_INFO.EMAIL && f ? ((0, M.checkReplyValidation)("email", f) && this.set("showValidationMark", !0), this.set("contactDetail", f)) : (null === (p = this.hotline) || void 0 === p || null === (m = p.ui) || void 0 === m || null === (h = m.offlineExperience) || void 0 === h ? void 0 : h.contactInfo) === this.CONVERSATION.CONTACT_INFO.PHONE && g && ((0, M.checkReplyValidation)("phone", g) && this.set("showValidationMark", !0), this.set("contactDetail", g))
                    }
                }, {
                    key: "contactInfo",
                    get: function() {
                        var e, t, n;
                        return 0 === (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.offlineExperience) || void 0 === n ? void 0 : n.contactInfo) ? "email" : "phone"
                    }
                }, {
                    key: "contactInfoPlaceholder",
                    get: function() {
                        return "email" === this.contactInfo ? this.intl.t("away_experience.your_email") : this.intl.t("away_experience.your_phone")
                    }
                }, {
                    key: "createMessageFragment",
                    value: function(e) {
                        return {
                            fragmentType: this.CONVERSATION.FRAGMENT_TYPE.TEXT,
                            contentType: "text/html",
                            content: e.trim()
                        }
                    }
                }, {
                    key: "validateOfflineForm",
                    value: function(e, t) {
                        var n = this.contactInfo,
                            i = (0, M.checkReplyValidation)(n, e);
                        return t || i ? t ? !!i || (this.set("invalidContactInfo", !0), !1) : (this.set("invalidUserMessage", !0), this.element.querySelector(".user-message-reply").focus(), !1) : (this.set("invalidUserMessage", !0), this.set("invalidContactInfo", !0), this.element.querySelector(".user-message-reply").focus(), !1)
                    }
                }, {
                    key: "validateContactInfo",
                    value: function() {
                        var e = this.contactInfo,
                            t = this.contactDetail,
                            n = (0, M.checkReplyValidation)(e, t);
                        this.set("showValidationMark", n), n && this.set("invalidContactInfo", !1)
                    }
                }, {
                    key: "validateUserMessage",
                    value: function() {
                        this.userMessage && this.invalidUserMessage && this.set("invalidUserMessage", !1)
                    }
                }, {
                    key: "sendMessages",
                    value: function() {
                        var e = this.contactDetail,
                            t = this.userMessage;
                        if (this.validateOfflineForm(e, t)) {
                            this.set("offlineFormSubmitted", !0), "email" === this.contactInfo && this.set("session.user.email", e);
                            var n = this.createMessageFragment(e),
                                i = this.createMessageFragment(t),
                                s = [];
                            s.push(n), s.push(i), this.sendOfflineMessage(s)
                        }
                    }
                }]), n
            }(Ember.Component), m = (0, S.Z)(p.prototype, "isIOS", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, S.Z)(p.prototype, "contactInfo", [a], Object.getOwnPropertyDescriptor(p.prototype, "contactInfo"), p.prototype), (0, S.Z)(p.prototype, "contactInfoPlaceholder", [l], Object.getOwnPropertyDescriptor(p.prototype, "contactInfoPlaceholder"), p.prototype), (0, S.Z)(p.prototype, "validateContactInfo", [r], Object.getOwnPropertyDescriptor(p.prototype, "validateContactInfo"), p.prototype), (0, S.Z)(p.prototype, "validateUserMessage", [u], Object.getOwnPropertyDescriptor(p.prototype, "validateUserMessage"), p.prototype), (0, S.Z)(p.prototype, "sendMessages", [c], Object.getOwnPropertyDescriptor(p.prototype, "sendMessages"), p.prototype), d = p)) || d) || d)
        },
        15567: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return d
                }
            });
            var i = n(78933),
                s = n(67117),
                o = n(80033),
                a = n(62588),
                l = n(37271),
                r = n.p + "dropdown_arrow.77949ef85f5f93473c2d5a6e78e18856.svg",
                u = n(1469),
                c = n(48919),
                d = Ember.Component.extend(o.default, a.default, {
                    PLACEHOLDERS: s.default.CONVERSATION.PLACEHOLDERS,
                    CONVERSATION: s.default.CONVERSATION,
                    DOM_ID: s.default.DOM_ID,
                    classNames: ["h-reply-button", "custom-message-wrapper"],
                    attributeBindings: ["tabindex"],
                    tabindex: "-1",
                    classNameBindings: ["dropdownOptions.length:h-reply-dropdown"],
                    images: Ember.Object.create({
                        DropdownArrow: r,
                        TickFeedbackSubmitted: c.Z
                    }),
                    customButtonComposer: Ember.computed("message", {
                        get: function() {
                            var e = this,
                                t = this.getReplyCollectionFragments();
                            return t && t.filter(function(t) {
                                return (0, i.Z)(this, e), t.fragmentType !== this.CONVERSATION.FRAGMENT_TYPE.TEXT && t.fragmentType !== this.CONVERSATION.FRAGMENT_TYPE.HELP_TEXT ? t : null
                            }.bind(this))
                        }
                    }),
                    isFeedbackReplyMessage: Ember.computed("message", {
                        get: function() {
                            var e;
                            return null == this || null === (e = this.message) || void 0 === e ? void 0 : e.isFeedbackResponse
                        }
                    }),
                    customTextComposer: Ember.computed("this.message.replyFragments", {
                        get: function() {
                            var e = this,
                                t = this.getReplyCollectionFragments();
                            return t && t.filter(function(t) {
                                return (0, i.Z)(this, e), t.fragmentType === this.CONVERSATION.FRAGMENT_TYPE.TEXT ? t : null
                            }.bind(this))
                        }
                    }),
                    articleFeedbackComposer: Ember.computed("message", {
                        get: function() {
                            var e = this,
                                t = this.getArticleFeedbackFragments();
                            return t && t.filter(function(t) {
                                return (0, i.Z)(this, e), t.fragmentType !== this.CONVERSATION.FRAGMENT_TYPE.TEXT ? t : null
                            }.bind(this))
                        }
                    }),
                    dropdownOptions: Ember.computed("message", {
                        get: function() {
                            var e, t = this,
                                n = null === (e = this.message) || void 0 === e ? void 0 : e.replyFragments;
                            if (null != n && n.length && this.isDropDownMessage(n)) {
                                var o, a = null === (o = n[0]) || void 0 === o ? void 0 : o.sections;
                                if (!a || !a.length) return [];
                                var l = a.find(function(e) {
                                    return (0, i.Z)(this, t), e.name === s.default.RICH_MESSAGES.SECTION_NAMES.OPTIONS
                                }.bind(this));
                                return null == l ? void 0 : l.fragments
                            }
                            return []
                        }
                    }),
                    getArticleFeedbackFragments: function() {
                        var e = this.message;
                        if (e && e.get("messageFragments") && e.get("messageFragments").length > 0 && e.get("messageFragments.lastObject.fragments")) {
                            var t = e.get("messageFragments.lastObject.fragments");
                            return t.length > 0 ? t : null
                        }
                    },
                    getReplyCollectionFragments: function() {
                        var e = this.message;
                        if (e && e.get("replyFragments") && e.get("replyFragments").length > 0) {
                            var t = e.get("replyFragments");
                            return t.length > 0 ? t[0].fragments : null
                        }
                    },
                    didInsertElement: function() {
                        var e = this;
                        this._super.apply(this, arguments), Ember.run.later(function() {
                            (0, i.Z)(this, e), this.setChatWindowHeight(!1)
                        }.bind(this))
                    },
                    willDestroyElement: function() {
                        this._super.apply(this, arguments), this.setChatWindowHeight(!0)
                    },
                    didRender: function() {
                        this._super.apply(this, arguments), this.resizeChatWindow()
                    },
                    onOpen: function() {
                        l.default.onDropDownOpen(".drop-down-list", ".channel-list", !0)
                    },
                    calculatePosition: function(e, t) {
                        var n = e.getBoundingClientRect(),
                            i = n.top,
                            s = n.left,
                            o = n.width,
                            a = n.height;
                        return {
                            style: {
                                left: s,
                                width: o,
                                top: i - (t.getBoundingClientRect().height - a) - 5
                            }
                        }
                    },
                    carousel: Ember.computed("message", {
                        get: function() {
                            var e, t = this,
                                n = {
                                    title: null,
                                    cards: []
                                },
                                o = null === (e = this.message) || void 0 === e ? void 0 : e.replyFragments;
                            if (null != o && o.length && this.isCarouselMessage(o)) {
                                var a = o[0],
                                    l = null == a ? void 0 : a.sections;
                                if (!l || !l.length) return n;
                                var r = l.find(function(e) {
                                        return (0, i.Z)(this, t), e.name === s.default.RICH_MESSAGES.SECTION_NAMES.CAROUSEL_TITLE
                                    }.bind(this)),
                                    u = l.find(function(e) {
                                        return (0, i.Z)(this, t), e.name === s.default.RICH_MESSAGES.SECTION_NAMES.CARDS
                                    }.bind(this));
                                n.title = null == r ? void 0 : r.fragments, n.cards = null == u ? void 0 : u.fragments
                            }
                            return n
                        }
                    }),
                    feedbackData: Ember.computed("message", {
                        get: function() {
                            var e, t, n, i, o, a, l, r, u = null === (e = this.message) || void 0 === e ? void 0 : e.replyFragments,
                                c = null == u || null === (t = u[0]) || void 0 === t ? void 0 : t.templateType,
                                d = null == u || null === (n = u[0]) || void 0 === n || null === (i = n.sections) || void 0 === i || null === (o = i[0]) || void 0 === o ? void 0 : o.fragments;
                            if (null != d && d.length) switch (c) {
                                case null === s.default || void 0 === s.default || null === (a = s.default.TemplateType) || void 0 === a ? void 0:
                                    a.FEEDBACK_RATING: return {
                                        content: d.reverse(),
                                        feedbackType: c
                                    };
                                case null === s.default || void 0 === s.default || null === (l = s.default.TemplateType) || void 0 === l ? void 0:
                                    l.FEEDBACK_OPINION_POLL:
                                        case null === s.default || void 0 === s.default || null === (r = s.default.TemplateType) || void 0 === r ? void 0:
                                    r.FEEDBACK_COMMENT: return {
                                        content: d,
                                        feedbackType: c
                                    }
                            }
                            return null
                        }
                    }),
                    actions: {
                        dropDownKeyboardEvent: function(e) {
                            l.default.hideDropDownOnFocusOut(event, e), l.default.changeFocusOnArrowKeyPress(event, e, {
                                sourceElem: ".channel-list",
                                optionsSelector: ".drop-down-list",
                                arrowTypes: "up-down",
                                isDropDown: !0
                            })
                        },
                        setNextFocus: function() {
                            var e = document.querySelector(".ic-back"),
                                t = document.querySelector(".fc-carousel");
                            event && event.target === t && event.keyCode === s.default.KEYCODES.TAB && event.shiftKey && e && (event.preventDefault(), e.focus())
                        },
                        dropdownSelectionHandler: function(e) {
                            this.set("disableDropdown", !0);
                            var t = [e],
                                n = {
                                    replyTo: {
                                        originalMessageId: this.message.messageId
                                    }
                                };
                            this.sendButtonMessage(t, n)
                        },
                        carouselSelectionHandler: function(e) {
                            var t = [e],
                                n = {
                                    replyTo: {
                                        originalMessageId: this.message.messageId
                                    }
                                };
                            this.sendButtonMessage(t, n)
                        },
                        feedbackSelectionHandler: function(e) {
                            var t = [e];
                            this.sendButtonMessage(t, {})
                        },
                        sendButtonMessage: function(e, t) {
                            this.sendButtonMessage(e, t)
                        },
                        triggerSendButtonMessage: function(e, t) {
                            this.sendButtonMessage(e, t, this.DOM_ID.appReplyComposerEditor)
                        },
                        keyPressDownLocal: function(e, t) {
                            if (13 === t.which) t.preventDefault(), (0, u.isSlashCmdMenuVisible)() || this.sendButtonMessage(null, null, this.DOM_ID.appReplyComposerEditor)
                        },
                        setIsTextLimitExceeded: function() {}
                    }
                })
        },
        42350: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                }
            });
            var i = n(56428)
        },
        14380: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                }
            });
            var i = n(34398)
        },
        53914: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return g
                }
            });
            var i, s = n(76227),
                o = n(75330),
                a = n(55365),
                l = n(39806),
                r = n(58880),
                u = n(53234),
                c = n(63537),
                d = n(77963),
                p = n(21951),
                m = n(67117),
                h = n(30094);

            function f(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, c.Z)(e);
                    if (t) {
                        var s = (0, c.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, u.Z)(this, n)
                }
            }
            var g = (0, p.attributeBindings)("accept")(i = function(e) {
                (0, r.Z)(n, e);
                var t = f(n);

                function n() {
                    var e;
                    (0, s.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), l = 0; l < i; l++) o[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(o)), (0, d.Z)((0, a.Z)(e), "type", "file"), (0, d.Z)((0, a.Z)(e), "accept", "file"), (0, d.Z)((0, a.Z)(e), "multiple", !1), e
                }
                return (0, o.Z)(n, [{
                    key: "init",
                    value: function() {
                        (0, l.Z)((0, c.Z)(n.prototype), "init", this).apply(this, arguments);
                        var e = this.allowedFileTypes;
                        e && Ember.set(this, "accept", e)
                    }
                }, {
                    key: "getFileType",
                    value: function(e) {
                        var t, n = this.isAttachment,
                            i = this.allowedFileTypes,
                            s = this.blockedFileTypes,
                            o = i && i.split(",") || [],
                            a = s && s.split(",") || [],
                            l = e && e.lastIndexOf("."),
                            r = e && l >= 0 && e.substr(l) || "";
                        return r = r.toLowerCase(), h.default.checkValidFileExtension(r) && e && r ? (t = m.default.SupportedImageFileExtensions[r] ? m.default.FILETYPE.IMAGE : m.default.FILETYPE.FILE, t = n ? m.default.FILETYPE.FILE : t, i ? o.indexOf(r) >= 0 ? t : m.default.FILETYPE.INVALID : s && a.indexOf(r) >= 0 ? m.default.FILETYPE.INVALID : t) : m.default.FILETYPE.INVALID
                    }
                }, {
                    key: "isSupportedFileSize",
                    value: function(e, t) {
                        var n = this.attr || {},
                            i = n && n.size || (t === m.default.FILETYPE.IMAGE ? m.default.ImageAttr.size : m.default.FileAttr.size),
                            s = e.size <= i;
                        return s || this.set("parentView.content", {
                            error: this.intl.t("file_attachment_errors.invalid_file_size", {
                                attributeSize: i / 1048576
                            }),
                            timestamp: (new Date).getTime()
                        }), s
                    }
                }, {
                    key: "processFile",
                    value: function(e, t) {
                        var n = {
                            fileType: t,
                            fileData: e,
                            timestamp: (new Date).getTime(),
                            isShared: this.isShared,
                            markForQuickAccess: this.markForQuickAccess
                        };
                        this.set("parentView.content", n), this.set("imageData", n)
                    }
                }, {
                    key: "processImageFile",
                    value: function(e, t) {
                        var n = this,
                            i = this.attr || {},
                            s = new FileReader,
                            o = new Image;
                        s.onload = function(s) {
                            var a, l = s.target.result;
                            (i.width || i.height) && (o.src = l, o.onload = function() {
                                (this.width > i.width || this.height > i.height) && n.set("parentView.content", {
                                    error: n.get("intl").t("file_attachment_errors.invalid_image_resolution", {
                                        width: i.width,
                                        height: i.height
                                    }),
                                    timestamp: (new Date).getTime()
                                })
                            }), a = {
                                fileType: t,
                                fileData: e,
                                timestamp: (new Date).getTime(),
                                data: l,
                                attr: {
                                    width: this.width,
                                    height: this.height
                                }
                            }, n.set("parentView.content", a), n.set("imageData", a)
                        }, s.readAsDataURL(e)
                    }
                }, {
                    key: "change",
                    value: function(e) {
                        for (var t = e && e.target && e.target.files || [], n = t.length || 0, i = 0; i < n; i++) {
                            var s = t[i],
                                o = this.getFileType(s.name);
                            o !== m.default.FILETYPE.INVALID ? this.isSupportedFileSize(s, o) && (o === m.default.FILETYPE.FILE ? this.processFile(s, o) : o === m.default.FILETYPE.IMAGE && this.processImageFile(s, o)) : this.set("parentView.content", {
                                error: this.intl.t("file_attachment_errors.invalid_file_extension"),
                                timestamp: (new Date).getTime()
                            })
                        }
                        e.target.value = ""
                    }
                }]), n
            }(Ember.TextField)) || i
        },
        77373: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return b
                }
            });
            var i, s, o, a, l, r = n(76227),
                u = n(75330),
                c = n(55365),
                d = n(58880),
                p = n(53234),
                m = n(63537),
                h = n(77963),
                f = n(65888),
                g = n(21951);

            function v(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, m.Z)(e);
                    if (t) {
                        var s = (0, m.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, p.Z)(this, n)
                }
            }
            var b = (i = (0, g.tagName)("input"), s = (0, g.attributeBindings)("type", "id", "name", "value", "checked", "tabIndex:tabindex", "ariaHidden:aria-hidden"), o = Ember.computed("group", "value"), i(a = s((l = function(e) {
                (0, d.Z)(n, e);
                var t = v(n);

                function n() {
                    var e;
                    (0, r.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(s)), (0, h.Z)((0, c.Z)(e), "type", "radio"), e
                }
                return (0, u.Z)(n, [{
                    key: "checked",
                    get: function() {
                        return this.group === this.value
                    }
                }, {
                    key: "change",
                    value: function() {
                        this.group !== this.value && Ember.run.once(this, "changed")
                    }
                }, {
                    key: "changed",
                    value: function() {
                        this.onchange(this.value)
                    }
                }]), n
            }(Ember.Component), (0, f.Z)(l.prototype, "checked", [o], Object.getOwnPropertyDescriptor(l.prototype, "checked"), l.prototype), a = l)) || a) || a)
        },
        68689: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return M
                }
            });
            var i, s, o, a, l, r, u, c = n(78933),
                d = n(1522),
                p = n(76227),
                m = n(75330),
                h = n(55365),
                f = n(39806),
                g = n(58880),
                v = n(53234),
                b = n(63537),
                y = n(77963),
                w = n(65888),
                E = n(54393),
                T = n(67117),
                S = n(23798);

            function C(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, b.Z)(e);
                    if (t) {
                        var s = (0, b.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, v.Z)(this, n)
                }
            }
            var M = (i = Ember._tracked, s = Ember.inject.service, o = Ember.inject.service, a = function(e) {
                (0, g.Z)(n, e);
                var t = C(n);

                function n(e, i) {
                    var s;
                    return (0, p.Z)(this, n), s = t.call(this, e, i), (0, d.Z)((0, h.Z)(s), "isAgentTyping", l, (0, h.Z)(s)), (0, y.Z)((0, h.Z)(s), "agentThread", void 0), (0, y.Z)((0, h.Z)(s), "freddyThread", void 0), (0, y.Z)((0, h.Z)(s), "chatWindow", document.querySelector(".h-conv-chat")), (0, y.Z)((0, h.Z)(s), "onRTSMessageCB", s.onRTSMessage.bind((0, h.Z)(s))), (0, d.Z)((0, h.Z)(s), "rts", r, (0, h.Z)(s)), (0, d.Z)((0, h.Z)(s), "session", u, (0, h.Z)(s)), Ember.addListener(s.rts, "didRTSMessage", s.onRTSMessageCB), s
                }
                return (0, m.Z)(n, [{
                    key: "channelId",
                    get: function() {
                        var e;
                        return null !== (e = this.args.channelId) && void 0 !== e ? e : void 0
                    }
                }, {
                    key: "willDestroy",
                    value: function() {
                        (0, f.Z)((0, b.Z)(n.prototype), "willDestroy", this).apply(this, arguments), Ember.removeListener(this.rts, "didRTSMessage", this.onRTSMessageCB)
                    }
                }, {
                    key: "hideTypingIndicator",
                    value: function() {
                        var e = this.agentThread,
                            t = this.freddyThread;
                        this.isAgentTyping = !1, e && clearTimeout(e), t && clearTimeout(t)
                    }
                }, {
                    key: "showTypingIndicator",
                    value: function(e) {
                        var t = this,
                            n = this.chatWindow,
                            i = this.agentThread;
                        this.isAgentTyping = !0, n && n.scrollTop >= n.scrollHeight - n.offsetHeight - 30 && !document.querySelector(".h-conv-chat .notification-container") && S.default.scrollTo(n, n.scrollHeight, 1500), i && clearTimeout(i), this.agentThread = setTimeout(function() {
                            (0, c.Z)(this, t), this.isDestroying || this.isDestroyed || (this.isAgentTyping = !1)
                        }.bind(this), e)
                    }
                }, {
                    key: "onRTSMessage",
                    value: function(e) {
                        var t = this,
                            n = e && e.userId,
                            i = this.channelId,
                            s = this.session.user.id;
                        if ("is_typing" === e.action && e.channelId && e.channelId === i && s && s !== parseInt(n, 10)) this.showTypingIndicator(T.default.TYPING_INDICATOR_DURATION.AGENT);
                        else if ("MESSAGE_RECEIVED" === e.type && e.conversation && e.conversation.channelId === i) {
                            s === (e.conversation && e.conversation.messages && e.conversation.messages.length && e.conversation.messages[0].messageUserId) ? e.conversation && e.conversation.status === T.default.CONVERSATION.CONVERSATION_STATUS.FREDDY_BOT && (this.hideTypingIndicator(), this.freddyThread = setTimeout(function() {
                                (0, c.Z)(this, t), this.showTypingIndicator(T.default.TYPING_INDICATOR_DURATION.FREDDY_BOT)
                            }.bind(this), 1e3)) : this.hideTypingIndicator()
                        }
                    }
                }]), n
            }(E.default), l = (0, w.Z)(a.prototype, "isAgentTyping", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }), r = (0, w.Z)(a.prototype, "rts", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), u = (0, w.Z)(a.prototype, "session", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), a)
        },
        75841: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return A
                }
            });
            var i, s, o, a, l, r, u, c, d, p, m = n(78933),
                h = n(76227),
                f = n(75330),
                g = n(58880),
                v = n(53234),
                b = n(63537),
                y = n(65888),
                w = n(21951),
                E = n(8797),
                T = n(67117),
                S = n(86907),
                C = n(1894),
                M = n(8543),
                _ = n(46377);

            function O(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, b.Z)(e);
                    if (t) {
                        var s = (0, b.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, v.Z)(this, n)
                }
            }
            var k = T.default.CONVERSATION,
                A = (i = (0, w.tagName)("button"), s = (0, w.classNames)("h-img-button"), o = (0, w.attributeBindings)("data-test-id", "title"), a = Ember.computed, l = Ember._action, r = Ember._action, u = Ember._action, c = Ember._action, i(d = s(d = o((p = function(e) {
                    (0, g.Z)(n, e);
                    var t = O(n);

                    function n() {
                        return (0, h.Z)(this, n), t.apply(this, arguments)
                    }
                    return (0, f.Z)(n, [{
                        key: "generatedHTML",
                        get: function() {
                            var e, t, n = (0, _.sanitizeHTML)(this, this.model.label, "strict"),
                                i = null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isDesktop ? (0, C.default)(n, M.default.EmberENV.cdnUrl) : n;
                            return Ember.String.htmlSafe(i)
                        }
                    }, {
                        key: "click",
                        value: function(e) {
                            e.preventDefault();
                            var t = this.model;
                            switch (t.fragmentType) {
                                case k.FRAGMENT_TYPE.QUICKREPLY:
                                    this.send("sendReplyMessage", t.customReplyText || t.label);
                                    break;
                                case k.FRAGMENT_TYPE.CALLBACK:
                                    this.performArticleFeedbackCallback(t), this.send("sendReplyMessage", t.label, k.MESSAGE_TYPE.FEEDBACK_RESPONSE);
                                    break;
                                case k.FRAGMENT_TYPE.BUTTON:
                                    "_blank" === t.target ? this.send("openExternalTab", t.content) : "_self" === t.target ? this.send("openExternalLink", t.content) : this.send("openInternalLink", t.content)
                            }
                        }
                    }, {
                        key: "openExternalTab",
                        value: function(e) {
                            window.open(e, "_blank")
                        }
                    }, {
                        key: "openInternalLink",
                        value: function(e) {
                            var t;
                            if (null !== (t = this.session) && void 0 !== t && t.isKbaseEnabled) {
                                var n = {
                                    articleId: (0, E.getParameterByName)("article_id", e),
                                    categoryId: (0, E.getParameterByName)("category_id", e)
                                };
                                this.router.send("gotoFAQArticle", n)
                            } else {
                                var i, s, o = null === (i = this.faqs) || void 0 === i ? void 0 : i.content.serialize();
                                o && (s = (0, E.getArticleToShow)(o.dsCategories, e)) && this.router.send("gotoFAQArticle", s)
                            }
                        }
                    }, {
                        key: "openExternalLink",
                        value: function(e) {
                            var t, n = null === (t = this.hotline) || void 0 === t ? void 0 : t.ui;
                            Ember.set(n, "modalOpen", !0), Ember.set(n, "modal", {
                                thirdPartyURL: e,
                                title: ""
                            }), Ember.set(n, "openArticleFromMessage", !0)
                        }
                    }, {
                        key: "sendReplyMessage",
                        value: function(e, t) {
                            var n = [{
                                fragmentType: k.FRAGMENT_TYPE.TEXT,
                                contentType: "text/html",
                                content: e
                            }];
                            this.sendButtonMessage(n, t ? {
                                messageType: t
                            } : null)
                        }
                    }, {
                        key: "performArticleFeedbackCallback",
                        value: function(e) {
                            var t, n, i = this,
                                s = this.message && (null === (t = this.message) || void 0 === t ? void 0 : t.alias),
                                o = T.default.EmberModelUrl.getTemplateArticle.postBackURL;
                            o = o.replace("{token}", null === (n = this.session) || void 0 === n ? void 0 : n.token).replace("{messageAlias}", s).replace("/{referenceId}", ""), this.axios.makeRequest({
                                method: "POST",
                                url: o,
                                contentType: "application/json",
                                data: e
                            }).then(function(e) {
                                (0, m.Z)(this, i), this.logger.log(e)
                            }.bind(this), function(e) {
                                (0, m.Z)(this, i), this.logger.log(e && e.response)
                            }.bind(this))
                        }
                    }]), n
                }(Ember.Component.extend(T.default, S.default)), (0, y.Z)(p.prototype, "generatedHTML", [a], Object.getOwnPropertyDescriptor(p.prototype, "generatedHTML"), p.prototype), (0, y.Z)(p.prototype, "openExternalTab", [l], Object.getOwnPropertyDescriptor(p.prototype, "openExternalTab"), p.prototype), (0, y.Z)(p.prototype, "openInternalLink", [r], Object.getOwnPropertyDescriptor(p.prototype, "openInternalLink"), p.prototype), (0, y.Z)(p.prototype, "openExternalLink", [u], Object.getOwnPropertyDescriptor(p.prototype, "openExternalLink"), p.prototype), (0, y.Z)(p.prototype, "sendReplyMessage", [c], Object.getOwnPropertyDescriptor(p.prototype, "sendReplyMessage"), p.prototype), d = p)) || d) || d) || d)
        },
        45498: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return h
                }
            });
            var i, s, o, a = n(76227),
                l = n(75330),
                r = n(58880),
                u = n(53234),
                c = n(63537),
                d = n(65888),
                p = n(37271);

            function m(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, c.Z)(e);
                    if (t) {
                        var s = (0, c.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, u.Z)(this, n)
                }
            }
            var h = (i = Ember.computed("model"), s = Ember._action, o = function(e) {
                (0, r.Z)(n, e);
                var t = m(n);

                function n() {
                    return (0, a.Z)(this, n), t.apply(this, arguments)
                }
                return (0, l.Z)(n, [{
                    key: "daysWithSlotsAsQuads",
                    get: function() {
                        for (var e = [], t = this.model, n = t && t.get("length"), i = 0; i < n; i++) {
                            var s = t.objectAt(i),
                                o = s && s.morningSlots,
                                a = s && s.afternoonSlots,
                                l = s && s.eveningSlots,
                                r = s && s.nightSlots,
                                u = {
                                    date: s.date,
                                    weekday: s.weekday
                                };
                            o && (u.morningSlots = this.convertSlotsIntoQuads(o), u.morningSlotsCount = o.length), a && (u.afternoonSlots = this.convertSlotsIntoQuads(a), u.afternoonSlotsCount = a.length), l && (u.eveningSlots = this.convertSlotsIntoQuads(l), u.eveningSlotsCount = l.length), r && (u.nightSlots = this.convertSlotsIntoQuads(r), u.nightSlotsCount = r.length), e.push(u)
                        }
                        return e
                    }
                }, {
                    key: "convertSlotsIntoQuads",
                    value: function(e) {
                        for (var t = e && e.length, n = [], i = 0; i < t; i += 4) t >= i + 4 ? n.push([e[i], e[i + 1], e[i + 2], e[i + 3]]) : t === i + 3 ? n.push([e[i], e[i + 1], e[i + 2]]) : t === i + 2 ? n.push([e[i], e[i + 1]]) : n.push([e[i]]);
                        return n
                    }
                }, {
                    key: "openConfirmationView",
                    value: function(e) {
                        this.openConfirmationScreen(e), p.default.moveFocusTo(".calendar-picker-minified")
                    }
                }]), n
            }(Ember.Component), (0, d.Z)(o.prototype, "daysWithSlotsAsQuads", [i], Object.getOwnPropertyDescriptor(o.prototype, "daysWithSlotsAsQuads"), o.prototype), (0, d.Z)(o.prototype, "openConfirmationView", [s], Object.getOwnPropertyDescriptor(o.prototype, "openConfirmationView"), o.prototype), o)
        },
        2177: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return C
                }
            });
            var i, s, o, a, l, r, u, c, d, p = n(76227),
                m = n(75330),
                h = n(55365),
                f = n(58880),
                g = n(53234),
                v = n(63537),
                b = n(77963),
                y = n(65888),
                w = n(21951),
                E = n(67117),
                T = n(68921);

            function S(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, v.Z)(e);
                    if (t) {
                        var s = (0, v.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, g.Z)(this, n)
                }
            }
            var C = (i = (0, w.classNames)("cal-picker-weekday"), s = Ember.computed("isLoading"), o = Ember.computed("slotsForMinifiedView.{session,slots}"), a = Ember.computed("slotsForMinifiedView.session"), l = Ember.computed("slotsForMinifiedView.slots"), r = Ember.computed("model"), u = Ember._action, i((d = function(e) {
                (0, f.Z)(n, e);
                var t = S(n);

                function n() {
                    var e;
                    (0, p.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(s)), (0, b.Z)((0, h.Z)(e), "CALENDAR", E.default.CALENDAR), e
                }
                return (0, m.Z)(n, [{
                    key: "mockSlots",
                    get: function() {
                        return [
                            [1, 2, 3],
                            [4, 5]
                        ]
                    }
                }, {
                    key: "tripletSessionWithCount",
                    get: function() {
                        var e = this.slotsForMinifiedView,
                            t = e && e.session,
                            n = "",
                            i = (e && e.slots).length;
                        return t === E.default.CALENDAR.SESSIONS.MORNING ? n = this.intl.t("calendar.morn") : t === E.default.CALENDAR.SESSIONS.AFTERNOON ? n = this.intl.t("calendar.afternoon") : t === E.default.CALENDAR.SESSIONS.EVENING ? n = this.intl.t("calendar.evening") : t === E.default.CALENDAR.SESSIONS.NIGHT && (n = this.intl.t("calendar.night")), n + "(" + i + ")"
                    }
                }, {
                    key: "tripletSessionIconClass",
                    get: function() {
                        var e = this.slotsForMinifiedView.session;
                        return e && this.getCSSClassForSession(e)
                    }
                }, {
                    key: "slotsAsTriplets",
                    get: function() {
                        for (var e, t = null === (e = this.slotsForMinifiedView) || void 0 === e ? void 0 : e.slots, n = t && t.length, i = [], s = 0; s < n; s += 3) n >= s + 3 ? i.push([t[s], t[s + 1], t[s + 2]]) : n === s + 2 ? i.push([t[s], t[s + 1]]) : i.push([t[s]]);
                        return i
                    }
                }, {
                    key: "slotsForMinifiedView",
                    get: function() {
                        return this.getFirstAvailableSessionFromDayObject(this.model)
                    }
                }, {
                    key: "getFirstAvailableSessionFromDayObject",
                    value: function(e) {
                        var t;
                        if (e) return e.morningSlots ? t = {
                            session: E.default.CALENDAR.SESSIONS.MORNING,
                            slots: e.morningSlots
                        } : e.afternoonSlots ? t = {
                            slots: e.afternoonSlots,
                            session: E.default.CALENDAR.SESSIONS.AFTERNOON
                        } : e.eveningSlots ? t = {
                            slots: e.eveningSlots,
                            session: E.default.CALENDAR.SESSIONS.EVENING
                        } : e.nightSlots && (t = {
                            slots: e.nightSlots,
                            session: E.default.CALENDAR.SESSIONS.NIGHT
                        }), t.slots && t.slots.length > 6 && (t.slots = t.slots.slice(0, 6)), t
                    }
                }, {
                    key: "bookSlot",
                    value: function(e) {
                        this.setSlot(e)
                    }
                }]), n
            }(Ember.Component.extend(T.default)), (0, y.Z)(d.prototype, "mockSlots", [s], Object.getOwnPropertyDescriptor(d.prototype, "mockSlots"), d.prototype), (0, y.Z)(d.prototype, "tripletSessionWithCount", [o], Object.getOwnPropertyDescriptor(d.prototype, "tripletSessionWithCount"), d.prototype), (0, y.Z)(d.prototype, "tripletSessionIconClass", [a], Object.getOwnPropertyDescriptor(d.prototype, "tripletSessionIconClass"), d.prototype), (0, y.Z)(d.prototype, "slotsAsTriplets", [l], Object.getOwnPropertyDescriptor(d.prototype, "slotsAsTriplets"), d.prototype), (0, y.Z)(d.prototype, "slotsForMinifiedView", [r], Object.getOwnPropertyDescriptor(d.prototype, "slotsForMinifiedView"), d.prototype), (0, y.Z)(d.prototype, "bookSlot", [u], Object.getOwnPropertyDescriptor(d.prototype, "bookSlot"), d.prototype), c = d)) || c)
        },
        39881: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return v
                }
            });
            var i, s, o, a, l, r = n(76227),
                u = n(75330),
                c = n(58880),
                d = n(53234),
                p = n(63537),
                m = n(65888),
                h = n(21951),
                f = n(68921);

            function g(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, p.Z)(e);
                    if (t) {
                        var s = (0, p.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, d.Z)(this, n)
                }
            }
            var v = (i = (0, h.classNames)("maximized-slots"), s = Ember._action, o = Ember._action, i((l = function(e) {
                (0, c.Z)(n, e);
                var t = g(n);

                function n() {
                    return (0, r.Z)(this, n), t.apply(this, arguments)
                }
                return (0, u.Z)(n, [{
                    key: "closeCalendarPickerMaxMode",
                    value: function() {
                        this.closeCalendarPicker()
                    }
                }, {
                    key: "openConfirmationScreen",
                    value: function(e) {
                        this.openConfirmationScreenForCalPicker(e, this.calendarMessage)
                    }
                }]), n
            }(Ember.Component.extend(f.default)), (0, m.Z)(l.prototype, "closeCalendarPickerMaxMode", [s], Object.getOwnPropertyDescriptor(l.prototype, "closeCalendarPickerMaxMode"), l.prototype), (0, m.Z)(l.prototype, "openConfirmationScreen", [o], Object.getOwnPropertyDescriptor(l.prototype, "openConfirmationScreen"), l.prototype), a = l)) || a)
        },
        27145: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return ie
                }
            });
            var i, s, o, a, l, r, u, c, d, p, m, h, f, g, v, b, y, w, E, T, S, C, M, _, O, k, A, I, N, R = n(78933),
                P = n(1522),
                x = n(76227),
                D = n(75330),
                Z = n(55365),
                F = n(39806),
                B = n(58880),
                L = n(53234),
                U = n(63537),
                V = n(77963),
                j = n(65888),
                H = n(21951),
                q = n(8209),
                z = n(5016),
                G = n(30094),
                Y = n(67117),
                W = n(68921),
                K = n(80033),
                Q = n(17067),
                J = n(37271),
                X = n(437),
                $ = n(51535),
                ee = n(35132),
                te = n(60919);

            function ne(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, U.Z)(e);
                    if (t) {
                        var s = (0, U.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, L.Z)(this, n)
                }
            }
            var ie = (i = (0, H.classNames)("cal-picker"), s = Ember.computed("isLoadingSlots", "firstFreeTimeSlots"), o = Ember.computed("messageMetaData", "messageMetaData.calendarMessageMeta.calendarAgentAlias"), a = Ember.computed("messageMetaData.calendarMessageMeta.calendarAgentAlias"), l = Ember.computed("session.user.{profilePicThumbUrl.isNameGenerated}"), r = Ember.computed.match("userInputEmail", G.default._EMAIL_REGEX), u = Ember.computed("message", "message.internalMeta.meetingStartTime", "meetingLength", "userTimeZoneToUse"), c = Ember.computed("message", "message.internalMeta.meetingStartTime", "userTimeZoneToUse"), d = Ember.computed, p = Ember.computed("timeZoneFilterValue"), m = Ember.computed("userInputEmailIsValid", "showValidationCrossMarkExplicit", "userInputEmail"), h = Ember.computed("userInputEmailIsValid", "showValidationCrossMarkExplicit", "userInputEmail"), f = Ember.computed("session.user.email", "userInputEmail"), g = Ember.computed.alias("hotline.ui.userCustomTz"), v = Ember._action, b = Ember._action, y = Ember._action, w = Ember._action, E = Ember._action, T = Ember._action, S = Ember._action, C = Ember._action, M = Ember._action, _ = Ember._action, O = Ember._action, i((A = function(e) {
                (0, B.Z)(n, e);
                var t = ne(n);

                function n() {
                    var e;
                    (0, x.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(s)), (0, V.Z)((0, Z.Z)(e), "images", {
                        AgentDefault: ee.Z,
                        CalUser: te.Z
                    }), (0, P.Z)((0, Z.Z)(e), "userInputEmailIsValid", I, (0, Z.Z)(e)), (0, P.Z)((0, Z.Z)(e), "userCustomTimeZone", N, (0, Z.Z)(e)), e
                }
                return (0, D.Z)(n, [{
                    key: "init",
                    value: function() {
                        var e, t, i, s;
                        (0, F.Z)((0, U.Z)(n.prototype), "init", this).apply(this, arguments), this.set("isLoadingSlots", !0), this.set("userEmailSubmitted", !1);
                        var o = (null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) || (null === (i = this.session) || void 0 === i || null === (s = i.user) || void 0 === s ? void 0 : s.workEmail);
                        o && this.set("userInputEmail", o)
                    }
                }, {
                    key: "noSlotsAvailable",
                    get: function() {
                        return !this.isLoadingSlots && !this.firstFreeTimeSlots
                    }
                }, {
                    key: "getCalendarData",
                    value: function() {
                        var e, t = this,
                            n = null === (e = this.messageMetaData) || void 0 === e ? void 0 : e.calendarMessageMeta,
                            i = n && n.calendarAgentAlias,
                            s = n && n.calendarProviderType;
                        this.store.findRecord("calendarAvailInfo", i, {
                            adapterOptions: {
                                calendarProviderType: s
                            },
                            reload: !0
                        }).then(function(e) {
                            (0, R.Z)(this, t), Ember.setProperties(this, {
                                isLoadingSlots: !1,
                                freeSlots: e.get("calendarTimeSlots"),
                                meetingLength: e.get("meetingLength"),
                                bufferTime: e.get("bufferTime"),
                                minNoticeTime: e.get("minNoticeTime"),
                                calendarType: e.get("calendarType")
                            })
                        }.bind(this))
                    }
                }, {
                    key: "agentData",
                    get: function() {
                        var e, t = null === (e = this.messageMetaData) || void 0 === e ? void 0 : e.calendarMessageMeta,
                            n = t && t.calendarAgentAlias;
                        return n ? this.agentService.getAgentInfo(n) : null
                    }
                }, {
                    key: "freshIdAgentPic",
                    get: function() {
                        var e, t, n, i, s, o = null === (e = this.messageMetaData) || void 0 === e || null === (t = e.calendarMessageMeta) || void 0 === t ? void 0 : t.calendarAgentAlias;
                        return null !== (n = this.hotlineUI) && void 0 !== n && null !== (i = n.config) && void 0 !== i && i.sales360App ? (0, $.freshIdAgentPicUrl)(null === (s = this.session) || void 0 === s ? void 0 : s.token, o) : ""
                    }
                }, {
                    key: "userPicUrl",
                    get: function() {
                        var e, t, n, i;
                        return null !== (e = this.session) && void 0 !== e && null !== (t = e.user) && void 0 !== t && t.isNameGenerated ? null : null === (n = this.session) || void 0 === n || null === (i = n.user) || void 0 === i ? void 0 : i.profilePicThumbUrl
                    }
                }, {
                    key: "timeSlotToBeBooked",
                    get: function() {
                        var e, t, n = this.userTimeZoneToUse,
                            i = null === (e = this.message) || void 0 === e || null === (t = e.internalMeta) || void 0 === t ? void 0 : t.meetingStartTime,
                            s = this.meetingLengthAsMillis;
                        if (i && s) {
                            var o = (0, z.default)(q.default.convert(i + s, n)).format("LT");
                            return (0, z.default)(q.default.convert(i, n)).format("LT") + " - " + o
                        }
                        return ""
                    }
                }, {
                    key: "dateToBeBooked",
                    get: function() {
                        var e, t, n = null === (e = this.message) || void 0 === e || null === (t = e.internalMeta) || void 0 === t ? void 0 : t.meetingStartTime,
                            i = this.userTimeZoneToUse;
                        return n && (0, z.default)(q.default.convert(n, i)).format("dddd") + ", " + (0, z.default)(q.default.convert(n, i)).format("LL")
                    }
                }, {
                    key: "createCalendarBookingFrag",
                    value: function(e, t) {
                        var n = this.meetingLengthAsMillis + e,
                            i = this.calendarType;
                        return {
                            fragmentType: Y.default.CONVERSATION.FRAGMENT_TYPE.MEETING,
                            startMillis: e,
                            endMillis: n,
                            eventProviderType: i,
                            userTimeZone: t,
                            isPendingCreation: !0
                        }
                    }
                }, {
                    key: "createCalendarCancelledFrag",
                    value: function() {
                        return {
                            fragmentType: Y.default.CONVERSATION.FRAGMENT_TYPE.TEXT,
                            content: this.intl.t("calendar.user_cancelled")
                        }
                    }
                }, {
                    key: "markCalendarInviteAsBooked",
                    value: function(e) {
                        Ember.set(e, "isCalendarInviteBooked", !0), e.save()
                    }
                }, {
                    key: "allTimeZones",
                    get: function() {
                        return q.default.listTimeZones()
                    }
                }, {
                    key: "filteredTimeZones",
                    get: function() {
                        var e = this.timeZoneFilterValue,
                            t = this.allTimeZones;
                        if (e) {
                            var n = [],
                                i = t && t.length;
                            e = e.toLowerCase();
                            for (var s = 0; s < i; s++) {
                                var o = t[s] && t[s].toLowerCase();
                                o && o.indexOf(e) > -1 && n.push(t[s])
                            }
                            return n
                        }
                        return t
                    }
                }, {
                    key: "emailIconClass",
                    get: function() {
                        return this.userInputEmailIsValid ? "ic-goto-next-screen icon-chevron_right_regular" : this.showValidationCrossMarkExplicit ? "ic-invalid-input icon-times_circle_solid" : "ic-empty-input icon-chevron_right_solid"
                    }
                }, {
                    key: "emailTooltip",
                    get: function() {
                        return this.userInputEmailIsValid ? this.intl.t("calendar.tooltips.valid_email") : this.showValidationCrossMarkExplicit ? this.intl.t("calendar.tooltips.invalid_email") : this.intl.t("calendar.tooltips.no_email")
                    }
                }, {
                    key: "updateUserEmail",
                    value: function() {
                        var e, t, n, i, s, o, a, l = this,
                            r = Y.default.EmberModelUrl.updateUser,
                            u = this.store,
                            c = {
                                user: {
                                    email: this.userInputEmail,
                                    id: null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.id,
                                    alias: null === (n = this.session) || void 0 === n || null === (i = n.user) || void 0 === i ? void 0 : i.alias
                                }
                            };
                        u.putRequest(r.model, (0, X.default)({
                            url: r.url,
                            token: null === (s = this.session) || void 0 === s ? void 0 : s.token,
                            alias: null === (o = this.session) || void 0 === o || null === (a = o.user) || void 0 === a ? void 0 : a.alias
                        }, this.session, this.isJWTEnabled()), c).then(function(e) {
                            (0, R.Z)(this, l), this.set("session.user.email", e.email), this.getCalendarData(), this.scrollToLastCalendarPicker(20)
                        }.bind(this)).catch(function() {
                            (0, R.Z)(this, l)
                        }.bind(this))
                    }
                }, {
                    key: "shouldUpdateUserEmail",
                    get: function() {
                        var e, t, n, i;
                        return ((null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) || (null === (n = this.session) || void 0 === n || null === (i = n.user) || void 0 === i ? void 0 : i.workEmail)) !== this.userInputEmail
                    }
                }, {
                    key: "maximizeCalendarPicker",
                    value: function() {
                        this.send("resetSlot");
                        var e = {
                            slotsData: this.sessionalizedCalendarSlots,
                            meetingLength: this.meetingLength,
                            message: this.message
                        };
                        this.openCalendarPickerMaximized(e), J.default.moveFocusTo(".cal-weekday-details")
                    }
                }, {
                    key: "resetSlot",
                    value: function() {
                        var e = this.message;
                        Ember.set(e, "internalMeta.meetingStartTime", null), e.save(), J.default.moveFocusTo(".calendar-picker-minified")
                    }
                }, {
                    key: "cancelInvite",
                    value: function() {
                        var e = [];
                        e.push(this.createCalendarCancelledFrag()), this.markCalendarInviteAsBooked(this.message), this.sendMessageFromAppConversation(e, {
                            internalMeta: this.messageMetaData,
                            messageType: Y.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.CANCELLED_BY_USER
                        }), J.default.moveFocusTo("#app-conversation-editor")
                    }
                }, {
                    key: "setSlot",
                    value: function(e) {
                        var t = this.message;
                        Ember.set(t, "internalMeta.meetingStartTime", e.from), t.save()
                    }
                }, {
                    key: "userEmailNextPress",
                    value: function() {
                        this.userInputEmail && this.send("userEmailEnterPress")
                    }
                }, {
                    key: "userEmailEnterPress",
                    value: function() {
                        this.userInputEmailIsValid ? (this.set("showValidationCheckMark", !0), this.set("userEmailSubmitted", !0), this.shouldUpdateUserEmail ? this.updateUserEmail(this.userInputEmail) : (this.getCalendarData(), this.scrollToLastCalendarPicker(20))) : this.set("showValidationCrossMarkExplicit", !0), J.default.moveFocusTo(".calendar-picker-minified")
                    }
                }, {
                    key: "bookSlot",
                    value: function() {
                        var e, t, n, i, s, o, a = this.userInputEmail;
                        a != (null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) && this.set("session.user.email", a);
                        var l = this.messageMetaData,
                            r = null === (n = this.message) || void 0 === n || null === (i = n.internalMeta) || void 0 === i ? void 0 : i.meetingStartTime,
                            u = a || (null === (s = this.session) || void 0 === s || null === (o = s.user) || void 0 === o ? void 0 : o.email),
                            c = this.userTimeZoneToUse,
                            d = [];
                        l && l.calendarMessageMeta && u && (l.calendarMessageMeta.calendarBookingEmail = u), d.push(this.createCalendarBookingFrag(r, c)), this.markCalendarInviteAsBooked(this.message), this.sendMessageFromAppConversation(d, {
                            internalMeta: l
                        }), J.default.moveFocusTo("#app-conversation-editor"), this.scrollToBottomWithDelay(20)
                    }
                }, {
                    key: "setUserCustomTimezone",
                    value: function(e) {
                        this.set("hotline.ui.userCustomTz", e), this.set("isTimeZoneSelectMode", !1)
                    }
                }, {
                    key: "switchToTimeZoneSelectMode",
                    value: function() {
                        this.set("isTimeZoneSelectMode", !0), J.default.onDropDownOpen(".time-zone-list-item", ".time-zone-input", !0)
                    }
                }, {
                    key: "dropDownKeyboardEvent",
                    value: function() {
                        J.default.hideDropDownOnFocusOut(event, "closeTimeZoneSelectMode", this), J.default.changeFocusOnArrowKeyPress(event, null, {
                            sourceElem: ".time-zone-input",
                            optionsSelector: ".time-zone-list-item",
                            scrollContainer: ".time-zones-container",
                            arrowTypes: "up-down",
                            isDropDown: !0
                        })
                    }
                }, {
                    key: "closeTimeZoneSelectMode",
                    value: function() {
                        this.set("isTimeZoneSelectMode", !1)
                    }
                }]), n
            }(Ember.Component.extend(W.default, K.default, Q.default)), (0, j.Z)(A.prototype, "noSlotsAvailable", [s], Object.getOwnPropertyDescriptor(A.prototype, "noSlotsAvailable"), A.prototype), (0, j.Z)(A.prototype, "agentData", [o], Object.getOwnPropertyDescriptor(A.prototype, "agentData"), A.prototype), (0, j.Z)(A.prototype, "freshIdAgentPic", [a], Object.getOwnPropertyDescriptor(A.prototype, "freshIdAgentPic"), A.prototype), (0, j.Z)(A.prototype, "userPicUrl", [l], Object.getOwnPropertyDescriptor(A.prototype, "userPicUrl"), A.prototype), I = (0, j.Z)(A.prototype, "userInputEmailIsValid", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, j.Z)(A.prototype, "timeSlotToBeBooked", [u], Object.getOwnPropertyDescriptor(A.prototype, "timeSlotToBeBooked"), A.prototype), (0, j.Z)(A.prototype, "dateToBeBooked", [c], Object.getOwnPropertyDescriptor(A.prototype, "dateToBeBooked"), A.prototype), (0, j.Z)(A.prototype, "allTimeZones", [d], Object.getOwnPropertyDescriptor(A.prototype, "allTimeZones"), A.prototype), (0, j.Z)(A.prototype, "filteredTimeZones", [p], Object.getOwnPropertyDescriptor(A.prototype, "filteredTimeZones"), A.prototype), (0, j.Z)(A.prototype, "emailIconClass", [m], Object.getOwnPropertyDescriptor(A.prototype, "emailIconClass"), A.prototype), (0, j.Z)(A.prototype, "emailTooltip", [h], Object.getOwnPropertyDescriptor(A.prototype, "emailTooltip"), A.prototype), (0, j.Z)(A.prototype, "shouldUpdateUserEmail", [f], Object.getOwnPropertyDescriptor(A.prototype, "shouldUpdateUserEmail"), A.prototype), N = (0, j.Z)(A.prototype, "userCustomTimeZone", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, j.Z)(A.prototype, "maximizeCalendarPicker", [v], Object.getOwnPropertyDescriptor(A.prototype, "maximizeCalendarPicker"), A.prototype), (0, j.Z)(A.prototype, "resetSlot", [b], Object.getOwnPropertyDescriptor(A.prototype, "resetSlot"), A.prototype), (0, j.Z)(A.prototype, "cancelInvite", [y], Object.getOwnPropertyDescriptor(A.prototype, "cancelInvite"), A.prototype), (0, j.Z)(A.prototype, "setSlot", [w], Object.getOwnPropertyDescriptor(A.prototype, "setSlot"), A.prototype), (0, j.Z)(A.prototype, "userEmailNextPress", [E], Object.getOwnPropertyDescriptor(A.prototype, "userEmailNextPress"), A.prototype), (0, j.Z)(A.prototype, "userEmailEnterPress", [T], Object.getOwnPropertyDescriptor(A.prototype, "userEmailEnterPress"), A.prototype), (0, j.Z)(A.prototype, "bookSlot", [S], Object.getOwnPropertyDescriptor(A.prototype, "bookSlot"), A.prototype), (0, j.Z)(A.prototype, "setUserCustomTimezone", [C], Object.getOwnPropertyDescriptor(A.prototype, "setUserCustomTimezone"), A.prototype), (0, j.Z)(A.prototype, "switchToTimeZoneSelectMode", [M], Object.getOwnPropertyDescriptor(A.prototype, "switchToTimeZoneSelectMode"), A.prototype), (0, j.Z)(A.prototype, "dropDownKeyboardEvent", [_], Object.getOwnPropertyDescriptor(A.prototype, "dropDownKeyboardEvent"), A.prototype), (0, j.Z)(A.prototype, "closeTimeZoneSelectMode", [O], Object.getOwnPropertyDescriptor(A.prototype, "closeTimeZoneSelectMode"), A.prototype), k = A)) || k)
        },
        84068: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(37271);
            t.default = Ember.Component.extend({
                actions: {
                    bookSlot: function(e) {
                        this.bookSlot(e), i.default.moveFocusTo(".calendar-picker-minified")
                    },
                    openConfirmationView: function(e) {
                        this.openConfirmationView(e)
                    }
                }
            })
        },
        18036: function(e, t, n) {
            "use strict";
            n.r(t), t.default = Ember.Component.extend({
                classNames: ["chip"]
            })
        },
        96045: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return f
                }
            });
            var i, s, o, a = n(76227),
                l = n(75330),
                r = n(58880),
                u = n(53234),
                c = n(63537),
                d = n(65888),
                p = n(54393),
                m = n(67117);

            function h(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, c.Z)(e);
                    if (t) {
                        var s = (0, c.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, u.Z)(this, n)
                }
            }
            var f = (i = Ember._action, s = Ember._action, o = function(e) {
                (0, r.Z)(n, e);
                var t = h(n);

                function n() {
                    return (0, a.Z)(this, n), t.apply(this, arguments)
                }
                return (0, l.Z)(n, [{
                    key: "onSelect",
                    value: function(e) {
                        return this.selectFragments(e)
                    }
                }, {
                    key: "onEnter",
                    value: function(e) {
                        var t = this.args.items[e].label;
                        return this.selectFragments(t)
                    }
                }, {
                    key: "createFragments",
                    value: function(e) {
                        return [{
                            fragmentType: m.default.CONVERSATION.FRAGMENT_TYPE.TEXT,
                            contentType: "text/html",
                            content: e,
                            quickAction: !0
                        }]
                    }
                }, {
                    key: "selectFragments",
                    value: function(e) {
                        var t, n, i, s = this.createFragments(e);
                        return null === (t = this.args.dropdown) || void 0 === t || t.actions.close(), null === (n = (i = this.args).selectionHandler) || void 0 === n ? void 0 : n.call(i, s)
                    }
                }]), n
            }(p.default), (0, d.Z)(o.prototype, "onSelect", [i], Object.getOwnPropertyDescriptor(o.prototype, "onSelect"), o.prototype), (0, d.Z)(o.prototype, "onEnter", [s], Object.getOwnPropertyDescriptor(o.prototype, "onEnter"), o.prototype), o)
        },
        43828: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return b
                }
            });
            var i, s, o, a, l, r = n(1522),
                u = n(76227),
                c = n(75330),
                d = n(55365),
                p = n(58880),
                m = n(53234),
                h = n(63537),
                f = n(65888),
                g = n(54393);

            function v(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, h.Z)(e);
                    if (t) {
                        var s = (0, h.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, m.Z)(this, n)
                }
            }
            var b = (i = Ember._tracked, s = Ember._action, o = Ember._action, a = function(e) {
                (0, p.Z)(n, e);
                var t = v(n);

                function n() {
                    var e;
                    (0, u.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(s)), (0, r.Z)((0, d.Z)(e), "editorText", l, (0, d.Z)(e)), e
                }
                return (0, c.Z)(n, [{
                    key: "slashQuickActionsText",
                    get: function() {
                        var e = this.editorText;
                        return e && 0 === e.trim().indexOf("/") ? e : ""
                    }
                }, {
                    key: "keyPressUp",
                    value: function(e, t) {
                        this.editorText = t
                    }
                }, {
                    key: "handleSelectionHandler",
                    value: function(e) {
                        var t, n;
                        null === (t = (n = this.args).onQuickActionSelect) || void 0 === t || t.call(n, e), this.editorText = ""
                    }
                }]), n
            }(g.default), l = (0, f.Z)(a.prototype, "editorText", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }), (0, f.Z)(a.prototype, "keyPressUp", [s], Object.getOwnPropertyDescriptor(a.prototype, "keyPressUp"), a.prototype), (0, f.Z)(a.prototype, "handleSelectionHandler", [o], Object.getOwnPropertyDescriptor(a.prototype, "handleSelectionHandler"), a.prototype), a)
        },
        94626: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return S
                }
            });
            var i, s, o, a, l, r = n(76227),
                u = n(75330),
                c = n(55365),
                d = n(39806),
                p = n(58880),
                m = n(53234),
                h = n(63537),
                f = n(77963),
                g = n(65888),
                v = n(21951),
                b = n(1469),
                y = n(67117),
                w = n(62588),
                E = n(99538);

            function T(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, h.Z)(e);
                    if (t) {
                        var s = (0, h.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, m.Z)(this, n)
                }
            }
            var S = (i = (0, v.tagName)("div"), s = (0, v.classNames)("fc-feedback"), o = Ember._action, i(a = s((l = function(e) {
                (0, p.Z)(n, e);
                var t = T(n);

                function n() {
                    var e;
                    (0, r.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(s)), (0, f.Z)((0, c.Z)(e), "images", {
                        ValidationErrorIcon: E.Z
                    }), e
                }
                return (0, u.Z)(n, [{
                    key: "init",
                    value: function() {
                        for (var e, t = arguments.length, i = new Array(t), s = 0; s < t; s++) i[s] = arguments[s];
                        (e = (0, d.Z)((0, h.Z)(n.prototype), "init", this)).call.apply(e, [this].concat(i));
                        var o = y.default.TemplateType,
                            a = o.FEEDBACK_RATING,
                            l = o.FEEDBACK_OPINION_POLL,
                            r = o.FEEDBACK_COMMENT;
                        this.setProperties({
                            FEEDBACK_RATING: a,
                            FEEDBACK_OPINION_POLL: l,
                            FEEDBACK_COMMENT: r,
                            isFeedbackCommentTextLengthExceeded: !1
                        })
                    }
                }, {
                    key: "submitBotFeedback",
                    value: function(e) {
                        var t = y.default.TemplateType,
                            n = t.FEEDBACK_RATING,
                            i = t.FEEDBACK_OPINION_POLL,
                            s = t.FEEDBACK_COMMENT,
                            o = "";
                        this.feedbackType === n ? o = null == e ? void 0 : e.displayOrder : this.feedbackType === i ? o = null == e ? void 0 : e.label : this.feedbackType === s && (o = null == e ? void 0 : e.content), this.onSelect({
                            fragmentType: 1,
                            contentType: "text/html",
                            content: o,
                            isFeedbackMessage: !0
                        })
                    }
                }, {
                    key: "keyPressDownFeedbackComment",
                    value: function(e, t) {
                        var n, i, s, o = null != t && null !== (n = t.target) && void 0 !== n && null !== (i = n.innerText) && void 0 !== i && i.length ? null == t || null === (s = t.target) || void 0 === s ? void 0 : s.innerText.replace(/<[^>]*>?/gm, "") : "",
                            a = (null == o ? void 0 : o.length) && (null == o ? void 0 : o.length) <= 500;
                        if (null != o && o.length && !a ? this.parentView.set("isFeedbackCommentTextLengthExceeded", !0) : this.parentView.set("isFeedbackCommentTextLengthExceeded", !1), t.which === y.default.KEYCODES.ENTER && a && (t.preventDefault(), !(0, b.isSlashCmdMenuVisible)())) {
                            var l, r = {
                                content: o
                            };
                            null == this || null === (l = this.parentView) || void 0 === l || l.submitBotFeedback(r)
                        }
                    }
                }]), n
            }(Ember.Component.extend(w.default)), (0, g.Z)(l.prototype, "submitBotFeedback", [o], Object.getOwnPropertyDescriptor(l.prototype, "submitBotFeedback"), l.prototype), a = l)) || a) || a)
        },
        84519: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(78933),
                s = n(5016),
                o = n(67117),
                a = n(86907),
                l = n(62588),
                r = n(68921),
                u = n(80033),
                c = n(66235),
                d = n(51535),
                p = n(103),
                m = n(46377);
            t.default = Ember.Component.extend(a.default, l.default, c.default, r.default, u.default, {
                CONVERSATION: o.default.CONVERSATION,
                MESSAGE_STATUS: o.default.MESSAGE_STATUS,
                CO_BROWSING_SUPPORT_URL: o.default.SUPPORT_URLS.CO_BROWSING,
                tagName: "li",
                classNames: ["fc-ui-message", "message-container"],
                screenshare: Ember.inject.service(),
                classNameBindings: ["model.userMessage:odd", "isGrpEnd:grp-ended", "isGrpStart:grp-started", "model.userMessage::agent-msg"],
                liveTranslation: Ember.inject.service(),
                postMessage: Ember.inject.service("post-message"),
                init: function() {
                    var e, t, n, s = this;
                    this._super.apply(this, arguments);
                    var a = this.model,
                        l = a.get("messageFragments") && a.get("messageFragments")[0],
                        r = a.get("messageFragments") && a.get("messageFragments").length,
                        u = null === (e = this.model) || void 0 === e ? void 0 : e.createdMillis,
                        c = this.readMillis,
                        d = null === (t = this.model) || void 0 === t ? void 0 : t.messageUserType,
                        p = null === (n = this.model) || void 0 === n ? void 0 : n.messageType,
                        h = this.messagesArray;
                    Ember.setProperties(this, {
                        showTranslatedText: !1,
                        isMuted: !1
                    }), l && 1 === r && l.fragmentType !== o.default.CONVERSATION.FRAGMENT_TYPE.IMAGE && a.set("emojisCount", this.getConsecutiveEmojisCount((0, m.sanitizeHTML)(this, l.content, "strict"))), 0 === d && h && h.isAny("hasReadReceipt", !0) && setTimeout(function() {
                        (0, i.Z)(this, s), h.setEach("hasReadReceipt", !1)
                    }.bind(this), 1), c && c < u && 0 !== d && p !== o.default.CONVERSATION.MESSAGE_TYPE.SCREEN_SHARE && h && !h.isAny("hasReadReceipt", !0) && setTimeout(Ember.set(this.model, "hasReadReceipt", !0), 1)
                },
                isCalendarInviteMessage: Ember.computed.equal("model.messageType", o.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT),
                isFlowCalendarInviteMessage: Ember.computed("isCalendarInviteMessage", {
                    get: function() {
                        var e;
                        return this.isCalendarInviteMessage && (null === (e = this.model) || void 0 === e ? void 0 : e.flowStepId)
                    }
                }),
                messageMetaData: Ember.computed("isCalendarInviteMessage", {
                    get: function() {
                        var e;
                        return this.isCalendarInviteMessage ? null === (e = this.model) || void 0 === e ? void 0 : e.internalMeta : null
                    }
                }),
                shouldDisplayCalendarPicker: Ember.computed("isCalendarInviteMessage", "iscalendarMessageResponded", {
                    get: function() {
                        var e;
                        return !!this.isCalendarInviteMessage && !(null !== (e = this.model) && void 0 !== e && e.isCalendarInviteBooked || this.iscalendarMessageResponded)
                    }
                }),
                flowCalendarResponded: Ember.computed("shouldDisplayCalendarPicker", "isFlowCalendarInviteMessage", {
                    get: function() {
                        return !this.shouldDisplayCalendarPicker && this.isFlowCalendarInviteMessage
                    }
                }),
                iscalendarMessageResponded: Ember.computed("shouldDisplayCalendarPicker", "calendarMessages", {
                    get: function() {
                        var e, t, n = this.calendarMessages,
                            i = null === (e = this.model) || void 0 === e || null === (t = e.internalMeta) || void 0 === t ? void 0 : t.calendarInviteId;
                        if (i) {
                            var s = n && n.filterBy("internalMeta.calendarInviteId", i);
                            if (s && s.length > 1) return !0
                        }
                        return !1
                    }
                }),
                showOfflineForm: Ember.computed("model", "model.{hasBeenRepliedToOffline,offlineMessage}", {
                    get: function() {
                        var e = this.model,
                            t = e && e.get("hasBeenRepliedToOffline");
                        return !(!e || !e.get("offlineMessage") || t)
                    }
                }),
                yesterdayMillis: Ember.computed({
                    get: function() {
                        return (0, s.default)().subtract(1, "day").startOf("day").valueOf()
                    }
                }),
                hideName: Ember.computed.alias("session.config.agent.hideName"),
                hidePic: Ember.computed.alias("session.config.agent.hidePic"),
                isAwayMessage: Ember.computed("model", "model.source", {
                    get: function() {
                        var e, t = null === (e = this.model) || void 0 === e ? void 0 : e.source;
                        return t === o.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE || t === o.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE_THANK_MESSAGE || t === o.default.CONVERSATION.MESSAGE_SOURCE.BH_AWAY_MESSAGE
                    }
                }),
                agentName: Ember.computed("model", "model.{messageUserType,messageType}", "hideName", {
                    get: function() {
                        var e, t, n, i, s, a = null === (e = this.model) || void 0 === e ? void 0 : e.messageUserType,
                            l = null === (t = this.model) || void 0 === t ? void 0 : t.messageType,
                            r = null === (n = this.session) || void 0 === n ? void 0 : n.appDisplayName,
                            u = null === (i = this.model) || void 0 === i ? void 0 : i.messageUserFirstName,
                            c = a && a === o.default.CONVERSATION.USER_TYPE.CHANNEL,
                            d = a && a !== o.default.CONVERSATION.USER_TYPE.USER,
                            p = l === o.default.CONVERSATION.MESSAGE_TYPE.BOT || l === o.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT || l === o.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT && (null === (s = this.model) || void 0 === s ? void 0 : s.flowId),
                            m = this.hideName,
                            h = this.isAwayMessage;
                        return c || h ? r : d ? m && !p ? r : u : null
                    }
                }),
                freshIdAgentPic: Ember.computed("model.{messageUserId,messageUserAlias}", {
                    get: function() {
                        var e, t, n, i, s = null === (e = this.model) || void 0 === e ? void 0 : e.messageUserAlias;
                        return null !== (t = this.hotlineUI) && void 0 !== t && null !== (n = t.config) && void 0 !== n && n.sales360App ? (0, d.freshIdAgentPicUrl)(null === (i = this.session) || void 0 === i ? void 0 : i.token, s) : ""
                    }
                }),
                agentPic: Ember.computed("model", "model.{messageUserId,messageUserAlias}", "hideName", "hidePic", "session.config.headerProperty.appLogo", {
                    get: function() {
                        var e, t, n, i, s = null === (e = this.model) || void 0 === e ? void 0 : e.messageUserAlias,
                            a = this.hideName,
                            l = this.hidePic,
                            r = null === (t = this.model) || void 0 === t ? void 0 : t.messageType,
                            u = r === o.default.CONVERSATION.MESSAGE_TYPE.BOT || r === o.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT || r === o.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT && (null === (n = this.model) || void 0 === n ? void 0 : n.flowId),
                            c = this.isAwayMessage;
                        return !s || (a || l) && !u || c ? null !== (i = this.session) && void 0 !== i && i.appLogoUrl ? Ember.Object.create({
                            profilePicThumbUrl: this.session.appLogoUrl
                        }) : Ember.Object.create({
                            profilePicThumbUrl: ""
                        }) : this.agentService.getAgentInfo(s)
                    }
                }),
                screenshareControl: Ember.computed("model.messageFragments.[]", {
                    get: function() {
                        var e = this.model;
                        return (e.get("messageFragments") && e.get("messageFragments").length && e.get("messageFragments")[0] && e.get("messageFragments")[0].content) !== this.intl.t("screenShare.screen_share_compare").toString()
                    }
                }),
                isArticleView: Ember.computed("model", "messageFragments.[]", {
                    get: function() {
                        var e = this.model,
                            t = !1;
                        if (e) {
                            var n = e.messageFragments,
                                i = n && n.length;
                            if (i > 0)
                                for (var s = 0; s < i; s++) {
                                    var o = n[s];
                                    if (o && o.fragmentType === this.CONVERSATION.FRAGMENT_TYPE.COLLECTION) {
                                        t = !0;
                                        break
                                    }
                                }
                        }
                        return t
                    }
                }),
                isGrpStart: Ember.computed("lastMessage", "model", "lastMessage.{messageUserId,messageUserType,messageType}", "model.{messageUserId,messageUserType,messageType}", {
                    get: function() {
                        var e = this.lastMessage,
                            t = this.model,
                            n = e && t.get("createdMillis") - e.get("createdMillis");
                        return !e || n > 3e5 || e.get("messageUserType") !== t.get("messageUserType") || t.get("messageType") !== e.get("messageType") || t.get("messageUserId") !== e.get("messageUserId") || !0 === t.hasReadReceipt
                    }
                }),
                isGrpEnd: Ember.computed("nextMessage", "model", "nextMessage.{messageUserId,messageUserType,messageType}", "model.{messageUserId,messageUserType,messageType}", {
                    get: function() {
                        var e = this.nextMessage,
                            t = this.model,
                            n = e && e.get("createdMillis") - t.get("createdMillis");
                        return !e || n > 3e5 || e.get("messageUserType") !== t.get("messageUserType") || t.get("messageType") !== e.get("messageType") || t.get("messageUserId") !== e.get("messageUserId")
                    }
                }),
                showDayStamp: Ember.computed("model.createdMillis", "lastMessage", "nextMessage", {
                    get: function() {
                        var e = this.model,
                            t = this.lastMessage,
                            n = e.get("createdMillis"),
                            i = t && t.get("createdMillis"),
                            o = i && (0, s.default)(i).startOf("day").valueOf(),
                            a = i && (0, s.default)(i).endOf("day").valueOf();
                        return o && a && !(n >= o && n <= a)
                    }
                }),
                showTimeStamp: Ember.computed("isGrpEnd", "model.userMessage", {
                    get: function() {
                        var e;
                        return !(!this.isGrpEnd || null === (e = this.model) || void 0 === e || !e.userMessage)
                    }
                }),
                containsTranslations: Ember.computed("liveTranslation.isLiveTranslationEnabled", {
                    get: function() {
                        var e, t, n = this.model;
                        return (null === (e = this.liveTranslation) || void 0 === e ? void 0 : e.isLiveTranslationEnabled) && (null === (t = this.liveTranslation) || void 0 === t ? void 0 : t.containsTranslatedContent(n))
                    }
                }),
                getConsecutiveEmojisCount: function(e) {
                    var t, n, i = 0,
                        s = 0,
                        o = p.unicodeRegExp;
                    return e && (n = (t = e.replace(/\s/g, "")).match(o)) && n.length <= 3 && n.length > 0 && (n.forEach((function(e) {
                        i += e.length
                    })), i === t.length && (s = n.length)), s
                },
                actions: {
                    resendMessage: function(e) {
                        this.resendMessage(e)
                    },
                    sendOfflineMessage: function(e) {
                        this.sendOfflineMessage(e)
                    },
                    enlargeImage: function(e) {
                        var t, n = null === (t = this.hotline) || void 0 === t ? void 0 : t.ui;
                        Ember.set(n, "modalOpen", !0), Ember.set(n, "modal", {
                            imageUrl: e
                        }), parent.focus(), this.postMessage.post({
                            action: "expand_all",
                            picUrl: e
                        })
                    },
                    allowScreenShare: function() {
                        var e, t, n, s, a, l, r, u, c, d, p = this;
                        if (null !== (e = this.session) && void 0 !== e && null !== (t = e.config) && void 0 !== t && t.isFCSDKWebView) return this.flash.showMessage(this.intl.t("screenShare.not_supported_mobile")), !1;
                        var m = o.default.EmberModelUrl.cobrowsingSettings,
                            h = null === (n = this.model) || void 0 === n ? void 0 : n.messageId,
                            f = null === (s = this.model) || void 0 === s ? void 0 : s.cobrowsingId,
                            g = null === (a = this.model) || void 0 === a ? void 0 : a.channelId,
                            v = null === (l = this.session) || void 0 === l ? void 0 : l.user,
                            b = this.agentPic,
                            y = b && b.get("profilePicThumbUrl"),
                            w = v.appId,
                            E = v.name,
                            T = v.id,
                            S = null === (r = this.model) || void 0 === r ? void 0 : r.conversationId,
                            C = null === (u = this.model) || void 0 === u ? void 0 : u.messageUserId,
                            M = v.cobrowsingSessionData,
                            _ = null === (c = this.model) || void 0 === c ? void 0 : c.messageUserName,
                            O = m.url.replace("{token}", null === (d = this.session) || void 0 === d ? void 0 : d.token),
                            k = {
                                messageId: h,
                                app_alias: w,
                                name: E,
                                role: "visitor",
                                viewerId: T,
                                conversationId: S,
                                sdata: M,
                                messageUserId: C,
                                agentName: _,
                                isMuted: !1,
                                cobrowsingId: f,
                                channelId: g,
                                pic: y
                            },
                            A = function(e) {
                                (0, i.Z)(this, p), k.cobrowsingSettings = e.data ? e.data : e.response.data, this.postMessage.post({
                                    action: "startScreenShare",
                                    cbData: k
                                })
                            }.bind(this);
                        this.axios.makeRequest({
                            method: "GET",
                            url: O,
                            contentType: "application/json; charset=UTF-8"
                        }).then(A, A)
                    },
                    denyScreensShare: function() {
                        var e, t, n, i, s = null === (e = this.model) || void 0 === e ? void 0 : e.conversationId,
                            o = null === (t = this.session) || void 0 === t ? void 0 : t.token,
                            a = (null === (n = this.session) || void 0 === n ? void 0 : n.user).appId,
                            l = null === (i = this.model) || void 0 === i ? void 0 : i.messageId;
                        this.screenshare.deny({
                            token: o,
                            messageId: l,
                            app_alias: a,
                            conversationId: s
                        })
                    },
                    openCalendarPickerMaximized: function(e) {
                        this.openCalendarPickerMaximized(e)
                    },
                    sendMessage: function(e, t) {
                        this.sendMessage(e, t)
                    },
                    toggleTranslatedTextView: function() {
                        this.liveTranslation.isLiveTranslationEnabled && this.toggleProperty("showTranslatedText")
                    }
                }
            })
        },
        32586: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return d
                }
            });
            var i = n(76227),
                s = n(75330),
                o = n(55365),
                a = n(58880),
                l = n(53234),
                r = n(63537),
                u = n(77963);

            function c(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, r.Z)(e);
                    if (t) {
                        var s = (0, r.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, l.Z)(this, n)
                }
            }
            var d = function(e) {
                (0, a.Z)(n, e);
                var t = c(n);

                function n() {
                    var e;
                    (0, i.Z)(this, n);
                    for (var s = arguments.length, a = new Array(s), l = 0; l < s; l++) a[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(a)), (0, u.Z)((0, o.Z)(e), "limit", 2), e
                }
                return (0, s.Z)(n, [{
                    key: "primaryActions",
                    get: function() {
                        var e;
                        return null === (e = this.args.quickActions) || void 0 === e ? void 0 : e.slice(0, this.limit)
                    }
                }, {
                    key: "restActions",
                    get: function() {
                        var e;
                        return null === (e = this.args.quickActions) || void 0 === e ? void 0 : e.slice(this.limit)
                    }
                }]), n
            }(n(54393).default)
        },
        98530: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return h
                }
            });
            var i = n(78933),
                s = n(76227),
                o = n(75330),
                a = n(55365),
                l = n(58880),
                r = n(53234),
                u = n(63537),
                c = n(77963),
                d = n(54393),
                p = n(67117);

            function m(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var s = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, r.Z)(this, n)
                }
            }
            var h = function(e) {
                (0, l.Z)(n, e);
                var t = m(n);

                function n() {
                    var e;
                    (0, s.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), l = 0; l < i; l++) o[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(o)), (0, c.Z)((0, a.Z)(e), "slashCmdId", p.default.DOM_ID.slashCommands), e
                }
                return (0, o.Z)(n, [{
                    key: "searchText",
                    get: function() {
                        return this.args.search ? this.args.search.slice(1) : ""
                    }
                }, {
                    key: "filteredQuickActions",
                    get: function() {
                        var e = this,
                            t = this.searchText.toLowerCase();
                        return this.args.quickActions.filter(function(n) {
                            var s = n.label;
                            return (0, i.Z)(this, e), s.toLowerCase().includes(t)
                        }.bind(this))
                    }
                }]), n
            }(d.default)
        },
        70827: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(62588),
                s = n(67117);
            t.default = Ember.Component.extend(i.default, {
                classNames: ["h-reply", "h-attachment-reply-composer"],
                attributeBindings: ["testId:data-test-id"],
                testId: "attachment-reply-composer",
                actions: {
                    onClickHandler: function() {
                        this.file.fileData || this.imageSelect()
                    },
                    onFileEdit: function(e) {
                        var t, n;
                        e.keyCode === s.default.KEYCODES.ENTER && (e.preventDefault(), null !== (t = this.file) && void 0 !== t && null !== (n = t.fileData) && void 0 !== n && n.name && this.sendAttachment())
                    },
                    onEnterFileUpload: function(e, t) {
                        var n, i;
                        t.keyCode === s.default.KEYCODES.ENTER && (t.preventDefault(), null !== (n = this.file) && void 0 !== n && null !== (i = n.fileData) && void 0 !== i && i.name ? this.sendAttachment() : this.imageSelect())
                    }
                }
            })
        },
        96750: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(75969);
            t.default = i.default.extend({})
        },
        15366: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(78933),
                s = n(26894),
                o = n(5016);

            function a(e, t, n) {
                return (e - t) * (e - n) <= 0
            }
            t.default = Ember.Helper.extend({
                compute: function(e, t) {
                    var n = this,
                        l = (0, s.Z)(e, 2),
                        r = l[0],
                        u = l[1];
                    if (r && !isNaN(r)) {
                        var c, d = 0,
                            p = (0, o.default)(r).diff((0, o.default)(), "seconds"),
                            m = !0;
                        if (t && t.updateOnInterval && (m = Boolean(t.updateOnInterval)), u) c = (0, o.default)(r).format(u);
                        else try {
                            c = p < 44 ? (0, o.default)(r).fromNow() : (0, o.default)().fromNow()
                        } catch (e) {
                            c = (0, o.default)(r).format("ddd, LT")
                        }
                        return m && (this.clearTimer(), d = function(e) {
                            return a(e, -89, 89) ? 3 : a(e, -5340, 5340) ? 120 : a(e, -86400, 86400) ? 1800 : 86400
                        }(p), this.intervalTimer = setInterval(function() {
                            var e = this;
                            (0, i.Z)(this, n), Ember.run(function() {
                                return (0, i.Z)(this, e), this.recompute()
                            }.bind(this))
                        }.bind(this), parseInt(1e3 * d, 10))), c
                    }
                    return ""
                },
                clearTimer: function() {
                    clearInterval(this.intervalTimer)
                },
                destroy: function() {
                    this.clearTimer()
                }
            })
        },
        63172: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                getNextElement: function() {
                    return s
                }
            });
            var i = n(26894);

            function s(e) {
                var t = (0, i.Z)(e, 2),
                    n = t[0],
                    s = t[1];
                return "undefined" === Ember.typeOf(s) ? null : n.objectAt(s + 1)
            }
            t.default = Ember.Helper.helper(s)
        },
        81826: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                getPreviousElement: function() {
                    return s
                }
            });
            var i = n(26894);

            function s(e) {
                var t = (0, i.Z)(e, 2),
                    n = t[0],
                    s = t[1];
                return "undefined" === Ember.typeOf(s) || 0 === s ? null : n.objectAt(s - 1)
            }
            t.default = Ember.Helper.helper(s)
        },
        35106: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                },
                gte: function() {
                    return i.gte
                }
            });
            var i = n(67883)
        },
        35284: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                isSame: function() {
                    return o
                }
            });
            var i = n(26894),
                s = n(5016);

            function o(e, t) {
                var n = (0, i.Z)(e, 2),
                    o = n[0],
                    a = n[1],
                    l = "milliseconds";
                if (o && a) return o = (0, s.default)("now" === o ? void 0 : o), a = (0, s.default)("now" === a ? void 0 : a), t && (l = t.precision ? t.precision : l), o.isSame(a, l)
            }
            t.default = Ember.Helper.helper(o)
        },
        89940: function(e, t, n) {
            "use strict";

            function i(e) {
                var t = e[0],
                    n = e[1],
                    i = e[2];
                return 0 != t && 1 != n ? i ? "maximize-triplet-slot" : "maximize-quad-slot" : ""
            }
            n.r(t), n.d(t, {
                canMaximizeSlots: function() {
                    return i
                }
            }), t.default = Ember.Helper.helper(i)
        },
        93244: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return f
                }
            });
            var i = n(78933),
                s = n(76227),
                o = n(75330),
                a = n(39806),
                l = n(58880),
                r = n(53234),
                u = n(63537),
                c = n(72194),
                d = n(86907),
                p = n(43436),
                m = n(67117);

            function h(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var s = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, s)
                    } else n = i.apply(this, arguments);
                    return (0, r.Z)(this, n)
                }
            }
            var f = function(e) {
                (0, l.Z)(n, e);
                var t = h(n);

                function n() {
                    return (0, s.Z)(this, n), t.apply(this, arguments)
                }
                return (0, o.Z)(n, [{
                    key: "init",
                    value: function() {
                        (0, a.Z)((0, u.Z)(n.prototype), "init", this).apply(this, arguments), this.conversationStatus = []
                    }
                }, {
                    key: "model",
                    value: function(e) {
                        var t, n, s = this,
                            o = m.default.EmberModelUrl.conversationStatus,
                            a = this.getParentRouteName(),
                            l = a ? this.modelFor(a) : null,
                            r = parseInt(e.channel_id);
                        if ((l && (t = l.channels, n = l.offlineExperience), n && n.offlineExpEnabled) && this.offlineExperienceEnabledChannel(r, n.channelIds)) {
                            var u, c, d, p = t.findBy("channelId", r),
                                h = null === (u = this.session) || void 0 === u ? void 0 : u.token,
                                f = null === (c = this.hotline) || void 0 === c || null === (d = c.ui) || void 0 === d ? void 0 : d.awayMessage,
                                g = p.operatingHoursId,
                                v = f.findBy("operatingHoursId", g);
                            if ((!v || v && !v.enabled) && (v = f.findBy("defaultBhr", !0)), v && v.awayMessage) {
                                var b = this.conversations.findBy("channelId", r),
                                    y = b && b.get("conversationId"),
                                    w = this.session,
                                    E = w && w.user,
                                    T = E && E.alias;
                                if (y) {
                                    var S, C = this.channelInfoAvailable(r, this.conversationStatus);
                                    if (C && (S = this.shouldUpdateChannelInfo(r, this.conversationStatus)), !C || C && S) return Ember.RSVP.hash({
                                        channelId: e.channel_id,
                                        conversationStatus: this.store.getRequest(o.model, o.url.replace("{token}", h).replace("{userAlias}", T) + "?conversationId=" + y + "&excludeMessages=true").then(function(e) {
                                            var t = this;
                                            (0, i.Z)(this, s), C ? C && S && this.conversationStatus && this.conversationStatus.forEach(function(n) {
                                                (0, i.Z)(this, t), n.channelId === r && (n.lastRequestedTime = (new Date).getTime(), n.conversationStatus = e.status, b.set("status", e.status), this.send("save"))
                                            }.bind(this)) : (this.conversationStatus.push({
                                                channelId: r,
                                                conversationStatus: e.status,
                                                lastRequestedTime: (new Date).getTime()
                                            }), b.set("status", e.status), this.send("save"))
                                        }.bind(this))
                                    })
                                }
                            }
                        }
                        return Ember.RSVP.hash({
                            channelId: e.channel_id
                        })
                    }
                }, {
                    key: "afterModel",
                    value: function(e) {
                        var t = this.getParentRouteName(),
                            i = t ? this.modelFor(t) : null;
                        i && (e.channels = i.channels, e.operatingHours = i.hours, e.offlineExperience = i.offlineExperience), (0, a.Z)((0, u.Z)(n.prototype), "afterModel", this).call(this)
                    }
                }, {
                    key: "channelInfoAvailable",
                    value: function(e, t) {
                        return t && t.findBy("channelId", e)
                    }
                }, {
                    key: "shouldUpdateChannelInfo",
                    value: function(e, t) {
                        var n = t.findBy("channelId", e);
                        return !(!n || !n.lastRequestedTime) && (new Date).getTime() - n.lastRequestedTime > 3e5
                    }
                }, {
                    key: "offlineExperienceEnabledChannel",
                    value: function(e, t) {
                        return (t && t.indexOf(e)) >= 0
                    }
                }]), n
            }(c.default.extend(d.default, p.default))
        },
        90620: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                }
            });
            var i = n(37784)
        },
        53200: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = g(n(6014)),
                s = g(n(62392)),
                o = g(n(31052)),
                a = g(n(31233)),
                l = g(n(13616)),
                r = g(n(84519)),
                u = g(n(84937)),
                c = g(n(66691)),
                d = g(n(81826)),
                p = g(n(63172)),
                m = g(n(45370)),
                h = g(n(68689)),
                f = g(n(20830));

            function g(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/or", (function() {
                return i.default
            })), window.define("hotline-web/components/app-loader/template", (function() {
                return s.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            })), window.define("hotline-web/helpers/contain-valid-text-fragment", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-message/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-message/component", (function() {
                return r.default
            })), window.define("hotline-web/helpers/and", (function() {
                return u.default
            })), window.define("hotline-web/helpers/not", (function() {
                return c.default
            })), window.define("hotline-web/helpers/get-previous-element", (function() {
                return d.default
            })), window.define("hotline-web/helpers/get-next-element", (function() {
                return p.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/template", (function() {
                return m.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/component", (function() {
                return h.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return f.default
            }));
            var v = (0, Ember.HTMLBars.template)({
                id: "IIbO1ufM",
                block: '[[[41,[28,[37,1],[[30,0,["isLoadingOlderMessages"]],[30,0,["isLoadingConversations"]]],null],[[[1,"  "],[10,"li"],[15,0,[52,[30,0,["isLoadingConversations"]],"app-loader-bottom","app-loader-top"]],[12],[1,"\\n    "],[8,[39,2],null,[["@isVertical","@label"],["true",[28,[37,3],["help_text.loading_older_conversations"],null]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[28,[37,4],[[30,0,["channelWrapedMessage"]]],null],[[[1,"  "],[8,[39,5],null,[["@model","@isOpen","@messagesArray"],[[30,0,["channelMessage"]],[30,0,["isOpen"]],[30,0,["channelWrapedMessage"]]]],null],[1,"\\n"]],[]],null],[1,"\\n"],[42,[28,[37,7],[[28,[37,7],[[30,0,["messages"]]],null]],null],null,[[[41,[28,[37,8],[[28,[37,4],[[30,1]],null],[28,[37,9],[[30,1,["isFeedbackResponse"]]],null]],null],[[[1,"    "],[8,[39,5],null,[["@messagesArray","@model","@lastMessage","@nextMessage","@calendarMessages","@isOpen","@extraParams","@cobrowsingAccepted","@cobrowsingDenied","@openCalendarPickerMaximized","@sendMessage","@sendOfflineMessage","@resendMessage","@readMillis"],[[30,0,["messages"]],[30,1],[28,[37,10],[[30,0,["messages"]],[30,2]],null],[28,[37,11],[[30,0,["messages"]],[30,2]],null],[30,0,["calendarMessages"]],[30,0,["isOpen"]],[30,0,["extraParams"]],"cobrowsingAccepted","cobrowsingDenied",[28,[37,12],[[30,0],"openCalendarPickerMaximized"],null],[28,[37,12],[[30,0],"sendMessage"],null],[28,[37,12],[[30,0],"sendOfflineMessage"],null],[28,[37,12],[[30,0],"resendMessage"],null],[30,0,["readMillis"]]]],null],[1,"\\n"]],[]],null]],[1,2]],null],[41,[30,0,["hotlineUI","config","enabledAgentTypingIndicator"]],[[[1,"  "],[10,"li"],[14,0,"ui-agent-typing-indicator-wrap"],[12],[1,"\\n    "],[8,[39,13],null,[["@channelId"],[[30,0,["channelId"]]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[41,[28,[37,8],[[30,0,["showPushOptions"]],[28,[37,9],[[30,0,["session","config","disableNotifications"]]],null]],null],[[[1,"  "],[10,"li"],[14,0,"notification-container animated fadeIn"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","push_notification"]],[[[1,"      "],[1,[28,[35,14],[[30,0,["session","config","content","headers","push_notification"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"      "],[1,[28,[35,3],["conversation.push_notification.message"],null]],[1,"\\n"]],[]]],[1,"    "],[10,0],[14,0,"btn-container"],[12],[1,"\\n      "],[11,1],[24,0,"btn-left"],[24,"role","button"],[24,"tabindex","0"],[4,[38,12],[[30,0],"askPermission"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","push_notify_yes"]],[[[1,"          "],[1,[30,0,["session","config","content","actions","push_notify_yes"]]],[1,"\\n"]],[]],[[[1,"          "],[1,[28,[35,3],["conversation.push_notification.yes"],null]],[1,"\\n"]],[]]],[1,"      "],[13],[1,"\\n      "],[11,1],[24,0,"btn-right"],[24,"role","button"],[24,"tabindex","0"],[4,[38,12],[[30,0],"clearPermission"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","push_notify_no"]],[[[1,"          "],[1,[30,0,["session","config","content","actions","push_notify_no"]]],[1,"\\n"]],[]],[[[1,"          "],[1,[28,[35,3],["conversation.push_notification.no"],null]],[1,"\\n"]],[]]],[1,"      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],["message","index"],false,["if","or","app-loader","t","contain-valid-text-fragment","ui-message","each","-track-array","and","not","get-previous-element","get-next-element","action","ui-agent-typing-indicator","sanitize-html"]]',
                moduleName: "hotline-web/components/app-conversation-message/template.hbs",
                isStrictMode: !1
            });
            t.default = v
        },
        62656: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = P(n(66691)),
                s = P(n(31052)),
                o = P(n(84937)),
                a = P(n(20830)),
                l = P(n(78735)),
                r = P(n(81140)),
                u = P(n(59901)),
                c = P(n(18036)),
                d = P(n(21581)),
                p = P(n(2582)),
                m = P(n(39881)),
                h = P(n(96389)),
                f = P(n(45697)),
                g = P(n(53200)),
                v = P(n(93589)),
                b = P(n(1238)),
                y = P(n(95617)),
                w = P(n(6014)),
                E = P(n(50207)),
                T = P(n(65061)),
                S = P(n(43828)),
                C = P(n(31514)),
                M = P(n(32586)),
                _ = P(n(53914)),
                O = P(n(19136)),
                k = P(n(90620)),
                A = P(n(42350)),
                I = P(n(14380)),
                N = P(n(28650)),
                R = P(n(15567));

            function P(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/not", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return s.default
            })), window.define("hotline-web/helpers/and", (function() {
                return o.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-quick-action-menu/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-ellipsis-icon/template", (function() {
                return r.default
            })), window.define("hotline-web/components/ui-chip/template", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-chip/component", (function() {
                return c.default
            })), window.define("hotline-web/helpers/gt", (function() {
                return d.default
            })), window.define("hotline-web/components/ui-calendar-picker-max/template", (function() {
                return p.default
            })), window.define("hotline-web/components/ui-calendar-picker-max/component", (function() {
                return m.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return h.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return f.default
            })), window.define("hotline-web/components/app-conversation-message/template", (function() {
                return g.default
            })), window.define("hotline-web/components/app-conversation-message/component", (function() {
                return v.default
            })), window.define("hotline-web/components/app-csat-form/template", (function() {
                return b.default
            })), window.define("hotline-web/components/app-csat-form/component", (function() {
                return y.default
            })), window.define("hotline-web/helpers/or", (function() {
                return w.default
            })), window.define("hotline-web/components/ui-attachment-preview/template", (function() {
                return E.default
            })), window.define("hotline-web/components/ui-editor-wrapper/template", (function() {
                return T.default
            })), window.define("hotline-web/components/ui-editor-wrapper/component", (function() {
                return S.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/template", (function() {
                return C.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/component", (function() {
                return M.default
            })), window.define("hotline-web/components/file-upload/component", (function() {
                return _.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return O.default
            })), window.define("hotline-web/templates/components/basic-dropdown", (function() {
                return k.default
            })), window.define("hotline-web/components/basic-dropdown", (function() {
                return A.default
            })), window.define("hotline-web/components/emoji-picker/component", (function() {
                return I.default
            })), window.define("hotline-web/components/app-reply-composer/template", (function() {
                return N.default
            })), window.define("hotline-web/components/app-reply-composer/component", (function() {
                return R.default
            }));
            var x = (0, Ember.HTMLBars.template)({
                id: "ksFxojpF",
                block: '[[[10,0],[14,0,"fc-conversation-view"],[12],[1,"\\n  "],[10,0],[15,0,[29,["h-header ",[52,[30,0,["isChannelOffline"]],"offline-header"]," ",[52,[30,0,["isSingleChannel"]],"single-channel-header"]," ",[52,[28,[37,1],[[30,0,["conversationDescription"]]],null],"single-channel-no-desc"]]]],[12],[1,"\\n    "],[10,0],[15,0,[29,["title fadeIn ",[30,0,["hotline","ui","config","headerProperty","headerStyle"]]]]],[12],[1,"\\n"],[41,[30,0,["isSingleChannel"]],[[[1,"        "],[10,0],[14,0,"logo"],[12],[1,"\\n"],[41,[30,0,["hotline","ui","config","widgetLogoUrl"]],[[[1,"            "],[10,"img"],[14,0,"animated zoomIn faster"],[15,"src",[30,0,["hotline","ui","config","widgetLogoUrl"]]],[15,"alt",[28,[37,2],["alt.logo"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"            "],[10,"img"],[14,0,"animated zoomIn faster"],[15,"src",[30,0,["images","FCLine"]]],[15,"alt",[28,[37,2],["alt.product_name"],null]],[12],[13],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n"]],[]],[[[1,"        "],[11,0],[24,0,"ic-back animated fadeIn faster"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,2],["aria_labels.back"],null]],[16,"onkeydown",[28,[37,3],[[30,0],"setNextFocus"],null]],[4,[38,3],[[30,0],"toggleBack"],null],[12],[1,"\\n          "],[10,"i"],[14,0,"icon icon-ic_back"],[12],[13],[1,"\\n        "],[13],[1,"\\n"]],[]]],[1,"      "],[10,0],[15,0,[29,["channel-info animated fadeIn faster ",[52,[30,0,["isCompact"]],"channel-info-compact-width","channel-info-width"]]]],[12],[1,"\\n        "],[10,"h1"],[15,0,[29,["channel-title\\n        ",[52,[28,[37,1],[[30,0,["conversationDescription"]]],null],"no-desc"],"\\n        ",[52,[28,[37,4],[[30,0,["isChannelOffline"]],[28,[37,4],[[28,[37,1],[[30,0,["showAgentProfile"]]],null]],null]],null],"offline"]]]],[12],[1,"\\n          "],[1,[28,[35,5],[[30,0,["channel","name"]],"strict"],null]],[1,"\\n        "],[13],[1,"\\n"],[41,[30,0,["isChannelOffline"]],[[[1,"          "],[10,1],[14,0,"away-icon"],[12],[1,"\\n            "],[10,"img"],[15,"src",[30,0,["images","ICOffline"]]],[15,"alt",[28,[37,2],["alt.away_icon"],null]],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["conversationDescription"]],[[[1,"          "],[10,2],[15,0,[29,["channel-desc ",[52,[30,0,["isChannelOffline"]],"offline-description"]]]],[12],[1,[30,0,["conversationDescription"]]],[13],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"],[41,[30,0,["quickActionsMenu"]],[[[1,"        "],[8,[39,6],null,[["@menuPosition","@quickActions","@selectionHandler"],[[28,[37,3],[[30,0],"menuPosition"],null],[30,0,["quickActionsMenu"]],[28,[37,3],[[30,0],"sendButtonMessage"],null]]],[["default"],[[[[1,"\\n          "],[10,3],[15,0,[29,["animated fadeIn faster ic-ellipsis-horizontal ",[52,[30,0,["conversationDescription"]],"ellipsis-with-desc","ellipsis-no-desc"]]]],[14,"role","button"],[15,"aria-label",[28,[37,2],["aria_labels.ellipsis_quick_action"],null]],[14,6,"javascript:void(0);"],[12],[1,"\\n            "],[8,[39,7],null,[["@fillColor","@height"],["#FFFFFF","1.7rem"]],null],[1,"\\n          "],[13],[1,"\\n        "]],[]]]]],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n  "],[10,0],[15,0,[29,["body\\n    ",[52,[28,[37,1],[[30,0,["isFAQAvailable"]]],null],"no-articles"]," ",[52,[30,0,["isSingleChannel"]],"single-channel-section"]," ",[52,[28,[37,1],[[30,0,["conversationDescription"]]],null],"single-channel-no-desc"]]]],[12],[1,"\\n"],[41,[30,0,["showUnreadToast"]],[[[1,"        "],[11,0],[24,0,"bottom-68 position--absolute align--center animated fadeInUp faster"],[24,"tabindex","0"],[24,"role","button"],[4,[38,3],[[30,0],"scrollToRecentMessages"],null],[12],[1,"\\n          "],[8,[39,8],null,[["@label"],[[52,[28,[37,9],[[30,0,["unreadCount"]],1],null],[28,[37,2],["conversation.chat_headers.new_msg_other"],[["count"],[[30,0,["unreadCount"]]]]],[28,[37,2],["conversation.chat_headers.new_msg_one"],null]]]],null],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"    "],[10,0],[15,0,[29,["h-chat-window ",[30,0,["chatWindowClass"]]]]],[12],[1,"\\n"],[1,"      "],[10,0],[15,0,[29,["cal-picker-maximized ",[52,[51,[30,0,["showCalPicker"]]],"hide-cal-picker"]]]],[12],[1,"\\n        "],[8,[39,11],null,[["@slotsData","@meetingLength","@calendarMessage","@openConfirmationScreenForCalPicker","@closeCalendarPicker"],[[30,0,["slotsData"]],[30,0,["meetingLength"]],[30,0,["calendarMessage"]],[28,[37,3],[[30,0],"openConfirmationScreenForCalPicker"],null],[28,[37,3],[[30,0],"closeCalendarPicker"],null]]],null],[1,"\\n      "],[13],[1,"\\n"],[41,[28,[37,4],[[30,0,["showAgentProfile"]],[28,[37,1],[[30,0,["isFocusInput"]]],null]],null],[[[1,"        "],[10,0],[15,0,[29,["expand ",[52,[30,0,["showCalPicker"]],"hide"]]]],[12],[1,"\\n          "],[10,0],[15,0,[29,["fc-agent-profile shadow ",[52,[30,0,["isAgentProfileExpand"]],"profile-expand"]]]],[12],[1,"\\n            "],[10,0],[14,0,"u-profile-info"],[12],[1,"\\n              "],[11,0],[16,0,[29,["user-details ",[30,0,["agentProfileClass"]]]]],[4,[38,3],[[30,0],"toggleProfileSize"],null],[12],[1,"\\n                "],[10,0],[14,0,"u-agent-avatar"],[12],[1,"\\n"],[41,[28,[37,4],[[30,0,["canShowFreshIdAgentPic"]],[28,[37,1],[[30,0,["isLastAgentMessageFromBot"]]],null]],null],[[[1,"                    "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,2],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[30,0,["currentAgent","profilePicUrl"]],[[[41,[28,[37,1],[[30,0,["isLastAgentMessageFromBot"]]],null],[[[41,[30,0,["hideName"]],[[[41,[30,0,["session","appLogoUrl"]],[[[1,"                          "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                            "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[15,"alt",[28,[37,2],["alt.app_logo"],null]],[12],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                          "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,12],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                              "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                "],[1,[28,[35,13],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n                        "]],[]],null]],[]]]],[]],[[[41,[30,0,["hidePic"]],[[[41,[30,0,["currentAgent","displayName"]],[[[1,"                            "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,12],[[30,0,["currentAgent","displayName"]]],null]]]],[12],[1,"\\n                                "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                  "],[1,[28,[35,13],[[30,0,["currentAgent","displayName"]]],null]],[1,"\\n                                "],[13],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                          "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,12],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                              "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                "],[1,[28,[35,13],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n                        "]],[]],null]],[]]]],[]],[[[1,"                        "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                          "],[10,"img"],[15,"src",[30,0,["currentAgent","profilePicUrl"]]],[15,"alt",[28,[37,2],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                        "],[13],[1,"\\n                      "]],[]]]],[]]]],[]],[[[1,"                      "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                        "],[10,"img"],[15,"src",[30,0,["currentAgent","profilePicUrl"]]],[15,"alt",[28,[37,2],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                      "],[13],[1,"\\n"]],[]]]],[]],[[[41,[30,0,["currentAgent","displayName"]],[[[41,[30,0,["hideName"]],[[[1,"                      "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                        "],[10,1],[15,0,[29,["theme-bg ",[28,[37,12],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                          "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                            "],[1,[28,[35,13],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                          "],[13],[1,"\\n                        "],[13],[1,"\\n                      "],[13],[1,"\\n"]],[]],[[[1,"                      "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                        "],[10,1],[15,0,[29,["theme-bg ",[28,[37,12],[[30,0,["currentAgent","displayName"]]],null]]]],[12],[1,"\\n                          "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                            "],[1,[28,[35,13],[[30,0,["currentAgent","displayName"]]],null]],[1,"\\n                          "],[13],[1,"\\n                        "],[13],[1,"\\n                      "],[13],[1,"\\n"]],[]]],[1,"                  "]],[]],null]],[]]]],[]]],[1,"                "],[13],[1,"\\n                "],[10,0],[14,0,"u-agent-info"],[12],[1,"\\n"],[41,[28,[37,4],[[30,0,["hideName"]],[28,[37,1],[[30,0,["isLastAgentMessageFromBot"]]],null]],null],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                      "],[10,2],[14,0,"u-agent-name"],[12],[1,"\\n                        "],[1,[28,[35,5],[[30,0,["session","appDisplayName"]],"strict"],null]],[1,"\\n                      "],[13],[1,"\\n"]],[]],null]],[]],[[[1,"                    "],[10,2],[14,0,"u-agent-name"],[12],[1,"\\n                      "],[1,[28,[35,5],[[30,0,["currentAgent","firstName"]],"strict"],null]],[1,"\\n                    "],[13],[1,"\\n"],[41,[30,0,["currentAgent","title"]],[[[1,"                      "],[10,2],[14,0,"u-agent-designation"],[12],[1,"\\n                        "],[10,"img"],[14,0,"designation-icon"],[15,"src",[30,0,["images","BCReg"]]],[15,"alt",[28,[37,2],["alt.designation_icon"],null]],[12],[13],[1,"\\n                        "],[1,[28,[35,5],[[30,0,["currentAgent","title"]],"strict"],null]],[1,"\\n                      "],[13],[1,"\\n"]],[]],null]],[]]],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n"],[41,[30,0,["showAgentBio"]],[[[1,"                "],[10,0],[14,0,"bio-details"],[12],[1,"\\n                  "],[10,0],[14,0,"u-agent-bio"],[12],[1,"\\n                    "],[10,2],[12],[1,[28,[35,5],[[30,0,["currentAgent","bio"]],"strict"],null]],[13],[1,"\\n                  "],[13],[1,"\\n"],[41,[51,[30,0,["hideBio"]]],[[[41,[30,0,["isSocialLinkPresent"]],[[[1,"                      "],[10,0],[14,0,"u-social-network"],[12],[1,"\\n"],[41,[30,0,["currentAgent","socialInfo","twitter"]],[[[1,"                          "],[10,3],[15,6,[29,["https://twitter.com/",[30,0,["currentAgent","socialInfo","twitter"]]]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n                            "],[10,0],[14,0,"u-twitter"],[12],[1,"\\n                              "],[10,"i"],[14,0,"icon-ic_logo_twitter social-icon"],[12],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["currentAgent","socialInfo","facebook"]],[[[1,"                          "],[10,3],[15,6,[29,["https://facebook.com/",[30,0,["currentAgent","socialInfo","facebook"]]]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n                            "],[10,0],[14,0,"u-fb"],[12],[1,"\\n                              "],[10,"i"],[14,0,"icon-ic_logo_facebook social-icon"],[12],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["currentAgent","socialInfo","linkedIn"]],[[[1,"                          "],[10,3],[15,6,[29,["https://linkedin.com/",[30,0,["currentAgent","socialInfo","linkedIn"]]]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n                            "],[10,0],[14,0,"u-linked-in"],[12],[1,"\\n                              "],[10,"i"],[14,0,"icon-ic_logo_linkedin social-icon"],[12],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],null],[1,"                      "],[13],[1,"\\n"]],[]],null]],[]],null],[1,"                "],[13],[1,"\\n"]],[]],null],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[41,[30,0,["channelEventReminder","eventDateTime"]],[[[1,"        "],[10,0],[15,0,[29,["calendar-event-reminder ",[52,[30,0,["showCalPicker"]],"hide"]]]],[12],[1,"\\n          "],[10,0],[14,0,"reminder-details"],[12],[1,"\\n            "],[10,"i"],[14,0,"ic-calendar icon-ic_schedule_meeting"],[12],[13],[1,"\\n            "],[10,1],[14,0,"reminder-time-date"],[12],[1,"\\n              "],[1,[30,0,["channelEventReminder","eventDateTime"]]],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n          "],[10,0],[14,0,"invite-more-icon"],[12],[1,"\\n"],[41,[30,0,["channelEventReminder","eventLink"]],[[[1,"              "],[10,3],[14,"target","_blank"],[14,"rel","noreferrer noopener"],[15,6,[30,0,["channelEventReminder","eventLink"]]],[12],[1,[28,[35,2],["calendar.view_details"],null]],[13],[1,"\\n"]],[]],null],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"      "],[10,0],[15,0,[29,["h-conv-chat h-theme-bg-",[30,0,["hotline","ui","config","backgroundImage"]]," animated fadeInUp speed scroll-section ",[30,0,["chatSectionClass"]]," ",[52,[30,0,["showCalPicker"]],"hide"]]]],[14,"tabindex","0"],[14,"role","status"],[14,"aria-live","assertive"],[14,"aria-relevant","additions"],[14,"aria-atomic","false"],[12],[1,"\\n        "],[8,[39,14],null,[["@model","@updateReadReceipt","@isOpen","@extraParams","@sendOfflineMessage","@sendMessage","@resendMessage","@openCalendarPickerMaximized","@isLoadingOlderMessages","@isLoadingConversations"],[[30,0,["model"]],[28,[37,3],[[30,0],"updateReadReceipt"],null],[30,0,["parentView","isOpen"]],[30,0,["extraParams"]],[28,[37,3],[[30,0],"sendOfflineMessage"],null],[28,[37,3],[[30,0],"sendMessage"],null],[28,[37,3],[[30,0],"resendMessage"],null],[28,[37,3],[[30,0],"openCalendarPickerMaximized"],null],[30,0,["isOldConvRequestPending"]],[30,0,["shouldDisableUserInput"]]]],null],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n    "],[8,[39,15],null,[["@model","@agent","@canShowFreshIdAgentPic","@freshIdAgentPic"],[[30,0,["model"]],[30,0,["currentAgent"]],[30,0,["canShowFreshIdAgentPic"]],[30,0,["freshIdAgentPic"]]]],null],[1,"\\n"],[41,[51,[30,0,["conversation","hasPendingCsat"]]],[[[1,"      "],[10,0],[15,0,[29,["h-reply-wrapper ",[30,0,["replyWrapperClass"]]]]],[12],[1,"\\n"],[1,"        "],[10,0],[15,0,[29,["h-reply ",[30,0,["replyEditorClass"]]]]],[12],[1,"\\n"],[41,[28,[37,16],[[30,0,["validationMsg"]],[30,0,["exampletextMessage"]]],null],[[[1,"            "],[10,0],[15,0,[29,["h-reply-validation ",[52,[30,0,["showValidationMsg"]],"validation-error"]]]],[12],[1,"\\n"],[41,[30,0,["showValidationMsg"]],[[[1,"                "],[10,1],[14,0,"validation-error-info"],[12],[1,"\\n                  "],[10,"img"],[14,0,"validation-error-icon"],[15,"src",[30,0,["images","ValidationErrorIcon"]]],[15,"alt",[28,[37,2],["alt.invalid_input"],null]],[12],[13],[1,"\\n                  "],[10,1],[12],[1,[30,0,["validationMsg"]]],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[1,"                "],[10,1],[12],[1,"\\n                  "],[1,[30,0,["exampletextMessage"]]],[1,"\\n                "],[13],[1,"\\n"]],[]]],[1,"            "],[13],[1,"\\n"]],[]],null],[41,[51,[30,0,["shouldHideReplyEditor"]]],[[[41,[30,0,["data","fileData","name"]],[[[1,"              "],[8,[39,17],null,[["@fileData","@imageSelect","@clearImage"],[[30,0,["data"]],[28,[37,3],[[30,0],"imageSelect"],null],[28,[37,3],[[30,0],"clearImage"],null]]],null],[1,"\\n"]],[]],null],[1,"              "],[8,[39,18],null,[["@quickActionsSlashCommandOptions","@onQuickActionSelect"],[[30,0,["quickActionsSlashCommandOptions"]],[28,[37,3],[[30,0],"sendButtonMessage"],null]]],[["default"],[[[[1,"\\n                "],[8,[30,1,["editor"]],null,[["@placeholder","@onBlur","@onFocus","@onKeyDown","@content","@isValidationError","@isTextLimitExceeded","@exceedAction","@hasValueInEditor","@id","@contentEditable","@editorHasContent"],[[30,0,["getPlaceholderMessage"]],[28,[37,3],[[30,0],"focusOut"],null],[28,[37,3],[[30,0],"focusIn"],null],[28,[37,3],[[30,0],"keyPressDown"],null],[30,0,["content"]],[30,0,["showValidationMsg"]],[30,0,["isTextLimitExceeded"]],[28,[37,3],[[30,0],"setIsTextLimitExceeded"],null],[28,[37,3],[[30,0],"hasValueInEditor"],null],[30,0,["DOM_ID","appConversationEditor"]],true,[30,0,["editorHasContent"]]]],null],[1,"\\n"],[41,[30,0,["quickActionButtons"]],[[[1,"                  "],[8,[39,19],null,[["@quickActions","@sendButtonMessage"],[[30,0,["quickActionButtons"]],[28,[37,3],[[30,0],"sendButtonMessage"],null]]],null],[1,"\\n"]],[]],null],[1,"              "]],[1]]]]],[1,"\\n"],[41,[30,0,["isAttachmentRequested"]],[[[1,"                "],[8,[39,20],null,[["@value","@id","@blockedFileTypes"],[[30,0,["fileReset"]],[30,0,["fileId"]],[30,0,["blockedFileTypes"]]]],null],[1,"\\n"]],[]],[[[41,[51,[30,0,["hideFileUpload"]]],[[[41,[30,0,["uploadFilesEnabled"]],[[[1,"                    "],[8,[39,20],null,[["@value","@id","@blockedFileTypes"],[[30,0,["fileReset"]],[30,0,["fileId"]],[30,0,["blockedFileTypes"]]]],null],[1,"\\n"]],[]],[[[1,"                    "],[8,[39,20],null,[["@value","@id","@allowedFileTypes"],[[30,0,["fileReset"]],[30,0,["fileId"]],".png,.jpg,.jpeg,.gif"]],null],[1,"\\n"]],[]]]],[]],null]],[]]],[41,[30,0,["hotline","ui","isDesktop"]],[[[41,[51,[28,[37,16],[[28,[37,21],[[30,0,["lastAgentMessage","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","BOT"]]],null],[28,[37,21],[[30,0,["lastAgentMessage","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","FREDDY_BOT"]]],null]],null]],[[[41,[51,[30,0,["hideFileUpload"]]],[[[1,"                  "],[11,3],[24,6,"#"],[16,0,[29,[[52,[30,0,["checkIfRtlIE"]],"h-reply-attach no-emoji","h-reply-attach"],"\\n                      ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]," ",[52,[30,0,["data","fileData","name"]],"fileAttached"]," test-class"]]],[24,"role","button"],[16,"aria-label",[28,[37,2],["aria_labels.file_attachment"],null]],[4,[38,3],[[30,0],"imageSelect"],null],[12],[1,"\\n                    "],[10,"i"],[14,0,"icons icon-ic_attachment"],[12],[13],[1,"\\n                  "],[13],[1,"\\n"]],[]],null],[41,[51,[30,0,["checkIfRtlIE"]]],[[[1,"                  "],[8,[39,22],null,[["@calculatePosition","@onOpen"],[[30,0,["calculatePosition"]],[30,0,["dropDownOpen"]]]],[["default"],[[[[1,"\\n                    "],[8,[30,2,["Trigger"]],[[16,0,[29,["h-reply-smiley ",[52,[30,0,["data","fileData","name"]],"fileAttached"]]]],[16,"onclick",[28,[37,3],[[30,0],"focusTextEditor"],null]]],null,[["default"],[[[[1,"\\n                      "],[11,0],[16,0,[29,["emoji-pic ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]]]],[16,"aria-label",[28,[37,2],["aria_labels.emoji_picker"],null]],[4,[38,3],[[30,0],"setConfig",[30,2]],null],[12],[1,"\\n                        "],[10,"i"],[14,0,"icons icon-ic_smiley"],[12],[13],[1,"\\n                      "],[13],[1,"\\n                    "]],[]]]]],[1,"\\n                    "],[8,[30,2,["Content"]],null,null,[["default"],[[[[1,"\\n                      "],[10,0],[15,"onkeydown",[28,[37,3],[[30,0],"emojiKeyboardEvent",[30,2]],null]],[15,"onmouseover",[28,[37,3],[[30,0],"setAriaSelected"],null]],[14,0,"emoji-picker-wrapper"],[12],[1,"\\n                        "],[8,[39,23],null,[["@selector","@updateHandler","@filePath","@updateContent"],["#app-conversation-editor",[28,[37,3],[[30,0],"updateEditorContent"],null],[30,0,["cdnUrl"]],false]],null],[1,"\\n                      "],[13],[1,"\\n                    "]],[]]]]],[1,"\\n                  "]],[2]]]]],[1,"\\n"]],[]],null]],[]],null]],[]],[[[1,"              "],[11,3],[16,0,[29,["h-reply-container ",[52,[30,0,["hasValueInEditor"]],"active","disabled"]]]],[24,6,"#"],[4,[38,3],[[30,0],"sendMessageFromMobile"],null],[12],[1,"\\n                "],[10,0],[15,0,[29,["h-reply-send ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]," ",[52,[30,0,["data","fileData","name"]],"fileAttached"]]]],[12],[1,"\\n                  "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"],[41,[51,[28,[37,16],[[28,[37,21],[[30,0,["lastAgentMessage","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","BOT"]]],null],[28,[37,21],[[30,0,["lastAgentMessage","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","FREDDY_BOT"]]],null]],null]],[[[41,[51,[30,0,["hideFileUpload"]]],[[[1,"                  "],[11,3],[24,6,"#"],[24,"role","button"],[16,"aria-label",[28,[37,2],["aria_labels.file_attachment"],null]],[4,[38,3],[[30,0],"imageSelect"],null],[12],[1,"\\n                    "],[10,0],[15,0,[29,["h-reply-attach ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]," ",[52,[30,0,["data","fileData","name"]],"fileAttached"]]]],[12],[1,"\\n                      "],[10,"i"],[14,0,"icons icon-ic_attachment"],[12],[13],[1,"\\n                    "],[13],[1,"\\n                  "],[13],[1,"\\n"]],[]],null]],[]],null]],[]]],[41,[30,0,["isTextLimitExceeded"]],[[[1,"              "],[10,0],[15,0,[29,["size-exceed-msg position-message-over\\n                ",[52,[30,0,["disableHugeMessageSending"]],"disable-send"]]]],[12],[1,"\\n                "],[10,"i"],[14,0,"icon-ic_alert"],[12],[13],[1,"\\n"],[41,[30,0,["disableHugeMessageSending"]],[[[1,"                  "],[1,[28,[35,2],["size_exceeded_msg.info_msg_sprout"],null]],[1,"\\n"]],[]],[[[1,"                  "],[2,[28,[37,2],["size_exceeded_msg.info_msg"],null]],[1,"\\n"]],[]]],[1,"              "],[13],[1,"\\n"]],[]],null]],[]],null],[1,"        "],[13],[1,"\\n"],[41,[51,[30,0,["defaultComposer"]]],[[[1,"          "],[8,[39,24],null,[["@isAttachmentRequested","@file","@imageSelect","@clearImage","@message","@sendButtonMessage","@resizeChatWindow","@quickActionButtons","@setIsTextLimitExceeded","@quickActionsSlashCommandOptions"],[[30,0,["isAttachmentRequested"]],[30,0,["data"]],[28,[37,3],[[30,0],"imageSelect"],null],[28,[37,3],[[30,0],"clearImage"],null],[30,0,["lastMessage"]],[28,[37,3],[[30,0],"sendButtonMessage"],null],[28,[37,3],[[30,0],"resizeChatWindow"],null],[30,0,["quickActionButtons"]],[28,[37,3],[[30,0],"setIsTextLimitExceeded"],null],[30,0,["quickActionsSlashCommandOptions"]]]],null],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["displayUnreadToastBubble"]],[[[1,"      "],[11,0],[24,0,"bottom-68 position--absolute align--center animated fadeInUp faster"],[24,"role","button"],[4,[38,3],[[30,0],"scrollToRecentMessages"],null],[12],[1,"\\n        "],[8,[39,8],null,[["@label"],[[52,[28,[37,9],[[30,0,["unreadCount"]],1],null],[28,[37,2],["conversation.chat_headers.new_msg_other"],[["count"],[[30,0,["unreadCount"]]]]],[28,[37,2],["conversation.chat_headers.new_msg_one"],null]]]],null],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"  "],[13],[1,"\\n  "],[10,1],[14,"aria-live","assertive"],[14,0,"aria-live-region"],[12],[13],[1,"\\n"],[13],[1,"\\n"]],["wrapper","dd"],false,["if","not","t","action","and","sanitize-html","ui-quick-action-menu","ui-ellipsis-icon","ui-chip","gt","unless","ui-calendar-picker-max","choose-theme","avatar-content","app-conversation-message","app-csat-form","or","ui-attachment-preview","ui-editor-wrapper","ui-quick-action-buttons","file-upload","eq","basic-dropdown","emoji-picker","app-reply-composer"]]',
                moduleName: "hotline-web/components/app-conversation/template.hbs",
                isStrictMode: !1
            });
            t.default = x
        },
        1238: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = m(n(20830)),
                s = m(n(66691)),
                o = m(n(31052)),
                a = m(n(84937)),
                l = m(n(6014)),
                r = m(n(96389)),
                u = m(n(45697)),
                c = m(n(77373)),
                d = m(n(19136)),
                p = m(n(35106));

            function m(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/sanitize-html", (function() {
                return i.default
            })), window.define("hotline-web/helpers/not", (function() {
                return s.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            })), window.define("hotline-web/helpers/and", (function() {
                return a.default
            })), window.define("hotline-web/helpers/or", (function() {
                return l.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return r.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return u.default
            })), window.define("hotline-web/components/radio-button/component", (function() {
                return c.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return d.default
            })), window.define("hotline-web/helpers/gte", (function() {
                return p.default
            }));
            var h = (0, Ember.HTMLBars.template)({
                id: "UzOeQ1Ls",
                block: '[[[41,[30,0,["showCsatForm"]],[[[1,"  "],[10,0],[14,0,"csat-rating animated fadeIn speed"],[14,"tabindex","0"],[15,"onkeydown",[28,[37,1],[[30,0],"csatKeyboardEvent"],null]],[12],[1,"\\n"],[41,[30,0,["conversation","resolvedConversationYes"]],[[[1,"      "],[10,0],[14,0,"vote-yes-outer animated delay-1 slideInUp speed"],[12],[1,"\\n        "],[10,0],[14,0,"vote-yes-wrapper"],[12],[1,"\\n          "],[10,0],[14,0,"vote-yes"],[12],[1,"\\n            "],[10,0],[14,0,"comment-header"],[12],[1,"\\n              "],[10,1],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_yes_question"]],[[[1,"                  "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_yes_question"]],"strict"],null]],[1,"\\n"]],[]],[[[41,[30,0,["conversation","csat","question"]],[[[1,"                  "],[1,[28,[35,2],[[30,0,["conversation","csat","question"]],"strict"],null]],[1,"\\n                "]],[]],null]],[]]],[1,"              "],[13],[1,"\\n              "],[11,0],[16,0,[29,["csat-minimize ",[52,[28,[37,3],[[30,0,["allowCsatSubmit"]]],null],"disabled"]]]],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,4],["aria_labels.close_csat"],null]],[4,[38,1],[[30,0],"submitCsatRating","true","true"],null],[12],[1,"\\n                "],[10,"i"],[14,0,"close_search_input icon-ic_close_small mild"],[12],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"align-middle"],[12],[1,"\\n              "],[10,0],[14,0,"voting-section"],[12],[1,"\\n                "],[10,0],[14,0,"user-logo"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"                     "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,4],["aria-label.agent_profile_pic"],null]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["hideName"]],[30,0,["session","appLogoUrl"]]],null],[[[1,"                    "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[15,"alt",[28,[37,4],["alt.app_logo"],null]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["agent","profilePicUrl"]],[28,[37,3],[[28,[37,6],[[30,0,["hidePic"]],[30,0,["hideName"]]],null]],null]],null],[[[1,"                    "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["agent","profilePicUrl"]]],[15,"alt",[28,[37,4],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[30,0,["agent","displayName"]],[[[1,"                    "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,1],[15,0,[29,["theme-bg ",[28,[37,7],[[30,0,["agent","displayName"]]],null]]]],[12],[1,"\\n                        "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                          "],[1,[28,[35,8],[[30,0,["agent","displayName"]]],null]],[1,"\\n                        "],[13],[1,"\\n                      "],[13],[1,"\\n                    "],[13],[1,"\\n                  "]],[]],null]],[]]]],[]]]],[]]],[1,"                "],[13],[1,"\\n                "],[10,0],[14,0,"rate"],[12],[1,"\\n                  "],[10,"h2"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_rate_here"]],[[[1,"                      "],[1,[30,0,["session","config","content","headers","csat_rate_here"]]],[1,"\\n"]],[]],[[[1,"                      "],[1,[28,[35,4],["csat.rate_here"],null]],[1,"\\n"]],[]]],[1,"                  "],[13],[1,"\\n                  "],[10,"fieldset"],[14,0,"rating"],[14,"role","radiogroup"],[12],[1,"\\n                      "],[8,[39,9],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star5","rating","5","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star5"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,10],[[30,0,["csatRatings","star"]],"5"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["5"]]]],[15,"aria-checked",[29,[[28,[37,11],[[30,0,["csatRatings","star"]],5],null]]]],[12],[13],[1," \\n                     "],[8,[39,9],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star4","rating","4","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star4"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,10],[[30,0,["csatRatings","star"]],"4"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["4"]]]],[15,"aria-checked",[29,[[28,[37,11],[[30,0,["csatRatings","star"]],4],null]]]],[12],[13],[1,"\\n                    "],[8,[39,9],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star3","rating","3","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star3"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,10],[[30,0,["csatRatings","star"]],"3"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["3"]]]],[15,"aria-checked",[29,[[28,[37,11],[[30,0,["csatRatings","star"]],3],null]]]],[12],[13],[1,"\\n                    "],[8,[39,9],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star2","rating","2","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star2"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,10],[[30,0,["csatRatings","star"]],"2"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["2"]]]],[15,"aria-checked",[29,[[28,[37,11],[[30,0,["csatRatings","star"]],2],null]]]],[12],[13],[1,"\\n                      "],[8,[39,9],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star1","rating","1","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star1"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,6],[[28,[37,3],[[30,0,["csatRatings","star"]]],null],[28,[37,10],[[30,0,["csatRatings","star"]],"1"],null]],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["1"]]]],[15,"aria-checked",[29,[[28,[37,11],[[30,0,["csatRatings","star"]],1],null]]]],[12],[13],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,0],[14,0,"comment"],[12],[1,"\\n                  "],[10,0],[12],[1,"\\n"],[41,[30,0,["conversation","csat","mobileUserCommentsAllowed"]],[[[1,"                      "],[8,[39,12],[[24,0,"csat-comments"],[16,"placeholder",[30,0,["csatComments"]]],[16,"aria-label",[30,0,["csatComments"]]]],[["@value","@rows","@autofocus","@maxlength"],[[30,0,["csatRatings","comment"]],"3",true,200]],null],[1,"                    "]],[]],null],[1,"                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,0],[14,0,"submit-rating"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["enableSubmitButtonForResolvedConversationYes"]],[28,[37,3],[[30,0,["disableCsatVoting"]]],null]],null],[[[1,"                    "],[11,1],[24,0,"btn submit"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"submitCsatRating","true"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n"]],[]]],[1,"                    "],[13],[1,"\\n"]],[]],[[[1,"                    "],[10,1],[14,0,"btn submit disabled"],[14,"role","button"],[14,"tabindex","0"],[14,"aria-disabled","true"],[12],[1,"\\n"],[41,[30,0,["isJwtAuthInProgressing"]],[[[1,"                        "],[1,[28,[35,4],["common.button.submitting"],null]],[1,"\\n"]],[]],[[[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n                      "]],[]]]],[]]],[1,"                    "],[13],[1,"\\n"]],[]]],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],[[[41,[30,0,["conversation","resolvedConversationNo"]],[[[1,"      "],[10,0],[14,0,"vote-yes-outer animated delay-1 slideInUp speed"],[12],[1,"\\n        "],[10,0],[14,0,"vote-yes-wrapper"],[12],[1,"\\n          "],[10,0],[14,0,"vote-yes"],[12],[1,"\\n            "],[10,0],[14,0,"comment-header"],[12],[1,"\\n              "],[10,1],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_no_question"]],[[[1,"                  "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_no_question"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                  "],[1,[28,[35,4],["csat.csat_no_comment"],null]],[1,"\\n"]],[]]],[1,"              "],[13],[1,"\\n              "],[11,0],[16,0,[29,["csat-minimize ",[52,[28,[37,3],[[30,0,["allowCsatSubmit"]]],null],"disabled"]]]],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,4],["aria_labels.close_csat"],null]],[16,"aria-disabled",[52,[51,[30,0,["allowCsatSubmit"]]],"true"]],[4,[38,1],[[30,0],"submitCsatRating","false","true"],null],[12],[1,"\\n                "],[10,"i"],[14,0,"close_search_input icon-ic_close_small mild"],[12],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"align-middle"],[12],[1,"\\n              "],[10,0],[14,0,"voting-section"],[12],[1,"\\n                "],[10,0],[14,0,"comment"],[12],[1,"\\n                  "],[10,0],[12],[1,"\\n                    "],[8,[39,12],[[24,0,"csat-comments"],[16,"placeholder",[30,0,["csatComments"]]],[16,"aria-label",[30,0,["csatComments"]]]],[["@value","@rows","@autofocus","@maxlength"],[[30,0,["csatRatings","comment"]],"3",true,200]],null],[1,"                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,0],[14,0,"submit-rating"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["enableSubmitButtonForResolvedConversationNo"]],[28,[37,3],[[30,0,["disableCsatVoting"]]],null]],null],[[[1,"                    "],[11,1],[24,0,"btn submit"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"submitCsatRating","false"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n"]],[]]],[1,"                    "],[13],[1,"\\n"]],[]],[[[1,"                    "],[10,1],[14,0,"btn submit disabled"],[12],[1,"\\n"],[41,[30,0,["isJwtAuthInProgressing"]],[[[1,"                        "],[1,[28,[35,4],["common.button.submitting"],null]],[1,"\\n"]],[]],[[[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n                      "]],[]]]],[]]],[1,"                    "],[13],[1,"\\n"]],[]]],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["showCsat"]],[28,[37,3],[[30,0,["conversation","resolvedConversationYes"]]],null],[28,[37,3],[[30,0,["conversation","resolvedConversationNo"]]],null]],null],[[[1,"      "],[10,0],[14,0,"csat-inner animated delay-1 slideInUp speed"],[12],[1,"\\n        "],[10,1],[14,0,"text"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_question"]],[[[1,"            "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_question"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"            "],[1,[28,[35,4],["csat.csat_question"],null]],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n        "],[10,0],[14,0,"btn-csat-wrapper"],[12],[1,"\\n          "],[11,1],[24,0,"btn-csat btn-csat-yes"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"csatVotingYes"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_yes"]],[[[1,"              "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_yes"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,4],["conversation.push_notification.yes"],null]],[1,"\\n"]],[]]],[1,"          "],[13],[1,"\\n          "],[11,1],[24,0,"btn-csat btn-csat-no"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"csatVotingNo"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_no"]],[[[1,"              "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_no"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,4],["conversation.push_notification.no"],null]],[1,"\\n"]],[]]],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],[[[41,[30,0,["feedbackSubmitted"]],[[[1,"      "],[10,0],[14,0,"csat-inner animated slideInUp speed"],[12],[1,"\\n        "],[10,0],[14,0,"thank-you-feedback"],[12],[1,"\\n          "],[10,0],[14,0,"thank-you-content"],[12],[1,"\\n            "],[10,0],[14,0,"user-logo"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,4],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["hideName"]],[30,0,["session","appLogoUrl"]]],null],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[15,"alt",[28,[37,4],["alt.app_logo"],null]],[12],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["agent","profilePicUrl"]],[28,[37,3],[[28,[37,6],[[30,0,["hidePic"]],[30,0,["hideName"]]],null]],null]],null],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,"img"],[15,"src",[30,0,["agent","profilePicUrl"]]],[15,"alt",[28,[37,4],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[41,[30,0,["agent","displayName"]],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,1],[15,0,[29,["theme-bg ",[28,[37,7],[[30,0,["agent","displayName"]]],null]]]],[12],[1,"\\n                    "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                      "],[1,[28,[35,8],[[30,0,["agent","displayName"]]],null]],[1,"\\n                    "],[13],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "]],[]],null]],[]]]],[]]]],[]]],[1,"            "],[13],[1,"\\n            "],[10,"h2"],[12],[1,[28,[35,4],["csat.submitted"],null]],[13],[1,"\\n            "],[10,1],[14,0,"thank-you"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_thankyou"]],[[[1,"                "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_thankyou"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                "],[1,[28,[35,4],["csat.thank_you"],null]],[1,"\\n"]],[]]],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "]],[]],null]],[]]]],[]]]],[]]],[1,"  "],[13],[1,"\\n"]],[]],null]],[],false,["if","action","sanitize-html","not","t","and","or","choose-theme","avatar-content","radio-button","eq","gte","textarea","unless"]]',
                moduleName: "hotline-web/components/app-csat-form/template.hbs",
                isStrictMode: !1
            });
            t.default = h
        },
        93479: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(31052)),
                s = a(n(84937)),
                o = a(n(66691));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/and", (function() {
                return s.default
            })), window.define("hotline-web/helpers/not", (function() {
                return o.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "h50rJC+o",
                block: '[[[10,0],[15,0,[29,["email-input ",[52,[30,0,["invalidContactInfo"]],"has-error"]]]],[12],[1,"\\n  "],[8,[39,1],[[24,0,"contact-detail"],[16,"placeholder",[30,0,["contactInfoPlaceholder"]]],[16,"aria-label",[30,0,["contactInfoPlaceholder"]]]],[["@value","@type","@key-up"],[[30,0,["contactDetail"]],"text",[28,[37,2],[[30,0],"validateContactInfo"],null]]],null],[1,"\\n"],[41,[30,0,["showValidationMark"]],[[[1,"    "],[10,"img"],[14,0,"input-state"],[15,"src",[30,0,["images","ValidInput"]]],[15,"alt",[28,[37,3],["alt.valid_input"],null]],[12],[13],[1,"\\n"]],[]],[[[41,[30,0,["invalidContactInfo"]],[[[1,"    "],[10,"img"],[14,0,"input-state"],[15,"src",[30,0,["images","InvalidInput"]]],[15,"alt",[28,[37,3],["alt.invalid_input"],null]],[12],[13],[1,"\\n  "]],[]],null]],[]]],[13],[1,"\\n"],[10,0],[15,0,[29,["user-comment ",[52,[30,0,["invalidUserMessage"]],"has-error"]]]],[12],[1,"\\n  "],[8,[39,4],[[24,0,"user-message-reply"],[16,"placeholder",[28,[37,3],["away_experience.offline_reply"],null]],[16,"aria-label",[28,[37,3],["away_experience.offline_reply"],null]]],[["@value","@type","@key-up","@rows"],[[30,0,["userMessage"]],"text",[28,[37,2],[[30,0],"validateUserMessage"],null],"15"]],null],[13],[1,"\\n"],[41,[30,0,["extraParams","isOfflineSendingFailed"]],[[[1,"  "],[10,0],[14,0,"error-text"],[12],[1,"\\n    "],[10,1],[12],[1,"\\n      "],[10,"img"],[14,0,"error-state"],[15,"src",[30,0,["images","ICNotSent"]]],[15,"alt",[28,[37,3],["alt.error_state"],null]],[12],[13],[1,"\\n    "],[13],[1,"\\n    "],[1,[28,[35,3],["away_experience.sending_failed"],null]],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[10,0],[14,0,"send-offline-reply"],[12],[1,"\\n  "],[11,"button"],[16,0,[29,["send-message\\n      ",[52,[28,[37,5],[[30,0,["offlineFormSubmitted"]],[28,[37,6],[[30,0,["extraParams","isOfflineSendingFailed"]]],null]],null],"disabled"]]]],[24,4,"button"],[4,[38,2],[[30,0],"sendMessages"],null],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["offlineFormSubmitted"]],[28,[37,6],[[30,0,["extraParams","isOfflineSendingFailed"]]],null]],null],[[[1,"      "],[1,[28,[35,3],["message.pending"],null]],[1,"\\n"]],[]],[[[41,[30,0,["extraParams","isOfflineSendingFailed"]],[[[1,"      "],[1,[28,[35,3],["away_experience.resend"],null]],[1,"\\n"]],[]],[[[1,"      "],[1,[28,[35,3],["away_experience.send"],null]],[1,"\\n    "]],[]]]],[]]],[1,"  "],[13],[1,"\\n"],[13]],[],false,["if","input","action","t","textarea","and","not"]]',
                moduleName: "hotline-web/components/app-offline-form/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        28650: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = y(n(31052)),
                s = y(n(35564)),
                o = y(n(75841)),
                a = y(n(90620)),
                l = y(n(42350)),
                r = y(n(20830)),
                u = y(n(89541)),
                c = y(n(57575)),
                d = y(n(58859)),
                p = y(n(94626)),
                m = y(n(65061)),
                h = y(n(43828)),
                f = y(n(65986)),
                g = y(n(70827)),
                v = y(n(31514)),
                b = y(n(32586));

            function y(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-button-composer/template", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-button-composer/component", (function() {
                return o.default
            })), window.define("hotline-web/templates/components/basic-dropdown", (function() {
                return a.default
            })), window.define("hotline-web/components/basic-dropdown", (function() {
                return l.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return r.default
            })), window.define("hotline-web/components/ui-carousel/template", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-carousel/component", (function() {
                return c.default
            })), window.define("hotline-web/components/ui-feedback/template", (function() {
                return d.default
            })), window.define("hotline-web/components/ui-feedback/component", (function() {
                return p.default
            })), window.define("hotline-web/components/ui-editor-wrapper/template", (function() {
                return m.default
            })), window.define("hotline-web/components/ui-editor-wrapper/component", (function() {
                return h.default
            })), window.define("hotline-web/components/ui-upload-attachment/template", (function() {
                return f.default
            })), window.define("hotline-web/components/ui-upload-attachment/component", (function() {
                return g.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/template", (function() {
                return v.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/component", (function() {
                return b.default
            }));
            var w = (0, Ember.HTMLBars.template)({
                id: "ggV8+lqe",
                block: '[[[41,[30,0,["isFeedbackReplyMessage"]],[[[1,"  "],[10,0],[14,0,"bot-feedback-response-container"],[12],[1,"\\n    "],[10,"img"],[14,0,"bot-feedback-response-tick"],[15,"src",[30,0,["images","TickFeedbackSubmitted"]]],[15,"alt",[28,[37,1],["alt.bot_feedback_response_tick"],null]],[12],[13],[1,"\\n    "],[10,0],[14,0,"bot-feedback-response"],[12],[1,[28,[35,1],["faqs.thank_you_for_feedback"],null]],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["customButtonComposer"]],[[[1,"  "],[10,0],[14,0,"button-region"],[12],[1,"\\n"],[42,[28,[37,3],[[28,[37,3],[[30,0,["customButtonComposer"]]],null]],null],null,[[[1,"      "],[8,[39,4],null,[["@sendButtonMessage","@model"],[[28,[37,5],[[30,0],[30,0,["sendButtonMessage"]]],null],[30,1]]],null],[1,"\\n"]],[1,2]],null],[1,"  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["articleFeedbackComposer"]],[[[1,"  "],[10,0],[14,0,"button-region"],[12],[1,"\\n"],[42,[28,[37,3],[[28,[37,3],[[30,0,["articleFeedbackComposer"]]],null]],null],null,[[[1,"      "],[8,[39,4],null,[["@sendButtonMessage","@model","@message"],[[28,[37,5],[[30,0],[30,0,["sendButtonMessage"]]],null],[30,3],[30,0,["message"]]]],null],[1,"\\n"]],[3,4]],null],[1,"  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["dropdownOptions","length"]],[[[1,"  "],[8,[39,6],null,[["@disabled","@calculatePosition","@onOpen"],[[30,0,["disableDropdown"]],[30,0,["calculatePosition"]],[30,0,["onOpen"]]]],[["default"],[[[[1,"\\n    "],[8,[30,5,["Trigger"]],null,null,[["default"],[[[[1,"\\n      "],[10,0],[14,0,"dropdown-placeholder"],[12],[1,"\\n        "],[1,[28,[35,1],["common.labels.click_here_to_select"],null]],[1,"\\n        "],[10,"img"],[14,0,"dropdown-icon"],[15,"src",[30,0,["images","DropdownArrow"]]],[15,"alt",[28,[37,1],["alt.dropdown_arrow"],null]],[12],[13],[1,"\\n      "],[13],[1,"\\n    "]],[]]]]],[1,"\\n    "],[8,[30,5,["Content"]],[[4,[38,5],[[30,0],[30,5,["actions","close"]]],null]],null,[["default"],[[[[1,"\\n      "],[10,"ul"],[14,0,"channel-list"],[14,"tabindex","-1"],[14,"role","listbox"],[15,"onkeydown",[28,[37,5],[[30,0],"dropDownKeyboardEvent",[30,5]],null]],[12],[1,"\\n"],[42,[28,[37,3],[[28,[37,3],[[30,0,["dropdownOptions"]]],null]],null],null,[[[1,"          "],[11,"li"],[24,"tabindex","-1"],[24,"aria-selected","false"],[24,0,"drop-down-list"],[24,"role","option"],[4,[38,5],[[30,0],"dropdownSelectionHandler",[30,6]],null],[12],[1,[28,[35,7],[[30,6,["label"]],"strict"],null]],[13],[1,"\\n"]],[6,7]],null],[1,"      "],[13],[1,"\\n    "]],[]]]]],[1,"\\n  "]],[5]]]]],[1,"\\n\\n"]],[]],[[[41,[30,0,["carousel","cards","length"]],[[[1,"  "],[10,0],[14,0,"fc-carousel-wrapper"],[15,"onkeydown",[28,[37,5],[[30,0],"setNextFocus"],null]],[12],[1,"\\n    "],[8,[39,8],null,[["@title","@cards","@onSelect"],[[30,0,["carousel","title","firstObject"]],[30,0,["carousel","cards"]],[28,[37,5],[[30,0],"carouselSelectionHandler"],null]]],null],[1,"\\n  "],[13],[1,"\\n\\n"]],[]],[[[41,[30,0,["feedbackData","content","length"]],[[[1,"    "],[10,0],[14,0,"fc-feedback-wrapper"],[15,"onkeydown",[28,[37,5],[[30,0],"setNextFocus"],null]],[12],[1,"\\n      "],[8,[39,9],null,[["@feedbackData","@feedbackType","@onSelect","@message","@quickActionButtons","@feedbackCommentQuickActionsSlashCommandOptions","@feedbackCommentOnQuickActionSelect","@feedbackCommentId","@feedbackCommentOnBlur","@feedbackCommentOnFocus","@feedbackCommentOnKeyDown","@feedbackCommentContent","@feedbackCommentExceedAction"],[[30,0,["feedbackData","content"]],[30,0,["feedbackData","feedbackType"]],[28,[37,5],[[30,0],"feedbackSelectionHandler"],null],[30,0,["message"]],[30,0,["quickActionButtons"]],[30,0,["quickActionsSlashCommandOptions"]],[28,[37,5],[[30,0],"triggerSendButtonMessage"],null],[30,0,["DOM_ID","appReplyComposerEditor"]],[28,[37,5],[[30,0],"focusOut"],null],[28,[37,5],[[30,0],"focusIn"],null],[28,[37,5],[[30,0],"keyPressDownLocal"],null],[30,0,["content"]],[28,[37,5],[[30,0],"setIsTextLimitExceeded"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null]],[]]]],[]]]],[]]]],[]]]],[]]],[1,"\\n"],[41,[30,0,["customTextComposer"]],[[[1,"  "],[10,0],[15,0,[29,["h-reply h-custom-composer ",[52,[51,[30,0,["hotline","ui","onLine"]]],"is-disabled"]]]],[12],[1,"\\n"],[41,[51,[30,0,["hotline","ui","isDesktop"]]],[[[1,"      "],[11,3],[16,0,[29,["h-reply-container\\n          ",[52,[51,[30,0,["showPlaceholderText"]]],"show-highlight"]]]],[24,6,"#"],[4,[38,5],[[30,0],"beforeSendMessage"],null],[12],[1,"\\n        "],[10,0],[14,0,"h-reply-send"],[12],[1,"\\n          "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"    "],[8,[39,11],null,[["@quickActionsSlashCommandOptions","@onQuickActionSelect"],[[30,0,["quickActionsSlashCommandOptions"]],[28,[37,5],[[30,0],"triggerSendButtonMessage"],null]]],[["default"],[[[[1,"\\n      "],[8,[30,8,["editor"]],null,[["@onBlur","@onFocus","@emojiSupport","@onKeyDown","@content","@exceedAction","@id","@contentEditable","@placeholder"],[[28,[37,5],[[30,0],"focusOut"],null],[28,[37,5],[[30,0],"focusIn"],null],true,[28,[37,5],[[30,0],"keyPressDownLocal"],null],[30,0,["content"]],[28,[37,5],[[30,0],"setIsTextLimitExceeded"],null],[30,0,["DOM_ID","appReplyComposerEditor"]],true,"conversation.ce.placeholders.default"]],null],[1,"\\n    "]],[8]]]]],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["isAttachmentRequested"]],[[[1,"  "],[8,[39,12],null,[["@exceedAction","@file","@imageSelect","@clearImage","@sendAttachment"],[[28,[37,5],[[30,0],"setIsTextLimitExceeded"],null],[30,0,["file"]],[28,[37,5],[[30,0],[30,0,["imageSelect"]]],null],[28,[37,5],[[30,0],[30,0,["clearImage"]]],null],[30,0,["sendButtonMessage"]]]],null],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,9],[[[1,"  "],[8,[39,13],null,[["@quickActions","@sendButtonMessage"],[[30,9],[30,10]]],null],[1,"\\n"]],[]],null]],["button","index","button","index","dd","option","index","wrapper","@quickActionButtons","@sendButtonMessage"],false,["if","t","each","-track-array","ui-button-composer","action","basic-dropdown","sanitize-html","ui-carousel","ui-feedback","unless","ui-editor-wrapper","ui-upload-attachment","ui-quick-action-buttons"]]',
                moduleName: "hotline-web/components/app-reply-composer/template.hbs",
                isStrictMode: !1
            });
            t.default = w
        },
        45370: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, s = (i = n(31052)) && i.__esModule ? i : {
                default: i
            };
            window.define("hotline-web/helpers/t", (function() {
                return s.default
            }));
            var o = (0, Ember.HTMLBars.template)({
                id: "S7WUDywq",
                block: '[[[11,0],[16,0,[29,["ui-agent-typing-indicator ",[52,[51,[30,0,["isAgentTyping"]]],"hidden"]]]],[16,"aria-label",[28,[37,1],["aria_labels.agent_typing"],null]],[17,1],[12],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n"],[13],[1,"\\n"]],["&attrs"],false,["unless","t"]]',
                moduleName: "hotline-web/components/ui-agent-typing-indicator/template.hbs",
                isStrictMode: !1
            });
            t.default = o
        },
        50207: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(19136)),
                s = a(n(20830)),
                o = a(n(31052));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/eq", (function() {
                return i.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return s.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "ZXEdzQdM",
                block: '[[[10,0],[14,0,"file-meta animated fadeInUp faster"],[12],[1,"\\n   "],[10,1],[14,0,"file-name"],[12],[1,"\\n      "],[10,"i"],[15,0,[29,["icons ",[52,[28,[37,1],[[30,1,["fileType"]],[30,0,["fileType","IMAGE"]]],null],"icon-ic_image","icon-ic_attachment"]]]],[14,"aria-hidden","true"],[12],[13],[1," "],[1,[28,[35,2],[[30,1,["fileData","name"]],"strict"],null]],[1,"\\n   "],[13],[1,"\\n\\n"],[41,[30,1,["fileContent"]],[[[1,"      "],[11,1],[24,0,"edit"],[24,"role","button"],[16,"onkeydown",[30,2]],[24,"tabindex","0"],[16,"aria-label",[28,[37,3],["aria_labels.select_image"],null]],[4,[38,4],[[30,0],[30,3]],null],[12],[1,"\\n         "],[10,"i"],[14,0,"icons icon-ic_pencil"],[12],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"\\n   "],[11,1],[24,0,"close"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,3],["aria_labels.clear_image"],null]],[4,[38,4],[[30,0],[30,4]],null],[12],[1,"\\n      "],[10,"i"],[14,0,"icon-ic_close_small"],[12],[13],[1,"\\n   "],[13],[1,"\\n"],[13]],["@fileData","@onKeyDown","@imageSelect","@clearImage"],false,["if","eq","sanitize-html","t","action"]]',
                moduleName: "hotline-web/components/ui-attachment-preview/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        35564: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "+JrtiA24",
                block: '[[[10,1],[14,0,"btn-content"],[12],[1,"\\n  "],[1,[30,0,["generatedHTML"]]],[1,"\\n"],[13]],[],false,[]]',
                moduleName: "hotline-web/components/ui-button-composer/template.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        70155: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(31052)),
                s = a(n(61863)),
                o = a(n(84068));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-calendar-session-view/template", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-calendar-session-view/component", (function() {
                return o.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "ZhGqMVu0",
                block: '[[[42,[28,[37,1],[[28,[37,1],[[30,0,["daysWithSlotsAsQuads"]]],null]],null],null,[[[1,"  "],[10,0],[14,0,"cal-weekday-details"],[14,"tabindex","0"],[12],[1,"\\n    "],[10,1],[14,0,"cal-weekday-name"],[12],[1,"\\n      "],[1,[30,1,["weekday"]]],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,0,"cal-weekday-date bolder"],[12],[1,"\\n      "],[1,[30,1,["date"]]],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"],[41,[30,1,["morningSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session morning icon-ic_morning"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.morn"],null]],[1,"("],[1,[30,1,["morningSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["morningSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,1,["afternoonSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session afternoon icon-ic_afternoon"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.afternoon"],null]],[1,"("],[1,[30,1,["afternoonSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["afternoonSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,1,["eveningSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session evening icon-ic_evening"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.evening"],null]],[1,"("],[1,[30,1,["eveningSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["eveningSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,1,["nightSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session night icon-ic_night"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.night"],null]],[1,"("],[1,[30,1,["nightSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["nightSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null]],[1]],null]],["day"],false,["each","-track-array","if","t","ui-calendar-session-view","action"]]',
                moduleName: "hotline-web/components/ui-calendar-day-quads/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        49342: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n(61863)),
                s = o(n(84068));

            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-calendar-session-view/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-calendar-session-view/component", (function() {
                return s.default
            }));
            var a = (0, Ember.HTMLBars.template)({
                id: "awo5KgU2",
                block: '[[[10,0],[14,0,"cal-weekday-details"],[14,"tabindex","0"],[12],[1,"\\n"],[41,[30,0,["isLoadingSlots"]],[[[1,"    "],[10,1],[14,0,"is-loading-weekday"],[12],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,0,"is-loading-weekday-name"],[12],[1,"\\n    "],[13],[1,"\\n"]],[]],[[[1,"    "],[10,1],[14,0,"cal-weekday-name"],[12],[1,"\\n      "],[1,[30,0,["model","weekday"]]],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,0,"cal-weekday-date"],[12],[1,"\\n      "],[1,[30,0,["model","date"]]],[1,"\\n    "],[13],[1,"\\n"]],[]]],[13],[1,"\\n"],[10,0],[14,0,"cal-time-slots"],[12],[1,"\\n"],[41,[30,0,["isLoadingSlots"]],[[[42,[28,[37,2],[[28,[37,2],[[30,0,["mockSlots"]]],null]],null],null,[[[1,"      "],[10,0],[14,0,"cal-time-slot-group cal-time-slot-triplet loading"],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,1]],null]],null],null,[[[1,"          "],[10,1],[14,0,"cal-time-slot"],[12],[1,"\\n            "],[10,1],[14,0,"is-loading-timeslot"],[12],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"]],[1]],null]],[]],[[[1,"    "],[10,0],[14,0,"session-name"],[12],[1,"\\n      "],[10,"i"],[15,0,[30,0,["tripletSessionIconClass"]]],[12],[13],[1,"\\n      "],[10,1],[14,0,"session-name-text"],[12],[1,[30,0,["tripletSessionWithCount"]]],[13],[1,"\\n    "],[13],[1,"\\n    "],[8,[39,3],null,[["@slots","@viewTriplets","@bookSlot"],[[30,0,["slotsAsTriplets"]],"true",[28,[37,4],[[30,0],"bookSlot"],null]]],null],[1,"\\n"]],[]]],[13]],["slotsTriplet"],false,["if","each","-track-array","ui-calendar-session-view","action"]]',
                moduleName: "hotline-web/components/ui-calendar-day-triplets/template.hbs",
                isStrictMode: !1
            });
            t.default = a
        },
        2582: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(31052)),
                s = a(n(70155)),
                o = a(n(45498));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-calendar-day-quads/template", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-calendar-day-quads/component", (function() {
                return o.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "70N4b2So",
                block: '[[[10,0],[14,0,"cal-picker-nav"],[12],[1,"\\n  "],[10,1],[14,0,"cal-nav-left"],[12],[1,"\\n    "],[11,"i"],[24,0,"ic-cal-back clickable icon-ic_back_calendar"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,0],["aria_labels.close_calendar_picker_maxmode"],null]],[4,[38,1],[[30,0],"closeCalendarPickerMaxMode"],null],[12],[13],[1,"\\n  "],[13],[1,"\\n  "],[10,1],[14,0,"cal-picker-title"],[12],[1,"\\n    "],[1,[28,[35,0],["calendar.schedule_a_demo"],null]],[1,"\\n  "],[13],[1,"\\n  "],[10,1],[14,0,"cal-meeting-length"],[12],[1,"\\n    "],[1,[30,0,["meetingLengthAsString"]]],[1,"\\n  "],[13],[1,"\\n"],[13],[1,"\\n"],[10,0],[14,0,"cal-timings-scroll"],[12],[1,"\\n  "],[8,[39,2],null,[["@openConfirmationScreen","@model"],[[28,[37,1],[[30,0],"openConfirmationScreen"],null],[30,0,["slotsData"]]]],null],[1,"\\n"],[13]],[],false,["t","action","ui-calendar-day-quads"]]',
                moduleName: "hotline-web/components/ui-calendar-picker-max/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        10767: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = d(n(31052)),
                s = d(n(66691)),
                o = d(n(84937)),
                a = d(n(96389)),
                l = d(n(45697)),
                r = d(n(20830)),
                u = d(n(49342)),
                c = d(n(2177));

            function d(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/not", (function() {
                return s.default
            })), window.define("hotline-web/helpers/and", (function() {
                return o.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return a.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return l.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return r.default
            })), window.define("hotline-web/components/ui-calendar-day-triplets/template", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-calendar-day-triplets/component", (function() {
                return c.default
            }));
            var p = (0, Ember.HTMLBars.template)({
                id: "whxmvZjh",
                block: '[[[10,0],[14,0,"h-chat"],[12],[1,"\\n  "],[10,0],[14,0,"h-conv multiple"],[12],[1,"\\n    "],[10,0],[14,0,"h-comment calendar-picker-container"],[12],[1,"\\n"],[41,[30,0,["isTimeZoneSelectMode"]],[[[1,"        "],[10,0],[14,0,"timezone-picker"],[12],[1,"\\n          "],[10,0],[14,0,"timezone-picker-header"],[12],[1,"\\n            "],[11,1],[24,0,"cal-nav-left"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["aria_labels.close_time_zone_selectmode"],null]],[4,[38,2],[[30,0],"closeTimeZoneSelectMode"],null],[12],[1,"\\n              "],[10,"i"],[14,0,"ic-cal-back clickable icon-ic_back_calendar"],[12],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,1],[14,0,"cal-tz-existing"],[12],[1,"\\n"],[41,[30,0,["userCustomTimeZone"]],[[[1,"                "],[1,[30,0,["userCustomTimeZone"]]],[1,"\\n"]],[]],[[[1,"                "],[1,[30,0,["userDefaultTimeZone"]]],[1,"\\n"]],[]]],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n"],[1,"          "],[10,0],[14,0,"timezone-picker-body"],[12],[1,"\\n            "],[10,0],[14,0,"time-zone-search-bar"],[15,"onkeydown",[28,[37,2],[[30,0],"dropDownKeyboardEvent"],null]],[12],[1,"\\n              "],[8,[39,3],[[24,0,"time-zone-input"],[16,"aria-label",[28,[37,1],["calendar.search_tz"],null]]],[["@value","@placeholder"],[[30,0,["timeZoneFilterValue"]],[28,[37,1],["calendar.search_tz"],null]]],null],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"time-zones-container"],[12],[1,"\\n              "],[10,"ul"],[14,0,"time-zones-list"],[14,"role","listbox"],[14,1,"time-zone-list"],[12],[1,"\\n"],[42,[28,[37,5],[[28,[37,5],[[30,0,["filteredTimeZones"]]],null]],null],null,[[[1,"                  "],[11,"li"],[24,0,"time-zone-list-item"],[24,"tabindex","-1"],[24,"aria-selected","false"],[24,"role","option"],[4,[38,2],[[30,0],"setUserCustomTimezone",[30,1]],null],[12],[1,"\\n                    "],[1,[30,1]],[1,"\\n                  "],[13],[1,"\\n"]],[1]],null],[1,"              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"],[1,"        "],[13],[1,"\\n"]],[]],[[[1,"        "],[10,0],[14,0,"calendar-picker-minified"],[14,"tabindex","-1"],[12],[1,"\\n          "],[10,0],[15,0,[29,["calendar-picker-header ",[52,[51,[30,0,["userEmailSubmitted"]]],"email-input-view"]]]],[12],[1,"\\n            "],[10,0],[14,0,"cal-header-left"],[12],[1,"\\n\\n              "],[10,"i"],[14,0,"ic-calendar cp-mini icon-ic_schedule_meeting"],[12],[13],[1,"\\n              "],[10,1],[14,0,"schedule-a-demo-text"],[12],[1,"\\n                "],[1,[28,[35,1],["calendar.schedule_a_demo"],null]],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"cal-header-tw"],[12],[1,"\\n              "],[1,[30,0,["meetingLengthAsString"]]],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"],[41,[28,[37,7],[[30,0,["userEmailSubmitted"]]],null],[[[1,"            "],[10,0],[14,0,"cal-picker-email-view"],[12],[1,"\\n              "],[10,0],[14,0,"email-input-container"],[12],[1,"\\n                "],[10,0],[15,0,[29,["email-input ",[52,[28,[37,8],[[28,[37,7],[[30,0,["userInputEmailIsValid"]]],null],[30,0,["showValidationCrossMarkExplicit"]]],null],"invalid-email"]]]],[12],[1,"\\n                  "],[8,[39,3],[[24,0,"email-input-field"],[16,"aria-label",[28,[37,1],["calendar.email_placeholder"],null]]],[["@enter","@value","@placeholder"],[[28,[37,2],[[30,0],"userEmailEnterPress"],null],[30,0,["userInputEmail"]],[28,[37,1],["calendar.email_placeholder"],null]]],null],[1,"\\n                "],[13],[1,"\\n                "],[11,0],[24,0,"email-action"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["aria_labels.schedule_meeting"],null]],[4,[38,2],[[30,0],[52,[30,0,["userInputEmailIsValid"]],"userEmailEnterPress",""]],null],[12],[1,"\\n                  "],[10,"i"],[15,0,[30,0,["emailIconClass"]]],[12],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["message","internalMeta","meetingStartTime"]],[[[1,"            "],[10,0],[14,0,"cal-picker-conf-view"],[12],[1,"\\n              "],[10,0],[14,0,"participants"],[12],[1,"\\n                "],[10,0],[14,0,"agent-segment"],[12],[1,"\\n                  "],[10,0],[14,0,"cal-agent-pic"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,1],["aria-label.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["agentData","profilePicThumbUrl"]],[28,[37,7],[[30,0,["hideName"]]],null]],null],[[[41,[30,0,["hidePic"]],[[[41,[30,0,["agentData","firstName"]],[[[1,"                          "],[10,1],[14,0,"event-participant-avatar"],[12],[1,"\\n                            "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,9],[[30,0,["agentData","firstName"]]],null]]]],[12],[1,"\\n                                "],[10,1],[14,0,"avatar-content"],[14,"data-calendar-agent-name-avatar",""],[12],[1,"\\n                                  "],[1,[28,[35,10],[[30,0,["agentData","firstName"]]],null]],[1,"\\n                                "],[13],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                          "],[10,1],[14,0,"event-participant-avatar"],[12],[1,"\\n                            "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,9],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                                "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                  "],[1,[28,[35,10],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                                "],[13],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n                        "]],[]],null]],[]]]],[]],[[[1,"                        "],[10,"img"],[15,"src",[30,0,["agentData","profilePicThumbUrl"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]]]],[]],[[[41,[30,0,["session","appLogoUrl"]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.app_logo"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["images","AgentDefault"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                    "]],[]]]],[]]]],[]]],[1,"                  "],[13],[1,"\\n"],[41,[28,[37,8],[[30,0,["agentData","firstName"]],[28,[37,7],[[30,0,["hideName"]]],null]],null],[[[1,"                    "],[10,0],[14,0,"cal-agent-name"],[12],[1,[30,0,["agentData","firstName"]]],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                      "],[10,0],[14,0,"cal-agent-name"],[12],[1,"\\n                        "],[1,[28,[35,11],[[30,0,["session","appDisplayName"]],"strict"],null]],[1,"\\n                      "],[13],[1,"\\n"]],[]],null]],[]]],[1,"                "],[13],[1,"\\n                "],[10,0],[14,0,"user-segment"],[12],[1,"\\n                  "],[10,0],[14,0,"cal-user-pic"],[12],[1,"\\n"],[41,[30,0,["userPicUrl"]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["userPicUrl"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.user_profile_pic"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["images","CalUser"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.participant_avatar"],null]],[12],[13],[1,"\\n"]],[]]],[1,"                  "],[13],[1,"\\n                  "],[10,0],[14,0,"cal-user-name"],[12],[1,"\\n                    "],[1,[28,[35,1],["calendar.you"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"meeting-date"],[12],[1,"\\n                "],[1,[30,0,["dateToBeBooked"]]],[1,"\\n              "],[13],[1,"\\n              "],[11,0],[24,0,"meeting-time"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["aria_labels.time_slot"],[["time"],[[30,0,["timeSlotToBeBooked"]]]]]],[4,[38,2],[[30,0],"resetSlot"],null],[12],[1,"\\n                "],[1,[30,0,["timeSlotToBeBooked"]]],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"time-zone"],[12],[1,"\\n                "],[1,[30,0,["userTimeZoneToUse"]]],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"],[1,"            "],[11,0],[16,0,[29,["cal-confirmation-div ",[52,[30,0,["message","isCalendarInviteBooked"]],"disabled"]]]],[16,"aria-disabled",[52,[30,0,["message","isCalendarInviteBooked"]],"true"]],[24,"role","button"],[24,"tabindex","0"],[4,[38,2],[[30,0],"bookSlot"],null],[12],[1,"\\n              "],[1,[28,[35,1],["calendar.confirm"],null]],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["noSlotsAvailable"]],[[[1,"              "],[10,0],[14,0,"calendar-slots-not-av"],[12],[1,"\\n                "],[1,[28,[35,1],["calendar.no_slots"],null]],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,0],[14,0,"calendar-picker-body"],[12],[1,"\\n                "],[8,[39,12],null,[["@isLoadingSlots","@setSlot","@model"],[[30,0,["isLoadingSlots"]],[28,[37,2],[[30,0],"setSlot"],null],[30,0,["firstFreeTimeSlots"]]]],null],[1,"\\n                "],[10,0],[15,0,[29,["calendar-picker-actions ",[52,[30,0,["isLoadingSlots"]],"is-loading"]]]],[12],[1,"\\n"],[41,[51,[30,0,["isLoadingSlots"]]],[[[1,"                    "],[11,0],[24,0,"calendar-show-more"],[24,"role","button"],[24,"tabindex","0"],[4,[38,2],[[30,0],"maximizeCalendarPicker"],null],[12],[1,"\\n                      "],[1,[28,[35,1],["calendar.show_more"],null]],[1,"\\n                    "],[13],[1,"\\n                    "],[11,0],[24,0,"calendar-tz-action"],[24,"role","combobox"],[24,"tabindex","0"],[4,[38,2],[[30,0],"switchToTimeZoneSelectMode"],null],[12],[1,"\\n"],[41,[30,0,["userCustomTimeZone"]],[[[1,"                        "],[1,[30,0,["userCustomTimeZone"]]],[1,"\\n"]],[]],[[[1,"                        "],[1,[30,0,["userDefaultTimeZone"]]],[1,"\\n"]],[]]],[1,"                    "],[13],[1,"\\n"]],[]],null],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]]],[1,"\\n"],[1,"            "],[11,0],[24,0,"calendar-cancel-action"],[24,"role","button"],[24,"tabindex","0"],[4,[38,2],[[30,0],"cancelInvite"],null],[12],[1,"\\n              "],[1,[28,[35,1],["calendar.cancel"],null]],[1,"\\n            "],[13],[1,"\\n"],[1,"          "]],[]]]],[]]],[1,"        "],[13],[1,"\\n"]],[]]],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"],[13],[1,"\\n"]],["filterResult"],false,["if","t","action","input","each","-track-array","unless","not","and","choose-theme","avatar-content","sanitize-html","ui-calendar-day-triplets"]]',
                moduleName: "hotline-web/components/ui-calendar-picker/template.hbs",
                isStrictMode: !1
            });
            t.default = p
        },
        61863: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, s = (i = n(89940)) && i.__esModule ? i : {
                default: i
            };
            window.define("hotline-web/helpers/maximize-calendar-slot", (function() {
                return s.default
            }));
            var o = (0, Ember.HTMLBars.template)({
                id: "goOpqBct",
                block: '[[[41,[30,0,["viewTriplets"]],[[[42,[28,[37,2],[[28,[37,2],[[30,0,["slots"]]],null]],null],null,[[[1,"    "],[10,0],[15,0,[29,["cal-time-slot-group cal-time-slot-triplet ",[28,[37,3],[[30,2],[30,1,["length"]],true],null]]]],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,1]],null]],null],null,[[[1,"        "],[11,1],[24,0,"cal-time-slot maximize-slot"],[24,"role","button"],[24,"tabindex","0"],[4,[38,4],[[30,0],"bookSlot",[30,3]],null],[12],[1,"\\n          "],[1,[30,3,["fromAsTime"]]],[1,"\\n        "],[13],[1,"\\n"]],[3]],null],[1,"    "],[13],[1,"\\n"]],[1,2]],null]],[]],[[[42,[28,[37,2],[[28,[37,2],[[30,0,["slots"]]],null]],null],null,[[[1,"    "],[10,0],[15,0,[29,["cal-time-slot-group cal-time-slot-quad ",[28,[37,3],[[30,5],[30,4,["length"]],false],null]]]],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,4]],null]],null],null,[[[1,"        "],[11,1],[24,0,"cal-time-slot maximize-slot"],[24,"role","button"],[24,"tabindex","0"],[4,[38,4],[[30,0],"openConfirmationView",[30,6]],null],[12],[1,"\\n          "],[1,[30,6,["fromAsTime"]]],[1,"\\n        "],[13],[1,"\\n"]],[6]],null],[1,"    "],[13],[1,"\\n"]],[4,5]],null]],[]]]],["slotsTriplet","index","slot","slotQuad","index","slot"],false,["if","each","-track-array","maximize-calendar-slot","action"]]',
                moduleName: "hotline-web/components/ui-calendar-session-view/template.hbs",
                isStrictMode: !1
            });
            t.default = o
        },
        59901: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "OxpG/mnC",
                block: '[[[41,[30,1],[[[1,"  "],[10,1],[14,0,"chip__content"],[12],[1,[30,1]],[13],[1,"\\n"]],[]],null]],["@label"],false,["if"]]',
                moduleName: "hotline-web/components/ui-chip/template.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        5109: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(84937)),
                s = a(n(19136)),
                o = a(n(20830));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/and", (function() {
                return i.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return s.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return o.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "PWmi8XP+",
                block: '[[[11,"ul"],[24,0,"dropdown-list"],[24,"tabindex","0"],[4,[38,0],[[30,1],[30,0,["onEnter"]]],null],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,2]],null]],null],null,[[[1,"    "],[10,"li"],[15,"aria-selected",[29,[[28,[37,3],[[30,1],[28,[37,4],[[30,4],0],null]],null]]]],[12],[1,"\\n      "],[10,3],[15,"title",[30,3,["label"]]],[14,"role","button"],[14,0,"dropdown-list__button"],[15,"onclick",[28,[37,5],[[30,0],"onSelect",[30,3,["label"]]],null]],[14,6,"javascript:void(0);"],[12],[1,"\\n        "],[1,[28,[35,6],[[30,3,["label"]],"strict"],null]],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[3,4]],null],[13]],["@enableKeyboardNavigation","@items","option","index"],false,["attach-keyboard-navigation","each","-track-array","and","eq","action","sanitize-html"]]',
                moduleName: "hotline-web/components/ui-dropdown-list/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        65061: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(84937)),
                s = l(n(26201)),
                o = l(n(98530)),
                a = l(n(91398));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/and", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-quick-action-slash-menu/template", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-quick-action-slash-menu/component", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-editor/component", (function() {
                return a.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "W9NexFAB",
                block: '[[[41,[28,[37,1],[[30,0,["slashQuickActionsText"]],[30,1]],null],[[[1,"  "],[8,[39,2],null,[["@quickActions","@search","@selectionHandler"],[[30,1],[30,0,["slashQuickActionsText"]],[28,[37,3],[[30,0],[30,0,["handleSelectionHandler"]]],null]]],null],[1,"\\n"]],[]],null],[1,"\\n"],[18,2,[[28,[37,5],null,[["editor"],[[50,"ui-editor",0,null,[["onKeyUp"],[[28,[37,3],[[30,0],[30,0,["keyPressUp"]]],null]]]]]]]]],[1,"\\n"]],["@quickActionsSlashCommandOptions","&default"],false,["if","and","ui-quick-action-slash-menu","action","yield","hash","component"]]',
                moduleName: "hotline-web/components/ui-editor-wrapper/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        81140: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "Yc54hmGT",
                block: '[[[10,"svg"],[14,"width","1.7rem"],[15,"height",[30,1]],[14,"viewBox","0 0 20 20"],[14,"fill","none"],[14,"xmlns","http://www.w3.org/2000/svg","http://www.w3.org/2000/xmlns/"],[15,0,[30,2]],[12],[1,"\\n  "],[10,"path"],[14,"fill-rule","evenodd"],[14,"clip-rule","evenodd"],[14,"d","M10 8.44995C10.8561 8.44995 11.55 9.14391 11.55 9.99995C11.55 10.856 10.8561 11.55 10 11.55C9.14397 11.55 8.45001 10.856 8.45001 9.99995C8.45001 9.14391 9.14397 8.44995 10 8.44995ZM5.09 9.99995C5.08473 9.59681 4.91951 9.21228 4.6307 8.93097C4.34188 8.64965 3.95314 8.49461 3.55 8.49995C3.14514 8.49192 2.75382 8.64578 2.46283 8.92738C2.17184 9.20898 2.00525 9.59505 2 9.99995C2.00525 10.4049 2.17184 10.7909 2.46283 11.0725C2.75382 11.3541 3.14514 11.508 3.55 11.5C3.95314 11.5053 4.34188 11.3502 4.6307 11.0689C4.91951 10.7876 5.08473 10.4031 5.09 9.99995ZM16.45 8.49995C16.8549 8.49192 17.2462 8.64577 17.5372 8.92738C17.8282 9.20898 17.9948 9.59505 18 9.99995C17.9352 10.8051 17.2628 11.4256 16.455 11.4256C15.6472 11.4256 14.9748 10.8051 14.91 9.99995C14.9153 9.59681 15.0805 9.21228 15.3693 8.93097C15.6581 8.64965 16.0469 8.49461 16.45 8.49995Z"],[15,"fill",[30,3]],[12],[13],[1,"\\n"],[13]],["@height","@class","@fillColor"],false,[]]',
                moduleName: "hotline-web/components/ui-ellipsis-icon/template.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        58859: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = u(n(19136)),
                s = u(n(77373)),
                o = u(n(31052)),
                a = u(n(35106)),
                l = u(n(65061)),
                r = u(n(43828));

            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/eq", (function() {
                return i.default
            })), window.define("hotline-web/components/radio-button/component", (function() {
                return s.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            })), window.define("hotline-web/helpers/gte", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-editor-wrapper/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-editor-wrapper/component", (function() {
                return r.default
            }));
            var c = (0, Ember.HTMLBars.template)({
                id: "iSD8HnSR",
                block: '[[[41,[28,[37,1],[[30,0,["feedbackType"]],[30,0,["FEEDBACK_RATING"]]],null],[[[1,"  "],[10,0],[15,0,[29,["csat-rating animated fadeIn speed ",[52,[30,0,["quickActionButtons"]],"feedback-quickactions"]]]],[14,1,"bot-feedback-rating"],[12],[1,"\\n    "],[10,0],[14,0,"vote-yes-outer animated delay-1 slideInUp speed"],[12],[1,"\\n      "],[10,0],[14,0,"vote-yes-wrapper"],[12],[1,"\\n        "],[10,0],[14,0,"vote-yes"],[12],[1,"\\n          "],[10,0],[14,0,"align-middle"],[12],[1,"\\n            "],[10,0],[14,0,"voting-section"],[12],[1,"\\n              "],[10,0],[14,0,"rate"],[12],[1,"\\n                "],[10,"fieldset"],[14,0,"rating"],[14,"role","radiogroup"],[12],[1,"\\n"],[42,[28,[37,3],[[28,[37,3],[[30,0,["feedbackData"]]],null]],null],null,[[[1,"                    "],[8,[39,4],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],[[29,["star",[30,1,["displayOrder"]]]],"rating",[30,1],[30,2],"true",[30,0,["feedback","star"]],[28,[37,5],[[30,0],"submitBotFeedback"],null]]],null],[1,"\\n                    "],[10,"label"],[15,"for",[29,["star",[30,1,["displayOrder"]]]]],[14,0,"star-label bot-feedback-rating-star-label"],[15,"tabindex",[52,[28,[37,1],[[30,0,["feedback","star"]],[30,1,["displayOrder"]]],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,6],["aria_labels.star"],[["star"],["{{rating.displayOrder}}"]]]],[15,"aria-checked",[29,[[28,[37,7],[[30,0,["feedback","star"]],[30,1,["displayOrder"]]],null]]]],[12],[1,[30,1,["label"]]],[13],[1,"\\n"]],[1,2]],null],[1,"                  "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[28,[37,1],[[30,0,["feedbackType"]],[30,0,["FEEDBACK_OPINION_POLL"]]],null],[[[1,"  "],[10,0],[14,0,"bot-feedback-poll"],[12],[1,"\\n"],[42,[28,[37,3],[[28,[37,3],[[30,0,["feedbackData"]]],null]],null],null,[[[1,"        "],[11,"button"],[16,1,[29,["opinion-poll-btn-",[30,4]]]],[24,0,"h-img-button"],[24,4,"button"],[4,[38,5],[[30,0],"submitBotFeedback",[30,3]],null],[12],[1,"\\n          "],[10,1],[14,0,"btn-content"],[12],[1,[30,3,["label"]]],[13],[1,"\\n        "],[13],[1,"\\n"]],[3,4]],null],[1,"  "],[13],[1,"\\n"]],[]],[[[41,[28,[37,1],[[30,0,["feedbackType"]],[30,0,["FEEDBACK_COMMENT"]]],null],[[[1,"  "],[10,0],[14,0,"bot-feedback-comment h-reply"],[12],[1,"\\n    "],[10,0],[15,0,[29,["h-reply h-custom-composer ",[52,[51,[30,0,["hotline","ui","onLine"]]],"is-disabled"]]]],[12],[1,"\\n"],[41,[51,[30,0,["hotline","ui","isDesktop"]]],[[[1,"        "],[11,3],[16,0,[29,["h-reply-container\\n            ",[52,[51,[30,0,["showPlaceholderText"]]],"show-highlight"]]]],[24,6,"#"],[4,[38,5],[[30,0],"beforeSendMessage"],null],[12],[1,"\\n          "],[10,0],[14,0,"h-reply-send"],[12],[1,"\\n            "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"      "],[8,[39,9],null,[["@quickActionsSlashCommandOptions","@onQuickActionSelect"],[[30,0,["feedbackCommentQuickActionsSlashCommandOptions"]],[30,0,["feedbackCommentOnQuickActionSelect"]]]],[["default"],[[[[1,"\\n        "],[8,[30,5,["editor"]],null,[["@onBlur","@onFocus","@emojiSupport","@onKeyDown","@content","@exceedAction","@id","@contentEditable","@placeholder"],[[30,0,["feedbackCommentOnBlur"]],[30,0,["feedbackCommentOnFocus"]],true,[30,0,["keyPressDownFeedbackComment"]],[30,0,["feedbackCommentContent"]],[30,0,["feedbackCommentExceedAction"]],[30,0,["feedbackCommentId"]],true,"aria_labels.feedback_comment"]],null],[1,"\\n      "]],[5]]]]],[1,"\\n"],[41,[30,0,["isFeedbackCommentTextLengthExceeded"]],[[[1,"          "],[10,0],[14,0,"err-feeback-comment"],[12],[1,"\\n            "],[10,1],[14,0,"validation-error-info"],[12],[1,"\\n              "],[10,"img"],[14,0,"validation-error-icon"],[15,"src",[30,0,["images","ValidationErrorIcon"]]],[15,"alt",[28,[37,6],["alt.invalid_input"],null]],[12],[13],[1,"\\n              "],[10,1],[12],[1,[28,[35,6],["alt.bot_feedback_comment_text_limit_exceeded_error"],null]],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],[]]]],[]]]],["rating","index","opinionPollButton","index","wrapper"],false,["if","eq","each","-track-array","radio-button","action","t","gte","unless","ui-editor-wrapper"]]',
                moduleName: "hotline-web/components/ui-feedback/template.hbs",
                isStrictMode: !1
            });
            t.default = c
        },
        13616: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = y(n(31052)),
                s = y(n(84937)),
                o = y(n(96389)),
                a = y(n(45697)),
                l = y(n(19136)),
                r = y(n(66691)),
                u = y(n(35284)),
                c = y(n(15366)),
                d = y(n(20830)),
                p = y(n(31233)),
                m = y(n(72754)),
                h = y(n(19591)),
                f = y(n(93479)),
                g = y(n(40715)),
                v = y(n(10767)),
                b = y(n(27145));

            function y(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/and", (function() {
                return s.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return o.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return a.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return l.default
            })), window.define("hotline-web/helpers/not", (function() {
                return r.default
            })), window.define("hotline-web/helpers/is-same", (function() {
                return u.default
            })), window.define("hotline-web/helpers/format-time", (function() {
                return c.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return d.default
            })), window.define("hotline-web/helpers/contain-valid-text-fragment", (function() {
                return p.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/template", (function() {
                return m.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/component", (function() {
                return h.default
            })), window.define("hotline-web/components/app-offline-form/template", (function() {
                return f.default
            })), window.define("hotline-web/components/app-offline-form/component", (function() {
                return g.default
            })), window.define("hotline-web/components/ui-calendar-picker/template", (function() {
                return v.default
            })), window.define("hotline-web/components/ui-calendar-picker/component", (function() {
                return b.default
            }));
            var w = (0, Ember.HTMLBars.template)({
                id: "QEnjkhwi",
                block: '[[[41,[30,0,["model","isCBInitiated"]],[[[1,"  "],[10,0],[14,0,"h-chat h-fc-co-browse-pad"],[12],[1,"\\n"],[41,[30,0,["isGrpStart"]],[[[1,"      "],[10,0],[14,0,"agent-pic"],[14,"aria-hidden","true"],[12],[1,"\\n"],[41,[30,0,["agentPic","profilePicThumbUrl"]],[[[1,"          "],[10,"img"],[15,"src",[30,0,["agentPic","profilePicThumbUrl"]]],[14,"height","24px"],[14,"width","24px"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]],[[[41,[28,[37,2],[[30,0,["hideName"]],[30,0,["session","appDisplayName"]]],null],[[[1,"          "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n              "],[10,1],[14,0,"avatar-content"],[12],[1,[28,[35,4],[[30,0,["session","appDisplayName"]]],null]],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],[[[41,[30,0,["model","messageUserName"]],[[[1,"          "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["model","messageUserName"]]],null]]]],[12],[1,"\\n              "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                "],[1,[28,[35,4],[[30,0,["model","messageUserName"]]],null]],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "]],[]],null]],[]]]],[]]],[1,"      "],[13],[1,"\\n"]],[]],null],[1,"    "],[10,0],[14,0,"h-conv multiple"],[12],[1,"\\n      "],[10,0],[14,0,"agent-name"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","CHANNEL"]]],null],[[[1,"          "],[1,[30,0,["session","appDisplayName"]]],[1,"\\n"]],[]],[[[41,[28,[37,6],[[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","USER"]]],null]],null],[[[41,[30,0,["hideName"]],[[[1,"            "],[1,[30,0,["session","appDisplayName"]]],[1,"\\n"]],[]],[[[1,"            "],[1,[30,0,["model","messageUserFirstName"]]],[1,"\\n"]],[]]],[1,"        "]],[]],null]],[]]],[1,"      "],[13],[1,"\\n      "],[10,"ul"],[12],[1,"\\n        "],[10,"li"],[12],[1,"\\n          "],[10,0],[14,0,"h-fc-cobrowse"],[12],[1,"\\n"],[41,[30,0,["screenshareControl"]],[[[1,"              "],[10,0],[14,0,"sc-visitor-header"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.header_vc"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"sc-visitor-footer"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.footer_vc"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n                "],[10,3],[15,6,[30,0,["CO_BROWSING_SUPPORT_URL"]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,[28,[35,1],["screenShare.read_more_link"],null]],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,0],[14,0,"sc-visitor-header"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.header"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"sc-visitor-footer"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.footer"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n                "],[10,3],[15,6,[30,0,["CO_BROWSING_SUPPORT_URL"]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,[28,[35,1],["screenShare.read_more_link"],null]],[13],[1,"\\n              "],[13],[1,"\\n"]],[]]],[1,"\\n"],[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","SCREEN_SHARING","DENIED"]]],null],[[[1,"              "],[10,0],[14,0,"sc-visitor-tailer-control"],[12],[1,"\\n                "],[10,1],[14,0,"sc-btn-container last-btn"],[12],[1,"\\n                  "],[10,"button"],[14,0,"sc-deny-btn"],[14,4,"button"],[12],[1,"\\n                    "],[10,"i"],[14,0,"icon icon-ic_cobrowse_close"],[12],[13],[1,"\\n                    "],[1,[28,[35,1],["screenShare.denied"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","SCREEN_SHARING","ACCEPTED"]]],null],[[[1,"              "],[10,0],[14,0,"sc-visitor-tailer-control"],[12],[1,"\\n                "],[10,1],[14,0,"sc-btn-container last-btn"],[12],[1,"\\n                  "],[10,"button"],[14,0,"sc-accept-btn"],[14,4,"button"],[12],[1,"\\n                    "],[10,"i"],[14,0,"icon icon-ic_cobrowse_tick"],[12],[13],[1,"\\n                    "],[1,[28,[35,1],["screenShare.approved"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,0],[14,0,"sc-visitor-tailer-control"],[12],[1,"\\n                "],[10,1],[14,0,"sc-btn-container"],[12],[1,"\\n                  "],[11,"button"],[24,0,"sc-accept-btn"],[24,4,"button"],[4,[38,7],[[30,0],"allowScreenShare",true],null],[12],[1,"\\n                    "],[1,[28,[35,1],["screenShare.allow"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,1],[14,0,"sc-btn-container last-btn"],[12],[1,"\\n                  "],[11,"button"],[24,0,"sc-deny-btn"],[24,4,"button"],[4,[38,7],[[30,0],"denyScreensShare"],null],[12],[1,"\\n                    "],[1,[28,[35,1],["screenShare.deny"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n            "]],[]]]],[]]],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["model","isCBDenied"]],[[[1,"  "],[10,0],[14,0,"h-chat"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","SCREEN_SHARING","CANCELLD"]]],null],[[[1,"      "],[10,0],[14,0,"h-fc-cb-status-messge"],[12],[1," "],[1,[28,[35,1],["screenShare.req_cancelled"],null]],[13],[1,"\\n"]],[]],[[[1,"      "],[10,0],[14,0,"h-fc-cb-status-messge"],[12],[1," "],[1,[28,[35,1],["screenShare.session_end"],null]],[13],[1,"\\n"]],[]]],[1,"  "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","CALENDAR","CANCELLED_BY_USER"]]],null],[[[1,"  "],[10,0],[14,0,"h-chat"],[12],[1,"\\n    "],[10,0],[14,0,"h-calendar-status-message-container"],[12],[1,"\\n      "],[10,0],[14,0,"h-calendar-cancelled-message-text"],[12],[1,"\\n        "],[1,[28,[35,1],["calendar.user_cancelled"],null]],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["showDayStamp"]],[[[1,"    "],[10,0],[14,0,"h-divide"],[12],[1,"\\n      "],[10,0],[12],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"d-line-left"],[12],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"date"],[12],[1,"\\n"],[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["day"]]],[[[1,"              "],[1,[28,[35,1],["conversation.chat_headers.today"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],[30,0,["yesterdayMillis"]]],[["precision"],["day"]]],[[[1,"              "],[1,[28,[35,1],["conversation.chat_headers.yesterday"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"D MMM YYYY"],null]],[1,"\\n            "]],[]]]],[]]],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,"div",""],[14,0,"d-line-right"],[12],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["model","hasReadReceipt"]],[[[1,"    "],[10,0],[14,0,"h-divide"],[12],[1,"\\n      "],[10,0],[12],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"line"],[12],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,1],[12],[10,1],[14,0,"text"],[12],[1,[28,[35,1],["conversation.chat_headers.new"],null]],[13],[13],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"line"],[12],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n  "],[10,0],[15,0,[29,["h-chat ",[52,[30,0,["isArticleView"]],"h-article-view"]," ",[52,[30,0,["containsTranslations"]],"having-translations"]]]],[12],[1,"\\n"],[41,[28,[37,6],[[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","USER"]]],null]],null],[[[41,[30,0,["model","isBot"]],[[[41,[28,[37,2],[[30,0,["model","agentMessagePic"]],[30,0,["isGrpStart"]]],null],[[[1,"          "],[10,0],[15,0,[29,["agent-pic ",[52,[28,[37,6],[[30,0,["agentName"]]],null],"no-agent-name"]]]],[14,"aria-hidden","true"],[12],[1,"\\n            "],[10,"img"],[15,"src",[30,0,["model","agentMessagePic"]]],[14,"height","24px"],[14,"width","24px"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null]],[]],[[[41,[30,0,["isGrpStart"]],[[[1,"          "],[10,0],[15,0,[29,["agent-pic ",[52,[28,[37,6],[[30,0,["agentName"]]],null],"no-agent-name"]]]],[14,"aria-hidden","true"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"              "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,1],["aria-label.agent_profile_pic"],null]],[14,"height","24px"],[14,"width","24px"],[12],[13],[1,"\\n"]],[]],[[[41,[30,0,["agentPic","profilePicThumbUrl"]],[[[41,[28,[37,2],[[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","AGENT"]]],null],[28,[37,2],[[30,0,["hidePic"]],[28,[37,6],[[30,0,["hideName"]]],null]],null]],null],[[[1,"              "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n                "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["agentName"]]],null]]]],[12],[1,"\\n                  "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                    "],[1,[28,[35,4],[[30,0,["agentName"]]],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,"img"],[15,"src",[30,0,["agentPic","profilePicThumbUrl"]]],[14,"height","24px"],[14,"width","24px"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]]]],[]],[[[41,[30,0,["isAwayMessage"]],[[[1,"            "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                  "],[1,[28,[35,4],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[28,[37,2],[[30,0,["hideName"]],[30,0,["session","appDisplayName"]]],null],[[[1,"            "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                "],[10,1],[14,0,"avatar-content"],[12],[1,[28,[35,4],[[30,0,["session","appDisplayName"]]],null]],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["model","messageUserName"]],[[[1,"            "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["model","messageUserName"]]],null]]]],[12],[1,"\\n                "],[10,1],[14,0,"avatar-content"],[12],[1,[28,[35,4],[[30,0,["model","messageUserName"]]],null]],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "]],[]],null]],[]]]],[]]]],[]]]],[]]],[1,"          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["isGrpEnd"]],[[[1,"          "],[10,1],[14,0,"time"],[12],[1,"\\n"],[41,[30,0,["model","createdMillis"]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["hour"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]]],[["interval"],[60000]]]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["day"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"LT"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["week"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ddd, LT"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["year"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"MMM D, LT"],null]],[1,"\\n"]],[]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ll, LT"],null]],[1,"\\n              "]],[]]]],[]]]],[]]]],[]]]],[]],null],[1,"          "],[13],[1,"\\n"]],[]],null]],[]]]],[]],null],[1,"    "],[10,0],[14,0,"h-conv multiple"],[12],[1,"\\n"],[41,[28,[37,2],[[30,0,["agentName"]],[30,0,["isGrpStart"]]],null],[[[1,"        "],[10,0],[14,0,"agent-name"],[12],[1,[28,[35,10],[[30,0,["agentName"]],"strict"],null]],[13],[1,"\\n"]],[]],null],[41,[28,[37,11],[[30,0,["model"]]],null],[[[1,"        "],[8,[39,12],null,[["@message","@isMessageUnauthenticated","@containsTranslations","@showInBothLocales","@isOpen"],[[30,0,["model"]],[30,0,["model","isMessageUnauthenticated"]],[30,0,["containsTranslations"]],[30,0,["showTranslatedText"]],[30,0,["isOpen"]]]],null],[1,"\\n\\n"],[41,[28,[37,5],[[30,0,["model","status"]],[30,0,["MESSAGE_STATUS","NOT_SENT"]]],null],[[[1,"          "],[11,1],[24,0,"fc-resend"],[24,"tabindex","0"],[24,"role","button"],[4,[38,7],[[30,0],"resendMessage",[30,0,["model"]]],null],[12],[1,"\\n            "],[10,"i"],[14,0,"fc-ic-resend"],[12],[13],[1,"\\n            "],[10,1],[14,0,"screen-reader-only"],[12],[1,[28,[35,1],["aria_labels.message_not_sent"],null]],[13],[1,[28,[35,1],["message.resend_action"],null]],[1,"\\n          "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["model","status"]],[30,0,["MESSAGE_STATUS","RETRYING"]]],null],[[[1,"          "],[10,0],[14,0,"time"],[12],[1,"\\n            "],[10,0],[12],[1,"\\n              "],[1,[28,[35,1],["message.pending"],null]],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "]],[]],null]],[]]]],[]],null],[41,[30,0,["containsTranslations"]],[[[1,"        "],[11,1],[24,0,"translated-message-options-text"],[24,"tabindex","0"],[24,"role","button"],[4,[38,7],[[30,0],"toggleTranslatedTextView"],null],[12],[1,"\\n"],[41,[30,0,["showTranslatedText"]],[[[1,"            "],[1,[28,[35,1],["live_translate.hide_original"],null]],[1,"\\n"]],[]],[[[1,"            "],[1,[28,[35,1],["live_translate.show_original"],null]],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["showTimeStamp"]],[[[1,"        "],[10,0],[14,0,"time"],[12],[1,"\\n"],[41,[30,0,["model","isMessagePending"]],[[[1,"            "],[10,0],[12],[1,[28,[35,1],["message.pending"],null]],[13],[1,"\\n"]],[]],[[[41,[28,[37,2],[[28,[37,6],[[30,0,["model","isLastMessageFailed"]]],null],[28,[37,6],[[30,0,["model","isRetryingLastMessage"]]],null]],null],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["hour"]]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]]],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["week"]]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ddd, LT"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["year"]]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"MMM D, LT"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ll, LT"],null]],[1,"\\n            "]],[]]]],[]]]],[]]],[1,"          "]],[]],null]],[]]],[1,"        "],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"],[41,[30,0,["showOfflineForm"]],[[[1,"    "],[8,[39,13],null,[["@extraParams","@sendOfflineMessage"],[[30,0,["extraParams"]],[28,[37,7],[[30,0],"sendOfflineMessage"],null]]],null],[1,"\\n"]],[]],null],[41,[30,0,["shouldDisplayCalendarPicker"]],[[[1,"    "],[8,[39,14],null,[["@message","@sendMessageFromAppConversation","@openCalendarPickerMaximized","@messageMetaData"],[[30,0,["model"]],[28,[37,7],[[30,0],"sendCalendarMessage"],null],[28,[37,7],[[30,0],"openCalendarPickerMaximized"],null],[30,0,["messageMetaData"]]]],null],[1,"\\n"]],[]],null]],[]]]],[]]]],[]]]],[],false,["if","t","and","choose-theme","avatar-content","eq","not","action","is-same","format-time","sanitize-html","contain-valid-text-fragment","ui-unity-message-fragment","app-offline-form","ui-calendar-picker"]]',
                moduleName: "hotline-web/components/ui-message/template.hbs",
                isStrictMode: !1
            });
            t.default = w
        },
        31514: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(35564)),
                s = l(n(75841)),
                o = l(n(78735)),
                a = l(n(81140));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-button-composer/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-button-composer/component", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-quick-action-menu/template", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-ellipsis-icon/template", (function() {
                return a.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "z3mkiP11",
                block: '[[[10,0],[14,0,"actions-button-dropdown"],[12],[1,"\\n  "],[10,0],[14,0,"actions-button-region"],[12],[1,"\\n"],[42,[28,[37,1],[[28,[37,1],[[30,0,["primaryActions"]]],null]],null],null,[[[1,"      "],[8,[39,2],[[24,0,"h-img-button--mini"]],[["@sendButtonMessage","@model","@title"],[[28,[37,3],[[30,0],[30,2]],null],[30,1],[30,1,["label"]]]],null],[1,"\\n"]],[1]],null],[1,"  "],[13],[1,"\\n"],[41,[30,0,["restActions"]],[[[1,"    "],[8,[39,5],null,[["@selectionHandler","@quickActions"],[[28,[37,3],[[30,0],[30,2]],null],[30,0,["restActions"]]]],[["default"],[[[[1,"\\n      "],[10,"button"],[14,0,"h-img-button h-img-button--mini"],[14,4,"button"],[12],[1,"\\n        "],[8,[39,6],null,[["@fillColor","@class","@height"],["#12344D","vertical-align-middle","1rem"]],null],[1,"\\n      "],[13],[1,"\\n    "]],[]]]]],[1,"\\n"]],[]],null],[13]],["button","@sendButtonMessage"],false,["each","-track-array","ui-button-composer","action","if","ui-quick-action-menu","ui-ellipsis-icon"]]',
                moduleName: "hotline-web/components/ui-quick-action-buttons/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        78735: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(90620)),
                s = l(n(42350)),
                o = l(n(5109)),
                a = l(n(96045));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/templates/components/basic-dropdown", (function() {
                return i.default
            })), window.define("hotline-web/components/basic-dropdown", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-dropdown-list/template", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-dropdown-list/component", (function() {
                return a.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "EmD1BkF1",
                block: '[[[10,0],[12],[1,"\\n  "],[8,[39,0],null,[["@calculatePosition"],[[30,1]]],[["default"],[[[[1,"\\n    "],[8,[30,2,["Trigger"]],null,null,[["default"],[[[[1,"\\n      "],[18,5,null],[1,"\\n    "]],[]]]]],[1,"\\n    "],[8,[30,2,["Content"]],[[24,0,"actions-menu"]],null,[["default"],[[[[1,"\\n      "],[8,[39,2],null,[["@items","@selectionHandler","@dropdown"],[[30,3],[30,4],[30,2]]],null],[1,"\\n    "]],[]]]]],[1,"\\n  "]],[2]]]]],[1,"\\n"],[13],[1,"\\n"]],["@menuPosition","dd","@quickActions","@selectionHandler","&default"],false,["basic-dropdown","yield","ui-dropdown-list"]]',
                moduleName: "hotline-web/components/ui-quick-action-menu/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        26201: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n(5109)),
                s = o(n(96045));

            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-dropdown-list/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-dropdown-list/component", (function() {
                return s.default
            }));
            var a = (0, Ember.HTMLBars.template)({
                id: "tglcor8k",
                block: '[[[41,[30,0,["filteredQuickActions","length"]],[[[1,"  "],[10,0],[15,1,[30,0,["slashCmdId"]]],[14,0,"actions-slash"],[12],[1,"\\n    "],[8,[39,1],null,[["@enableKeyboardNavigation","@items","@selectionHandler"],[true,[30,0,["filteredQuickActions"]],[28,[37,2],[[30,0],[30,1]],null]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],["@selectionHandler"],false,["if","ui-dropdown-list","action"]]',
                moduleName: "hotline-web/components/ui-quick-action-slash-menu/template.hbs",
                isStrictMode: !1
            });
            t.default = a
        },
        65986: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(50207)),
                s = a(n(91398)),
                o = a(n(31052));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-attachment-preview/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-editor/component", (function() {
                return s.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "pDUlLJt/",
                block: '[[[41,[30,0,["file","fileData","name"]],[[[1,"  "],[8,[39,1],null,[["@fileData","@imageSelect","@onKeyDown","@clearImage"],[[30,0,["file"]],[30,1],[28,[37,2],[[30,0],"onFileEdit"],null],[30,2]]],null],[1,"\\n"]],[]],null],[1,"  "],[8,[39,3],null,[["@onBlur","@onFocus","@ariaLabel","@onClickEditor","@onKeyDown","@contentEditable","@exceedAction","@testId","@placeholder","@autoFocus"],[[28,[37,2],[[30,0],"focusOut"],null],[28,[37,2],[[30,0],"focusIn"],null],"aria_labels.file_attachment",[28,[37,2],[[30,0],"onClickHandler"],null],[28,[37,2],[[30,0],"onEnterFileUpload"],null],false,[30,3],"attachment-editor","conversation.ce.placeholders.attachment",true]],null],[1,"\\n"],[41,[30,0,["file","fileData","name"]],[[[1,"  "],[11,3],[24,6,"#"],[16,0,[29,["h-reply-container ",[52,[30,0,["file","fileData","name"]]," active"]]]],[24,"role","button"],[4,[38,2],[[30,0],[30,4]],null],[12],[1,"\\n    "],[10,0],[15,0,[29,["h-reply-send ",[52,[30,0,["file","fileData","name"]]," fileAttached"]]]],[12],[1,"\\n      "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[1,"  "],[11,3],[24,6,"#"],[16,0,[29,["h-reply-smiley ",[52,[30,0,["file","fileData","name"]]," fileAttached"]]]],[24,"role","button"],[16,"aria-label",[28,[37,4],["aria_labels.file_attachment"],null]],[4,[38,2],[[30,0],[30,1]],null],[12],[1,"\\n    "],[10,"i"],[14,0,"icons icon-ic_attachment"],[12],[13],[1,"\\n  "],[13],[1,"\\n"]],[]]]],["@imageSelect","@clearImage","@exceedAction","@sendAttachment"],false,["if","ui-attachment-preview","action","ui-editor","t"]]',
                moduleName: "hotline-web/components/ui-upload-attachment/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        88237: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n(62656)),
                s = o(n(33144));

            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/app-conversation/template", (function() {
                return i.default
            })), window.define("hotline-web/components/app-conversation/component", (function() {
                return s.default
            }));
            var a = (0, Ember.HTMLBars.template)({
                id: "VPtU3kpF",
                block: '[[[8,[39,0],null,[["@model","@gotoHome"],[[30,0,["model"]],[28,[37,1],[[30,0],"gotoHome"],null]]],null]],[],false,["app-conversation","action"]]',
                moduleName: "hotline-web/templates/home/channel.hbs",
                isStrictMode: !1
            });
            t.default = a
        },
        99538: function(e, t, n) {
            "use strict";
            t.Z = n.p + "info_red.63f90ddece5b89e17560b1cc02645168.svg"
        }
    }
]);