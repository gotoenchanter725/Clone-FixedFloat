(self.webpackChunkhotline_web = self.webpackChunkhotline_web || []).push([
    [3185], {
        43185: function(e, t, n) {
            var r = window.define;
            r("hotline-web/templates/widget", (function() {
                return n(57327)
            })), r("hotline-web/routes/widget", (function() {
                return n(27420)
            }))
        },
        27420: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return k
                }
            });
            var r, a, i, o, l, s = n(78933),
                u = n(1522),
                d = n(76227),
                c = n(75330),
                f = n(55365),
                p = n(58880),
                m = n(53234),
                h = n(63537),
                b = n(65888),
                v = n(67117),
                w = n(86907),
                E = n(22620),
                g = n(72194),
                y = n(8797),
                M = n(4970);

            function Z(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = (0, h.Z)(e);
                    if (t) {
                        var a = (0, h.Z)(this).constructor;
                        n = Reflect.construct(r, arguments, a)
                    } else n = r.apply(this, arguments);
                    return (0, m.Z)(this, n)
                }
            }
            var k = (r = Ember.inject.service, a = Ember.inject.service, i = function(e) {
                (0, p.Z)(n, e);
                var t = Z(n);

                function n() {
                    var e;
                    (0, d.Z)(this, n);
                    for (var r = arguments.length, a = new Array(r), i = 0; i < r; i++) a[i] = arguments[i];
                    return e = t.call.apply(t, [this].concat(a)), (0, u.Z)((0, f.Z)(e), "locale", o, (0, f.Z)(e)), (0, u.Z)((0, f.Z)(e), "postMessage", l, (0, f.Z)(e)), e
                }
                return (0, c.Z)(n, [{
                    key: "beforeModel",
                    value: function() {
                        this.locale.updateAppLocale()
                    }
                }, {
                    key: "model",
                    value: function(e, t) {
                        var n = this,
                            r = t.to.queryParams.token && t.to.queryParams.token.trim(),
                            a = t.to.queryParams.referrer,
                            i = t.to.queryParams.previewMode,
                            o = v.default.EmberModelUrl.config,
                            l = o.url.replace("{token}", r).replace("{domainName}", a),
                            u = this.session,
                            d = t.to.queryParams.eagerLoad;
                        return r && r.toUpperCase() === v.default.SAMPLE_TOKEN ? null : r && a && u ? (Ember.set(u, "token", r), Ember.set(u, "referrer", a), Ember.set(u, "previewMode", i), Ember.set(u, "config", {}), d ? new Promise(function(e) {
                            var t = this;
                            (0, s.Z)(this, n);
                            var r = !1;
                            Ember.run.later(function() {
                                (0, s.Z)(this, t), r || (window.removeEventListener("message", a), e(this.store.getRequest(o.model, l)))
                            }.bind(this), 3e3);
                            var a = function(t) {
                                var n;
                                r = !0, null != t && null !== (n = t.data) && void 0 !== n && n.payload ? e(t.data.payload) : e(this.store.getRequest(o.model, l)), window.removeEventListener("message", a)
                            }.bind(this);
                            window.addEventListener("message", a), this.postMessage.post({
                                action: v.default.impostor.getFreshChatConfigs
                            })
                        }.bind(this)) : this.store.getRequest(o.model, l)) : null
                    }
                }, {
                    key: "afterModel",
                    value: function(e, t) {
                        var n = this.session,
                            r = this.hotlineUI,
                            a = e && e.appId,
                            i = e && e.appName,
                            o = e && e.userAuthConfig,
                            l = e && (0, y.bulidBetaFeatureFlagObject)(e.betaFeatures);
                        if (e && (e.betaFeatures = l, l[v.default.FEATURES.KUBE_CANARY_ENABLED_FLAG] && (0, M.setWCFCToken)(!0), this.jwt.enable(o && o.jwtAuthEnabled || !1), this.jwt.strict(o && o.strictModeEnabled || !1), this.jwt.isEnabled && (this.jwt.auth.timeoutInterval = o && o.authTimeOutInterval), Ember.set(r, "config", e), Ember.set(n, "appId", a), Ember.set(n, "appName", i), Ember.set(n, "appDisplayName", i), Ember.set(n, "isKbaseEnabled", e.support360App && e.omniKBaseEnabled)), this.session.previewMode && (e.hideMessenger = !1), e.hideMessenger) return t.abort(), this.replaceWith("access-denied"), !1
                    }
                }]), n
            }(g.default.extend(w.default, E.default)), o = (0, b.Z)(i.prototype, "locale", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), l = (0, b.Z)(i.prototype, "postMessage", [a], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), i)
        },
        54314: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, a = (r = n(62392)) && r.__esModule ? r : {
                default: r
            };
            window.define("hotline-web/components/app-loader/template", (function() {
                return a.default
            }));
            var i = (0, Ember.HTMLBars.template)({
                id: "pGdpav8T",
                block: '[[[10,0],[14,0,"h-channel"],[12],[1,"\\n  "],[8,[39,0],null,null,null],[1,"\\n"],[13]],[],false,["app-loader"]]',
                moduleName: "hotline-web/components/app-widget/template.hbs",
                isStrictMode: !1
            });
            t.default = i
        },
        57327: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, a = (r = n(54314)) && r.__esModule ? r : {
                default: r
            };
            window.define("hotline-web/components/app-widget/template", (function() {
                return a.default
            }));
            var i = (0, Ember.HTMLBars.template)({
                id: "A+RpcPGD",
                block: '[[[8,[39,0],null,null,null]],[],false,["app-widget"]]',
                moduleName: "hotline-web/templates/widget.hbs",
                isStrictMode: !1
            });
            t.default = i
        }
    }
]);