(self.webpackChunkhotline_web = self.webpackChunkhotline_web || []).push([
    [8849], {
        48849: function(e, t, n) {
            var i = window.define;
            i("hotline-web/templates/home", (function() {
                return n(87986)
            })), i("hotline-web/routes/home", (function() {
                return n(15490)
            })), i("hotline-web/templates/home/index", (function() {
                return n(50122)
            }))
        },
        33470: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return Z
                }
            });
            var i, o, r, s, a, l, u, c, d, h, f, p = n(1522),
                g = n(76227),
                m = n(75330),
                v = n(55365),
                y = n(58880),
                b = n(53234),
                w = n(63537),
                E = n(77963),
                C = n(65888),
                A = n(21951),
                I = n(80033),
                O = n(67117);

            function T(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, w.Z)(e);
                    if (t) {
                        var o = (0, w.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, b.Z)(this, n)
                }
            }
            var Z = (i = (0, A.classNames)("channel", "animated", "fadeInLeft"), o = (0, A.classNameBindings)("enabledAgentTypingIndicator"), r = Ember.computed.alias("hotlineUI.config.enabledAgentTypingIndicator"), s = Ember.computed("channel.channelId"), a = Ember.computed("lastAgentMessage.messageId"), l = Ember.computed("unreadCount"), u = Ember.computed.gt("lastMessage.messageFragments.length", 0), i(c = o((d = function(e) {
                (0, y.Z)(n, e);
                var t = T(n);

                function n() {
                    var e;
                    (0, g.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(o)), (0, p.Z)((0, v.Z)(e), "enabledAgentTypingIndicator", h, (0, v.Z)(e)), (0, E.Z)((0, v.Z)(e), "USER", O.default.CONVERSATION.USER_TYPE.USER), (0, p.Z)((0, v.Z)(e), "isNonWelcomeMessage", f, (0, v.Z)(e)), e
                }
                return (0, m.Z)(n, [{
                    key: "channelId",
                    get: function() {
                        var e;
                        return null === (e = this.channel) || void 0 === e ? void 0 : e.channelId
                    }
                }, {
                    key: "currentAgent",
                    get: function() {
                        var e = this.lastAgentMessage,
                            t = e && e.get("messageUserAlias");
                        return !!t && this.agentService.getAgentInfo(t)
                    }
                }, {
                    key: "getAriaLabel",
                    get: function() {
                        var e = this.unreadCount;
                        return e ? e <= 9 ? e > 1 ? this.intl.t("aria_labels.unread_msg_other", {
                            count: e
                        }) : this.intl.t("aria_labels.unread_msg_one") : this.intl.t("aria_labels.unread_msg_other", {
                            count: this.intl.t("common.numbers.nine") + "+"
                        }) : ""
                    }
                }]), n
            }(Ember.Component.extend(I.default)), h = (0, C.Z)(d.prototype, "enabledAgentTypingIndicator", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, C.Z)(d.prototype, "channelId", [s], Object.getOwnPropertyDescriptor(d.prototype, "channelId"), d.prototype), (0, C.Z)(d.prototype, "currentAgent", [a], Object.getOwnPropertyDescriptor(d.prototype, "currentAgent"), d.prototype), (0, C.Z)(d.prototype, "getAriaLabel", [l], Object.getOwnPropertyDescriptor(d.prototype, "getAriaLabel"), d.prototype), f = (0, C.Z)(d.prototype, "isNonWelcomeMessage", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), c = d)) || c) || c)
        },
        82169: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return E
                }
            });
            var i, o, r, s, a = n(78933),
                l = n(76227),
                u = n(75330),
                c = n(39806),
                d = n(58880),
                h = n(53234),
                f = n(63537),
                p = n(65888),
                g = n(21951),
                m = n(86907),
                v = n(46377),
                y = n(67117),
                b = n(22620);

            function w(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, f.Z)(e);
                    if (t) {
                        var o = (0, f.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, h.Z)(this, n)
                }
            }
            var E = (i = (0, g.tagName)(""), o = Ember.computed("session.config.content.headers.chat", "hotline.ui.config.title"), i((s = function(e) {
                (0, d.Z)(n, e);
                var t = w(n);

                function n() {
                    return (0, l.Z)(this, n), t.apply(this, arguments)
                }
                return (0, u.Z)(n, [{
                    key: "fetchConversations",
                    value: function() {
                        var e = this,
                            t = y.default.EmberModelUrl,
                            n = this.session,
                            i = this.localds,
                            o = n && n.user,
                            r = n && n.siteId,
                            s = n && n.token,
                            l = i && i.messageAfter || n && n.didMessage,
                            u = t.conversations,
                            c = u.url.replace("{token}", s).replace("{userAlias}", o.alias),
                            d = {
                                src: y.default.CONVERSATION.FETCH.CHANNELS_LOADED,
                                limit: y.default.CONVERSATION.LIMIT
                            };
                        l && (d.messageAfter = l), r && (c += "?siteId=".concat(r)), this.store.getRequest(u.model, c, d).then(function(t) {
                            var n, i, o, r;
                            ((0, a.Z)(this, e), this.isDestroyed && this.isDestroying) || t && t.conversations && ((null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i || null === (o = i.offlineExperience) || void 0 === o || null === (r = o.awayMessage) || void 0 === r ? void 0 : r.localeId) !== y.default.DefaultLocale && this.replaceUnrepliedOfflineMessageWithCurrentLocaleMessage(), this.loadConversation(t.conversations))
                        }.bind(this))
                    }
                }, {
                    key: "headerTitle",
                    get: function() {
                        var e, t, n, i, o, r, s, a = this.intl,
                            l = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.headers) || void 0 === i ? void 0 : i.chat,
                            u = null === (o = this.hotline) || void 0 === o || null === (r = o.ui) || void 0 === r || null === (s = r.config) || void 0 === s ? void 0 : s.title;
                        return l ? (0, v.sanitizeHTML)(this, l, "strict") : u ? (0, v.sanitizeHTML)(this, u, "strict") : a.t("channel.heading_title")
                    }
                }, {
                    key: "didInsertElement",
                    value: function() {
                        (0, c.Z)((0, f.Z)(n.prototype), "didInsertElement", this).apply(this, arguments), this.session && this.session.user && this.session.user.alias && this.fetchConversations()
                    }
                }, {
                    key: "replaceUnrepliedOfflineMessageWithCurrentLocaleMessage",
                    value: function() {
                        var e, t, n, i, o, r, s = this,
                            l = this.conversations,
                            u = this.localds,
                            c = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.offlineExperience) || void 0 === n || null === (i = n.awayMessage) || void 0 === i || null === (o = i.messageFragments) || void 0 === o || null === (r = o.firstObject) || void 0 === r ? void 0 : r.content;
                        l && l.forEach(function(e) {
                            var t = this;
                            (0, a.Z)(this, s);
                            var n = e && e.get("messages").toArray();
                            n && n.forEach(function(e) {
                                (0, a.Z)(this, t), e && !0 === e.get("offlineMessage") && e && !1 === e.get("hasBeenRepliedToOffline") && e.get("messageFragments.firstObject.content") !== c && e.set("messageFragments.firstObject.content", c)
                            }.bind(this))
                        }.bind(this)), u && u.save()
                    }
                }]), n
            }(Ember.Component.extend(b.default, m.default)), (0, p.Z)(s.prototype, "headerTitle", [o], Object.getOwnPropertyDescriptor(s.prototype, "headerTitle"), s.prototype), r = s)) || r)
        },
        5420: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return S
                }
            });
            var i, o, r, s, a, l, u, c, d, h, f, p = n(1522),
                g = n(76227),
                m = n(75330),
                v = n(55365),
                y = n(39806),
                b = n(58880),
                w = n(53234),
                E = n(63537),
                C = n(77963),
                A = n(65888),
                I = n(21951),
                O = n(86907),
                T = n(44493),
                Z = n(37271),
                M = n(4754);

            function R(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, E.Z)(e);
                    if (t) {
                        var o = (0, E.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, w.Z)(this, n)
                }
            }
            var S = (i = (0, I.tagName)(""), o = Ember.computed.gt("faqCategories.length", 3), r = Ember.computed.gt("faqCategories.length", 0), s = Ember.computed("categories", "categories.[]", "session.faqTags"), a = Ember.computed("faqCategories"), l = Ember._action, u = Ember._action, i((d = function(e) {
                (0, b.Z)(n, e);
                var t = R(n);

                function n() {
                    var e;
                    (0, g.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(o)), (0, C.Z)((0, v.Z)(e), "images", {
                        UploadingNew: M.Z
                    }), (0, p.Z)((0, v.Z)(e), "isShowMoreCategories", h, (0, v.Z)(e)), (0, p.Z)((0, v.Z)(e), "isCategoriesPresent", f, (0, v.Z)(e)), e
                }
                return (0, m.Z)(n, [{
                    key: "faqCategories",
                    get: function() {
                        if (this.isKbaseEnabled) return this.store.peekAll("category");
                        var e, t = this.categories,
                            n = null === (e = this.session) || void 0 === e ? void 0 : e.faqTags;
                        return this.filterFAQCategories(t, n)
                    }
                }, {
                    key: "willDestroyElement",
                    value: function() {
                        var e, t;
                        (0, y.Z)((0, E.Z)(n.prototype), "willDestroyElement", this).apply(this, arguments), this.isKbaseEnabled && null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.lastSelectedCategoryId && this.set("hotline.ui.lastSelectedCategoryId", null)
                    }
                }, {
                    key: "sliceCategories",
                    get: function() {
                        return this.faqCategories && this.faqCategories.length > 3 ? this.faqCategories.slice(0, 3) : this.faqCategories
                    }
                }, {
                    key: "selectCategory",
                    value: function(e) {
                        var t, n;
                        !this.isKbaseEnabled || null !== (t = this.hotline) && void 0 !== t && null !== (n = t.ui) && void 0 !== n && n.lastSelectedCategoryId || this.set("hotline.ui.lastSelectedCategoryId", e.categoryId), Z.default.moveFocusTo(".search-input-text"), this.router.send("gotoFAQArticles", e.categoryId)
                    }
                }, {
                    key: "goToCategory",
                    value: function() {
                        this.router.send("gotoFAQCategory"), Z.default.moveFocusTo(".search-input-text")
                    }
                }]), n
            }(Ember.Component.extend(O.default, T.default)), h = (0, A.Z)(d.prototype, "isShowMoreCategories", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), f = (0, A.Z)(d.prototype, "isCategoriesPresent", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, A.Z)(d.prototype, "faqCategories", [s], Object.getOwnPropertyDescriptor(d.prototype, "faqCategories"), d.prototype), (0, A.Z)(d.prototype, "sliceCategories", [a], Object.getOwnPropertyDescriptor(d.prototype, "sliceCategories"), d.prototype), (0, A.Z)(d.prototype, "selectCategory", [l], Object.getOwnPropertyDescriptor(d.prototype, "selectCategory"), d.prototype), (0, A.Z)(d.prototype, "goToCategory", [u], Object.getOwnPropertyDescriptor(d.prototype, "goToCategory"), d.prototype), c = d)) || c)
        },
        56183: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(86907),
                o = n(61230),
                r = n(52340);
            t.default = Ember.Component.extend(i.default, {
                classNames: ["h-channel"],
                brand: Ember.inject.service("brand-check"),
                images: Ember.Object.create({
                    HomeIcon: r.Z
                }),
                isRoutedFromFAQ: Ember.computed.reads("model.isRoutedFromFAQ"),
                isRateLimited: Ember.computed("hotline.ui.{isKbaseCategoryRateLimited,rateLimitedCategoryArticles}", {
                    get: function() {
                        var e, t, n, i;
                        return (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.isKbaseCategoryRateLimited) || (null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.rateLimitedCategoryArticles)
                    }
                }),
                retryRateLimitedUrlIn: Ember.computed.alias("hotline.ui.retryAfter"),
                get hidePoweredBy() {
                    return this.brand.hidePoweredBy
                },
                onScroll: function(e) {
                    var t = e && e.target;
                    t && (parseInt(t.scrollHeight - t.scrollTop - t.clientHeight) <= 0 ? (0, o.addCSSInline)(this.element.querySelector(".bottom-gradient"), "visibility", "hidden") : (0, o.addCSSInline)(this.element.querySelector(".bottom-gradient"), "visibility", "visible"), t.scrollHeight - t.scrollTop - t.clientHeight <= 20 ? (0, o.addClass)(this.element.querySelector(".footer-note"), "show-when-zoom") : (0, o.removeClass)(this.element.querySelector(".footer-note"), "show-when-zoom"), t.scrollTop <= 0 ? (0, o.addCSSInline)(this.element.querySelector(".dummy-bar"), "height", "1.5rem") : (0, o.addCSSInline)(this.element.querySelector(".dummy-bar"), "height", "0"))
                },
                scrollCallback: Ember.computed({
                    get: function() {
                        return this.onScroll.bind(this)
                    }
                }),
                didInsertElement: function() {
                    this._super.apply(this, arguments), (0, o.bindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback), this.onScroll({
                        target: this.element.querySelector(".scroll-section")
                    })
                },
                willDestroyElement: function() {
                    this._super.apply(this, arguments), this.set("model.isRoutedFromFAQ", !1), (0, o.unbindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback)
                },
                actions: {
                    retryCallbackOnRateLimit: function() {
                        this.router.send("retryCallbackOnRateLimitedUrl")
                    }
                }
            })
        },
        68689: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return O
                }
            });
            var i, o, r, s, a, l, u, c = n(78933),
                d = n(1522),
                h = n(76227),
                f = n(75330),
                p = n(55365),
                g = n(39806),
                m = n(58880),
                v = n(53234),
                y = n(63537),
                b = n(77963),
                w = n(65888),
                E = n(54393),
                C = n(67117),
                A = n(23798);

            function I(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, y.Z)(e);
                    if (t) {
                        var o = (0, y.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, v.Z)(this, n)
                }
            }
            var O = (i = Ember._tracked, o = Ember.inject.service, r = Ember.inject.service, s = function(e) {
                (0, m.Z)(n, e);
                var t = I(n);

                function n(e, i) {
                    var o;
                    return (0, h.Z)(this, n), o = t.call(this, e, i), (0, d.Z)((0, p.Z)(o), "isAgentTyping", a, (0, p.Z)(o)), (0, b.Z)((0, p.Z)(o), "agentThread", void 0), (0, b.Z)((0, p.Z)(o), "freddyThread", void 0), (0, b.Z)((0, p.Z)(o), "chatWindow", document.querySelector(".h-conv-chat")), (0, b.Z)((0, p.Z)(o), "onRTSMessageCB", o.onRTSMessage.bind((0, p.Z)(o))), (0, d.Z)((0, p.Z)(o), "rts", l, (0, p.Z)(o)), (0, d.Z)((0, p.Z)(o), "session", u, (0, p.Z)(o)), Ember.addListener(o.rts, "didRTSMessage", o.onRTSMessageCB), o
                }
                return (0, f.Z)(n, [{
                    key: "channelId",
                    get: function() {
                        var e;
                        return null !== (e = this.args.channelId) && void 0 !== e ? e : void 0
                    }
                }, {
                    key: "willDestroy",
                    value: function() {
                        (0, g.Z)((0, y.Z)(n.prototype), "willDestroy", this).apply(this, arguments), Ember.removeListener(this.rts, "didRTSMessage", this.onRTSMessageCB)
                    }
                }, {
                    key: "hideTypingIndicator",
                    value: function() {
                        var e = this.agentThread,
                            t = this.freddyThread;
                        this.isAgentTyping = !1, e && clearTimeout(e), t && clearTimeout(t)
                    }
                }, {
                    key: "showTypingIndicator",
                    value: function(e) {
                        var t = this,
                            n = this.chatWindow,
                            i = this.agentThread;
                        this.isAgentTyping = !0, n && n.scrollTop >= n.scrollHeight - n.offsetHeight - 30 && !document.querySelector(".h-conv-chat .notification-container") && A.default.scrollTo(n, n.scrollHeight, 1500), i && clearTimeout(i), this.agentThread = setTimeout(function() {
                            (0, c.Z)(this, t), this.isDestroying || this.isDestroyed || (this.isAgentTyping = !1)
                        }.bind(this), e)
                    }
                }, {
                    key: "onRTSMessage",
                    value: function(e) {
                        var t = this,
                            n = e && e.userId,
                            i = this.channelId,
                            o = this.session.user.id;
                        if ("is_typing" === e.action && e.channelId && e.channelId === i && o && o !== parseInt(n, 10)) this.showTypingIndicator(C.default.TYPING_INDICATOR_DURATION.AGENT);
                        else if ("MESSAGE_RECEIVED" === e.type && e.conversation && e.conversation.channelId === i) {
                            o === (e.conversation && e.conversation.messages && e.conversation.messages.length && e.conversation.messages[0].messageUserId) ? e.conversation && e.conversation.status === C.default.CONVERSATION.CONVERSATION_STATUS.FREDDY_BOT && (this.hideTypingIndicator(), this.freddyThread = setTimeout(function() {
                                (0, c.Z)(this, t), this.showTypingIndicator(C.default.TYPING_INDICATOR_DURATION.FREDDY_BOT)
                            }.bind(this), 1e3)) : this.hideTypingIndicator()
                        }
                    }
                }]), n
            }(E.default), a = (0, w.Z)(s.prototype, "isAgentTyping", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }), l = (0, w.Z)(s.prototype, "rts", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), u = (0, w.Z)(s.prototype, "session", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), s)
        },
        24175: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return v
                }
            });
            var i, o, r, s = n(1522),
                a = n(76227),
                l = n(55365),
                u = n(58880),
                c = n(53234),
                d = n(63537),
                h = n(77963),
                f = n(65888),
                p = n(54393),
                g = n.p + "freshchat_logo.f6e2dc08072c0bf69ca4c005e561b7dc.png";

            function m(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, d.Z)(e);
                    if (t) {
                        var o = (0, d.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, c.Z)(this, n)
                }
            }
            var v = (i = Ember.inject.service, o = function(e) {
                (0, u.Z)(n, e);
                var t = m(n);

                function n() {
                    var e;
                    (0, a.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), u = 0; u < i; u++) o[u] = arguments[u];
                    return e = t.call.apply(t, [this].concat(o)), (0, s.Z)((0, l.Z)(e), "session", r, (0, l.Z)(e)), (0, h.Z)((0, l.Z)(e), "images", {
                        Logo: g
                    }), e
                }
                return n
            }(p.default), r = (0, f.Z)(o.prototype, "session", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), o)
        },
        15366: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(78933),
                o = n(26894),
                r = n(5016);

            function s(e, t, n) {
                return (e - t) * (e - n) <= 0
            }
            t.default = Ember.Helper.extend({
                compute: function(e, t) {
                    var n = this,
                        a = (0, o.Z)(e, 2),
                        l = a[0],
                        u = a[1];
                    if (l && !isNaN(l)) {
                        var c, d = 0,
                            h = (0, r.default)(l).diff((0, r.default)(), "seconds"),
                            f = !0;
                        if (t && t.updateOnInterval && (f = Boolean(t.updateOnInterval)), u) c = (0, r.default)(l).format(u);
                        else try {
                            c = h < 44 ? (0, r.default)(l).fromNow() : (0, r.default)().fromNow()
                        } catch (e) {
                            c = (0, r.default)(l).format("ddd, LT")
                        }
                        return f && (this.clearTimer(), d = function(e) {
                            return s(e, -89, 89) ? 3 : s(e, -5340, 5340) ? 120 : s(e, -86400, 86400) ? 1800 : 86400
                        }(h), this.intervalTimer = setInterval(function() {
                            var e = this;
                            (0, i.Z)(this, n), Ember.run(function() {
                                return (0, i.Z)(this, e), this.recompute()
                            }.bind(this))
                        }.bind(this), parseInt(1e3 * d, 10))), c
                    }
                    return ""
                },
                clearTimer: function() {
                    clearInterval(this.intervalTimer)
                },
                destroy: function() {
                    this.clearTimer()
                }
            })
        },
        15490: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return re
                }
            });
            var i, o, r, s, a, l, u, c, d, h, f, p, g, m, v, y, b, w, E, C, A, I, O, T, Z, M = n(78933),
                R = n(1522),
                S = n(76227),
                _ = n(75330),
                k = n(55365),
                P = n(39806),
                N = n(58880),
                U = n(53234),
                B = n(63537),
                D = n(77963),
                L = n(65888),
                j = n(81387),
                F = n(72194),
                q = n(67117),
                H = n(8797),
                x = n(86907),
                V = n(44493),
                Q = n(56612),
                z = n(22620),
                G = n(17067),
                K = n(5016),
                W = n(8209),
                Y = n(57214),
                J = n(4779),
                X = n(80033),
                $ = n(62588),
                ee = n(84319);

            function te(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function ne(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? te(Object(n), !0).forEach((function(t) {
                        (0, D.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : te(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function ie(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, B.Z)(e);
                    if (t) {
                        var o = (0, B.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, U.Z)(this, n)
                }
            }
            var oe = q.default.CONVERSATION.MESSAGE_TYPE.IMAGE,
                re = (i = Ember.inject.service, o = Ember.inject.service, r = Ember.inject.service, s = Ember.inject.service, a = Ember.inject.service, l = Ember.inject.service("window-listener"), u = Ember.computed, c = Ember.computed("isKbaseEnabled"), d = Ember.computed("commandHelper"), h = Ember.computed, f = Ember.computed, p = Ember.computed, g = (0, j.observes)("session.user.id"), m = Ember._action, v = Ember._action, y = Ember._action, b = Ember._action, w = Ember._action, E = function(e) {
                    (0, N.Z)(n, e);
                    var t = ie(n);

                    function n() {
                        var e;
                        (0, S.Z)(this, n);
                        for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                        return e = t.call.apply(t, [this].concat(o)), (0, R.Z)((0, k.Z)(e), "ruleEngine", C, (0, k.Z)(e)), (0, R.Z)((0, k.Z)(e), "notification", A, (0, k.Z)(e)), (0, D.Z)((0, k.Z)(e), "fetchFaqs", !1), (0, R.Z)((0, k.Z)(e), "messageStacker", I, (0, k.Z)(e)), (0, R.Z)((0, k.Z)(e), "postMessage", O, (0, k.Z)(e)), (0, R.Z)((0, k.Z)(e), "user", T, (0, k.Z)(e)), (0, R.Z)((0, k.Z)(e), "windowListener", Z, (0, k.Z)(e)), e
                    }
                    return (0, _.Z)(n, [{
                        key: "model",
                        value: function() {
                            var e, t = null === (e = this.hotline) || void 0 === e ? void 0 : e.ui,
                                n = t && t.userBehaviour,
                                i = t && t.channels,
                                o = t && t.hours,
                                r = n && n.eventRules,
                                s = t && t.rspTime,
                                a = t && t.offlineExperience;
                            return Ember.RSVP.hash({
                                channels: i,
                                hours: o,
                                rspTime: s,
                                eventRules: r,
                                offlineExperience: a
                            })
                        }
                    }, {
                        key: "afterModel",
                        value: function(e) {
                            var t, i, o;
                            (null === (t = this.session.integrations) || void 0 === t ? void 0 : t.shopify) && Ember.addListener(this.rts, "didCampaignMessage", this.onCampaignMessageCB), null !== (i = this.session) && void 0 !== i && null !== (o = i.user) && void 0 !== o && o.id || this.hotline.broadcastConversationLoaded(), this.windowListener.bindNetworkEvents(), e && (this.setupModel(e), this.getAgentsInformationForRules(e), this.getAgentsInformationForChannels(e)), (0, P.Z)((0, B.Z)(n.prototype), "afterModel", this).call(this)
                        }
                    }, {
                        key: "getAgentsInformationForRules",
                        value: function(e) {
                            var t = e && e.eventRules;
                            if (t && t.length > 0)
                                for (var n = t.length - 1; n >= 0; n--) {
                                    var i = t[n];
                                    i.agent && this.store.pushPayload("agent", {
                                        agent: i.agent
                                    }), i.serviceAccount && this.store.pushPayload("agent", {
                                        agent: i.serviceAccount
                                    })
                                }
                        }
                    }, {
                        key: "getAgentsInformationForChannels",
                        value: function(e) {
                            var t = e && e.channels;
                            if (t && t.length > 0)
                                for (var n = t.length - 1; n >= 0; n--) {
                                    var i = t[n];
                                    i.serviceAccount && this.store.pushPayload("agent", {
                                        agent: i.serviceAccount
                                    })
                                }
                        }
                    }, {
                        key: "setupModel",
                        value: function(e) {
                            this.postModel(e), this.isKbaseEnabled ? (this.resetDsFaq(), this.fetchKbaseCategories()) : this.loadFAQS()
                        }
                    }, {
                        key: "fetchKbaseCategories",
                        value: function() {
                            var e = this;
                            this.getKbaseCategories(!0).then(function(t) {
                                var n, i;
                                (0, M.Z)(this, e), t && null !== (n = t.categories) && void 0 !== n && n.length && Ember.set(this.session, "isKbaseFaqAvailable", !0), Ember.setProperties(null === (i = this.hotline) || void 0 === i ? void 0 : i.ui, {
                                    isKbaseCategoryRateLimited: !1,
                                    retryingRateLimitedUrl: !1
                                })
                            }.bind(this), function(t) {
                                var n;
                                (0, M.Z)(this, e);
                                var i, o, r = t && t.errors && t.errors.length && t.errors[0];
                                r && r.status === q.default.HTTP_STATUS_CODES.RATE_LIMIT_ERROR ? Ember.setProperties(null === (i = this.hotline) || void 0 === i ? void 0 : i.ui, {
                                    isKbaseCategoryRateLimited: !0,
                                    retryAfter: r.retryAfter
                                }) : Ember.set(null === (o = this.hotline) || void 0 === o ? void 0 : o.ui, "isKbaseCategoryRateLimited", !1);
                                Ember.set(null === (n = this.hotline) || void 0 === n ? void 0 : n.ui, "retryingRateLimitedUrl", !1)
                            }.bind(this))
                        }
                    }, {
                        key: "postModel",
                        value: function(e) {
                            var t, n, i, o, r, s = null === (t = this.hotline) || void 0 === t ? void 0 : t.ui;
                            e.hours && (e.hours.operatingHours && (e.hours.operatingHours.clientTimeInMillis = (new Date).getTime()), Ember.set(s, "hours", e.hours), this.processOperatingHours(), this.pollster || ((r = Y.Z.create({
                                onPoll: this.processOperatingHours.bind(this),
                                interval: 6e4
                            })).start(), this.set("pollster", r))), e.rspTime && Ember.set(s, "rspTime", e.rspTime), Ember.set(s, "userBehaviour", {
                                eventRules: e.eventRules
                            }), -1 !== (null === (n = this.transition) || void 0 === n ? void 0 : n.targetName.indexOf("channels.index")) && this.openChannel(), this.connectSocket(), this.isJWTStrictMode && Ember.addListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB), null !== (i = this.session) && void 0 !== i && null !== (o = i.user) && void 0 !== o && o.id || s.dsLoaded || (Ember.set(s, "dsLoaded", !0), this.postMessage.post({
                                action: "datastore_loaded"
                            })), Ember.set(s, "homeRouteLoadMillis", (new Date).getTime()), e.isRoutedFromFAQ = this.transition.to.queryParams.isRoutedFromFAQ
                        }
                    }, {
                        key: "didAuthUserCB",
                        get: function() {
                            return this.didAuthenticateUser.bind(this)
                        }
                    }, {
                        key: "faqRouteName",
                        get: function() {
                            return this.isKbaseEnabled ? "home.kbase-faq" : "home.faqs"
                        }
                    }, {
                        key: "helper",
                        get: function() {
                            return J.Z.create({
                                scope: this
                            })
                        }
                    }, {
                        key: "didAuthenticateUser",
                        value: function() {
                            this.jwt.auth.expired ? this.disconnectSocket(!1) : this.jwt.auth.user && this.connectSocket()
                        }
                    }, {
                        key: "canShowBusinessClosedBanner",
                        value: function(e) {
                            var t, n, i, o, r, s, a, l = this;
                            return !!e && (1 === e.filter(function(e) {
                                return (0, M.Z)(this, l), e.enabled && e.defaultBhr
                            }.bind(this)).length && !(null === (t = this.hotline) || void 0 === t || null === (n = t.ui) || void 0 === n || null === (i = n.config) || void 0 === i || !i.messengerVisibility || (null === (o = this.hotline) || void 0 === o || null === (r = o.ui) || void 0 === r || null === (s = r.config) || void 0 === s || null === (a = s.messengerVisibility) || void 0 === a ? void 0 : a.selected) !== q.default.messengerVisibilityOptions.businessHours))
                        }
                    }, {
                        key: "isCurrentDayInHolidays",
                        value: function(e, t) {
                            var n = !1,
                                i = e && e.length;
                            if (i && t)
                                for (var o = 0; o < i; o++) {
                                    var r = e[o],
                                        s = String(r.date).toUpperCase(),
                                        a = (0, K.default)(W.default.convert(new Date, t.replace(" - ", "/"), !0));
                                    if (a && s === a.format("MMM DD").toUpperCase() || s === a.format("MMM D").toUpperCase()) {
                                        n = !0;
                                        break
                                    }
                                }
                            return n
                        }
                    }, {
                        key: "processOperatingHours",
                        value: function() {
                            var e, t, n, i, o, r, s = this,
                                a = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.hours,
                                l = a && a.operatingHours,
                                u = void 0,
                                c = this.canShowBusinessClosedBanner(l);
                            Ember.set(null === (n = this.hotline) || void 0 === n ? void 0 : n.ui, "awayMessage", []);
                            for (var d = 0, h = l.length; d < h; d++) {
                                var f, p, g = l[d],
                                    m = (new Date).getTime(),
                                    v = this.isCurrentDayInHolidays(g.holidays, g.timezone),
                                    y = void 0,
                                    b = void 0,
                                    w = void 0,
                                    E = !0,
                                    C = void 0;
                                if (Ember.set(g, "clientTimeInMillis", (new Date).getTime()), g)
                                    if (g.enabled) {
                                        if (!v)
                                            if (y = m - l.clientTimeInMillis, w = ((b = (0, K.default)(W.default.convert(g.serverTimeInMillis + y, g.timezone.replace(" - ", "/"), !0))).day() + 6) % 7, "true" !== g.working[w]) E = !0;
                                            else
                                                for (var A = 0, I = (C = this.workingHours(g.days[w])).length; A < I; A++) {
                                                    var O = C[A],
                                                        T = parseInt(O[0], 10),
                                                        Z = parseInt(O[1], 10),
                                                        R = b.clone().startOf("day").add(T, "s"),
                                                        S = b.clone().startOf("day").add(Z, "s");
                                                    if (b.isAfter(R) && b.isBefore(S)) {
                                                        E = !1, c && (u = S.diff(b));
                                                        break
                                                    }
                                                }
                                    } else E = !1;
                                else E = !1;
                                var _ = {
                                    operatingHoursId: g.operatingHoursId,
                                    awayMessage: E ? g.awayMessage : "",
                                    defaultBhr: g.defaultBhr,
                                    enabled: g.enabled
                                };
                                null === (f = this.hotline) || void 0 === f || null === (p = f.ui) || void 0 === p || p.awayMessage.push(_)
                            }
                            c && (null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o || !o.triggerTimerForBusinessHours) && u && u > 0 && (Ember.set(null === (r = this.hotline) || void 0 === r ? void 0 : r.ui, "triggerTimerForBusinessHours", !0), this.logger.log("Countdown timer to show Business Closed banner after end of Business hours has begun. Duration: ".concat(u, " milliseconds")), Ember.run.later(function() {
                                var e, t;
                                (0, M.Z)(this, s), Ember.set(null === (e = this.hotline) || void 0 === e ? void 0 : e.ui, "showBusinessClosedBanner", !0), Ember.set(null === (t = this.hotline) || void 0 === t ? void 0 : t.ui, "triggerTimerForBusinessHours", q.default.messengerVisibilityOptions.businessHours), this.logger.log("Countdown timer to show Business Closed banner has completed. Duration: ".concat(u, " milliseconds"))
                            }.bind(this), u))
                        }
                    }, {
                        key: "workingHours",
                        value: function(e) {
                            var t = this;
                            return e.substr(0, e.length - 1).split(";").reduce(function(e, n, i) {
                                (0, M.Z)(this, t);
                                var o = Math.floor(i / 2);
                                return e[o] = [].concat(e[o] || [], n), e
                            }.bind(this), [])
                        }
                    }, {
                        key: "onAdvicePullCB",
                        get: function() {
                            return this.onAdvicePull.bind(this)
                        }
                    }, {
                        key: "onUserMessageCB",
                        get: function() {
                            return this.onUserMessage.bind(this)
                        }
                    }, {
                        key: "onCampaignMessageCB",
                        get: function() {
                            return this.onCampaignMessage.bind(this)
                        }
                    }, {
                        key: "onCampaignMessage",
                        value: function(e, t, n) {
                            var i, o, r = this,
                                s = null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o ? void 0 : o.userBehaviour.eventRules;
                            (s = s.find(function(t) {
                                return (0, M.Z)(this, r), t.ruleId === e.campaignId
                            }.bind(this))).command.delay = e.timeOnCurrentPage ? (0, H.convertOperand)("NUMBER", e.timeOnCurrentPage) : 0, s.command.ruleId = e.campaignId, this.commandHelper.execute([s])
                        }
                    }, {
                        key: "disconnectSocket",
                        value: function() {
                            var e, t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                            !this.rts.connection || this.rts.connecting || this.rts.reconnecting || (Ember.removeListener(this.rts, "didUserMessage", this.onUserMessageCB), (null === (e = this.session.integrations) || void 0 === e ? void 0 : e.shopify) && Ember.removeListener(this.rts, "didCampaignMessage", this.onCampaignMessageCB), Ember.removeListener(this.rts, "didAdvicePull", this.onAdvicePullCB), t && this.rts.connection.unsubscribeAll(), this.rts.close())
                        }
                    }, {
                        key: "connectSocket",
                        value: function() {
                            var e, t, n, i, o;
                            this.rts.connection || this.rts.connecting || this.rts.reconnecting || null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t || !t.id ? this.rts.connection && this.rts.didDisconnect && !this.rts.connecting && !this.rts.reconnecting && null !== (n = this.session) && void 0 !== n && null !== (i = n.user) && void 0 !== i && i.id && (this.rts.close(), this.rts.create()) : (Ember.addListener(this.rts, "didUserMessage", this.onUserMessageCB), Ember.addListener(this.rts, "didAdvicePull", this.onAdvicePullCB), (null === (o = this.session.integrations) || void 0 === o ? void 0 : o.shopify) && this.rts.close(), this.rts.create())
                        }
                    }, {
                        key: "sessionUserObserver",
                        value: function() {
                            var e, t;
                            null !== (e = this.session) && void 0 !== e && null !== (t = e.user) && void 0 !== t && t.id ? this.connectSocket() : this.disconnectSocket()
                        }
                    }, {
                        key: "onUserMessage",
                        value: function(e, t, n) {
                            var i, o, r = this,
                                s = null === (i = this.hotline) || void 0 === i ? void 0 : i.ui,
                                a = this.messageStacker,
                                l = this.session,
                                u = l && l.config,
                                c = u && u.agent,
                                d = c && c.hideName,
                                h = l && l.appDisplayName || l.appName,
                                f = this.store,
                                p = this.localds,
                                g = p.get("seq"),
                                m = this.conversations,
                                v = this.displayChannels,
                                y = e && e.type;
                            if (this.isJWTStrictMode) {
                                if (this.jwt.auth.expiredAt || this.jwt.auth.scheduled || this.jwt.auth.expired) return void this.disconnectSocket(!1);
                                if (this.isJwtExpired()) return this.disconnectSocket(!1), void this.initiateSendingMode()
                            }
                            if (e.userRules) {
                                var b = e.userRules.filter(function(e) {
                                    return (0, M.Z)(this, r), !(s.prevExecutedRuleIds.length > 0 && s.prevExecutedRuleIds.includes(e.ruleId))
                                }.bind(this));
                                b.length > 0 && b.forEach(function(e) {
                                    (0, M.Z)(this, r), e.command.delay = 0, e.command.ruleId = e.ruleId
                                }.bind(this)), b.length > 0 && this.commandHelper.execute(b)
                            } else {
                                var w, E = e && e.conversation,
                                    C = E && E.messages && E.messages.length && E.messages[0],
                                    A = E && E.channelId,
                                    I = m.findBy("channelId", A),
                                    O = (0, H.findObjectByValueProperty)(v, A, "channelId");
                                if (C && C.messageType === q.default.CONVERSATION.MESSAGE_TYPE.SCREEN_SHARING.ENDED && window.parent && this.postMessage.post({
                                        event_id: "cobrowsingStop"
                                    }), this.send("ackMessageInRTS", C, t), "MESSAGE_RECEIVED" === y)
                                    if (w = (C && C.messageUserType) === q.default.CONVERSATION.USER_TYPE.USER ? "message_from_user" : "message_from_agent", this.rts.checkForSubscription(), C) {
                                        var T = C.messageUserName;
                                        q.default.CONVERSATION.MESSAGE_TYPE.BOT !== C.messageType && q.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT !== C.messageType && (T = d || !T ? h : T.split(" ")[0]), this.postMessage.post({
                                            action: w,
                                            data: {
                                                message: {
                                                    messageFragments: C.messageFragments,
                                                    messageUserName: T,
                                                    appName: h,
                                                    createdMillis: C.createdMillis,
                                                    channelId: A,
                                                    conversationId: E.conversationId,
                                                    stepId: C.flowStepId
                                                }
                                            }
                                        })
                                    }
                                if (1 === n || 0 === g.id || n === g.id + 1) {
                                    if ("MESSAGE_RECEIVED" === y || "COBOROWSING_STATUS_UPDATED" === y) {
                                        if (E) {
                                            var Z, R, S, _, k, P, N = C && C.messageId,
                                                U = C && C.marketingId,
                                                B = C && C.msgHopId,
                                                D = C && C.messageUserType,
                                                L = I && I.get("messages"),
                                                j = this.notification;
                                            if (-1 !== oe.indexOf(C.messageType) && (0, H.resizeImage)(C), A && Ember.set(C, "channelId", A), Ember.set(C, "delivered", !0), L) {
                                                Z = N && L.findBy("messageId", N) || U && L.findBy("marketingId", U) || B && L.findBy("msgHopId", B), C && C.flowStepId && 0 !== C.messageUserType && (P = (0, H.updateAndGetLastFlowMessage)(L, C)), C && C.ruleId && 0 !== C.messageUserType && (R = (0, H.updateAndGetLastAutoMessage)(L, C)), C && C.source === q.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE && (S = (k = (_ = L.filter(function(e) {
                                                    return (0, M.Z)(this, r), e.get("source") === q.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE && e.get("needsUpdation")
                                                }.bind(this))) && _.length) ? _[k - 1] : null);
                                                var F = L.filterBy("offlineMessage", !0).filterBy("hasBeenRepliedToOffline", !1);
                                                if ((C && C.messageUserType === q.default.CONVERSATION.USER_TYPE.AGENT && F.length || C.internalMeta) && F.length && F[F.length - 1].set("hasBeenRepliedToOffline", !0), Z && B && Z.get("msgHopId") && N && Z.get("messageId") && Z.get("msgHopId") === B && Z.get("messageId") !== N && (Z = null), Z) "COBOROWSING_STATUS_UPDATED" === y ? Z.set("messageType", C.messageType) : f.cloneRecord(Z, C), this.logger.log("Updating Message");
                                                else if (R) Ember.set(R, "messageUserAlias", C.messageUserAlias), (0, H.checkAndUpdateReadMillis)(R.get("createdMillis"), C.createdMillis, I), f.cloneRecord(R, C), this.logger.log("Updated automessage via Websockets");
                                                else if (P) Ember.set(P, "messageUserAlias", C.messageUserAlias), (0, H.checkAndUpdateReadMillis)(P.get("createdMillis"), C.createdMillis, I), f.cloneRecord(P, C), this.logger.log("Updated flowmessage via Websockets");
                                                else if (S) {
                                                    Ember.set(S, "messageUserAlias", C.messageUserAlias), f.cloneRecord(S, C), S.set("needsUpdation", !1);
                                                    for (var x = 0; x < k - 1; x++) _[x].set("needsUpdation", !1);
                                                    this.logger.log("Updated offlineMessage via Websockets")
                                                } else {
                                                    var V = f.createRecord("message", C),
                                                        Q = L.lastObject;
                                                    if (L.firstObject && L.firstObject.messageId && L.firstObject.createdMillis > C.createdMillis) L.unshiftObjects([V]);
                                                    else if (Q && Q.messageId) {
                                                        for (var z = L.length - 1; z >= 0; z--) {
                                                            if (L.objectAt(z).createdMillis < C.createdMillis) {
                                                                L.insertAt(z + 1, V);
                                                                break
                                                            }
                                                        }
                                                        z < 0 && L.pushObject(V)
                                                    } else L.pushObject(V);
                                                    this.logger.log("Adding Message"), C && C.messageUserType === q.default.CONVERSATION.USER_TYPE.USER && this.postMessage.post({
                                                        action: "notify_frame",
                                                        data: "close"
                                                    })
                                                }
                                            } else {
                                                var G, K = Ember.A([]);
                                                if (K.pushObject(f.createRecord("message", C)), G = f.createRecord("conversation", {
                                                        conversationId: E.conversationId,
                                                        channelId: E.channelId,
                                                        messages: K
                                                    }), m) m.pushObject(G);
                                                else {
                                                    var W = Ember.A([]);
                                                    W.pushObject(G), p.set("conversations", W)
                                                }
                                            }
                                            o = C.createdMillis, p.set("messageAfter", o), this.send("save", O && !Z), O && (D && !C.ruleId ? (a.isSameAsLastAgentChannelId(C.channelId) ? Ember.setProperties(s, {
                                                lockAgentMessage: !0
                                            }) : s.lockAgentMessage || Ember.setProperties(s, {
                                                lockAgentMessage: void 0
                                            }), a.setLastAgentMessage(C), Ember.run.later(function() {
                                                (0, M.Z)(this, r), j.playSound()
                                            }.bind(this), 0)) : s.lockAgentMessage || (Ember.setProperties(s, {
                                                lockAgentMessage: void 0
                                            }), a.resetLastAgentMessages())), I.set("status", E.status)
                                        }
                                    } else "CONVERSATION_RESOLVED" === y ? (E.hasPendingCsat && (I.set("csat", f.createRecord("csat", E.csat)), I.set("hasPendingCsat", E.hasPendingCsat)), I.set("status", E.status), this.send("save")) : "CSAT_RESPONSE_RECEIVED" === y ? I.get("csat") && (Ember.set(I, "hasPendingCsat", !1), this.send("save")) : "GDPR_USER_DELETED" === y && (this.user.delete(), this.send("reset", null, !0));
                                    p.set("seq", {
                                        id: n,
                                        millis: o
                                    }), this.send("save")
                                } else this.populateConversation(q.default.CONVERSATION.FETCH.RTS_SEQ_ID_MISMATCH, null, g.millis)
                            }
                        }
                    }, {
                        key: "onAdvicePull",
                        value: function(e) {
                            var t = e && e.src,
                                n = this.router.currentRouteName,
                                i = n && "home.faqs" !== n;
                            this.populateConversation(t, e.channel && i ? this.openChannel : null, e && e.reset ? 0 : null)
                        }
                    }, {
                        key: "openChannel",
                        value: function() {
                            var e, t, n = this.displayChannels,
                                i = n && n.length,
                                o = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t ? void 0 : t.openChannelId;
                            if (i && 1 === i && !this.isFAQAvailable) this.transition.abort(), this.replaceWith("home.channel", n[0].channelId);
                            else if (o) {
                                var r = n.findBy("channelId", o);
                                r && r.channelId && this.replaceWith("home.channel", r.channelId)
                            }
                        }
                    }, {
                        key: "populateConversation",
                        value: function() {
                            var e = this,
                                t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                                i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                                o = q.default.EmberModelUrl,
                                r = o.conversations,
                                s = this.session,
                                a = s && s.user,
                                l = r.url.replace("{token}", s.token).replace("{userAlias}", a.alias),
                                u = s && s.siteId,
                                c = null !== i ? i : s && s.didMessage,
                                d = t ? {
                                    src: t
                                } : {
                                    src: q.default.CONVERSATION.FETCH.DEFAULT
                                };
                            d = ne(ne({}, d), {}, {
                                limit: q.default.CONVERSATION.LIMIT
                            }), c && (d.messageAfter = c), u && (l += "?siteId=".concat(u)), this.store.getRequest(r.model, l, d).then(function(t) {
                                var o, r = this;
                                (0, M.Z)(this, e);
                                var s = t && t.errorCode,
                                    a = null === (o = this.hotline) || void 0 === o ? void 0 : o.ui;
                                if (a && a.helpNote && Ember.set(a, "helpNote", void 0), t && t.conversations && !s) {
                                    var l = this.conversations,
                                        u = [];
                                    if (0 === i && l) {
                                        l.forEach(function(e) {
                                            var t = this;
                                            (0, M.Z)(this, r);
                                            var n = [];
                                            if (e.get("messages").forEach(function(e) {
                                                    (0, M.Z)(this, t), 0 === e.get("messageUserType") && e.get("status") === q.default.MESSAGE_STATUS.PENDING && n.push(e)
                                                }.bind(this)), n.length) {
                                                var i = e.serialize();
                                                e.messages = n, u.push(i)
                                            }
                                        }.bind(this));
                                        var c = t && t.conversations;
                                        c && c.forEach(function(e) {
                                            (0, M.Z)(this, r);
                                            var t = l.findBy("channelId", e.channelId);
                                            l.removeObject(t)
                                        }.bind(this)), this.send("save", !1)
                                    }
                                    this.loadConversation(t.conversations || []), this.loadConversation(u)
                                } else;
                                n && n.call(this)
                            }.bind(this))
                        }
                    }, {
                        key: "restoreConversation",
                        value: function() {
                            this.populateConversation(q.default.CONVERSATION.FETCH.CONVERSATION_RESTORED, this.openChannel)
                        }
                    }, {
                        key: "gotoFAQArticle",
                        value: function(e, t) {
                            var n, i = null === (n = this.hotline) || void 0 === n ? void 0 : n.ui;
                            Ember.set(i, "modal", e), this.transitionTo(this.faqRouteName, {
                                queryParams: {
                                    fromChannelId: t
                                }
                            })
                        }
                    }, {
                        key: "gotoFAQArticles",
                        value: function(e) {
                            this.transitionTo(this.faqRouteName, {
                                queryParams: {
                                    categoryID: e
                                }
                            })
                        }
                    }, {
                        key: "gotoFAQCategory",
                        value: function() {
                            this.transitionTo(this.faqRouteName)
                        }
                    }, {
                        key: "retryCallbackOnRateLimitedUrl",
                        value: function() {
                            var e, t, n, i, o;
                            if (null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isKbaseCategoryRateLimited) Ember.set(null === (o = this.hotline) || void 0 === o ? void 0 : o.ui, "retryingRateLimitedUrl", !0), this.fetchKbaseCategories();
                            else if (null !== (n = this.hotline) && void 0 !== n && null !== (i = n.ui) && void 0 !== i && i.rateLimitedCategoryArticles) {
                                var r, s, a;
                                Ember.set(null === (r = this.hotline) || void 0 === r ? void 0 : r.ui, "retryingRateLimitedUrl", !0), this.send("gotoFAQArticles", null === (s = this.hotline) || void 0 === s || null === (a = s.ui) || void 0 === a ? void 0 : a.rateLimitedCategoryArticles)
                            }
                        }
                    }]), n
                }(F.default.extend(x.default, V.default, z.default, Q.default, G.default, $.default, X.default, ee.default)), C = (0, L.Z)(E.prototype, "ruleEngine", [i], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), A = (0, L.Z)(E.prototype, "notification", [o], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), I = (0, L.Z)(E.prototype, "messageStacker", [r], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), O = (0, L.Z)(E.prototype, "postMessage", [s], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), T = (0, L.Z)(E.prototype, "user", [a], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), Z = (0, L.Z)(E.prototype, "windowListener", [l], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), (0, L.Z)(E.prototype, "didAuthUserCB", [u], Object.getOwnPropertyDescriptor(E.prototype, "didAuthUserCB"), E.prototype), (0, L.Z)(E.prototype, "faqRouteName", [c], Object.getOwnPropertyDescriptor(E.prototype, "faqRouteName"), E.prototype), (0, L.Z)(E.prototype, "helper", [d], Object.getOwnPropertyDescriptor(E.prototype, "helper"), E.prototype), (0, L.Z)(E.prototype, "onAdvicePullCB", [h], Object.getOwnPropertyDescriptor(E.prototype, "onAdvicePullCB"), E.prototype), (0, L.Z)(E.prototype, "onUserMessageCB", [f], Object.getOwnPropertyDescriptor(E.prototype, "onUserMessageCB"), E.prototype), (0, L.Z)(E.prototype, "onCampaignMessageCB", [p], Object.getOwnPropertyDescriptor(E.prototype, "onCampaignMessageCB"), E.prototype), (0, L.Z)(E.prototype, "sessionUserObserver", [g], Object.getOwnPropertyDescriptor(E.prototype, "sessionUserObserver"), E.prototype), (0, L.Z)(E.prototype, "restoreConversation", [m], Object.getOwnPropertyDescriptor(E.prototype, "restoreConversation"), E.prototype), (0, L.Z)(E.prototype, "gotoFAQArticle", [v], Object.getOwnPropertyDescriptor(E.prototype, "gotoFAQArticle"), E.prototype), (0, L.Z)(E.prototype, "gotoFAQArticles", [y], Object.getOwnPropertyDescriptor(E.prototype, "gotoFAQArticles"), E.prototype), (0, L.Z)(E.prototype, "gotoFAQCategory", [b], Object.getOwnPropertyDescriptor(E.prototype, "gotoFAQCategory"), E.prototype), (0, L.Z)(E.prototype, "retryCallbackOnRateLimitedUrl", [w], Object.getOwnPropertyDescriptor(E.prototype, "retryCallbackOnRateLimitedUrl"), E.prototype), E)
        },
        90603: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = p(n(31052)),
                o = p(n(96389)),
                r = p(n(45697)),
                s = p(n(20830)),
                a = p(n(45370)),
                l = p(n(68689)),
                u = p(n(19136)),
                c = p(n(72754)),
                d = p(n(19591)),
                h = p(n(15366)),
                f = p(n(21581));

            function p(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return o.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return r.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/template", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/component", (function() {
                return l.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/template", (function() {
                return c.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/component", (function() {
                return d.default
            })), window.define("hotline-web/helpers/format-time", (function() {
                return h.default
            })), window.define("hotline-web/helpers/gt", (function() {
                return f.default
            }));
            var g = (0, Ember.HTMLBars.template)({
                id: "AIHYZ0k4",
                block: '[[[8,[39,0],[[24,0,"channel-link"]],[["@route","@model","@replace"],["home.channel",[30,0,["channel","channelId"]],true]],[["default"],[[[[1,"\\n  "],[10,0],[14,0,"h-category-item"],[12],[1,"\\n    "],[10,0],[14,0,"h-category-icon"],[12],[1,"\\n"],[41,[30,0,["channel","iconUrl"]],[[[1,"        "],[10,"img"],[14,0,"img-circle avatar-image"],[15,"src",[30,0,["channel","iconUrl"]]],[15,"alt",[28,[37,2],["alt.channel_icon"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"        "],[10,1],[15,0,[29,["category-content-wrap ",[28,[37,3],[[30,0,["channel","name"]]],null]]]],[12],[1,"\\n          "],[10,1],[14,0,"category-content"],[12],[1,"\\n            "],[1,[28,[35,4],[[30,0,["channel","name"]]],null]],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]]],[1,"    "],[13],[1,"\\n    "],[10,0],[14,0,"channel-names"],[12],[1,"\\n      "],[10,0],[14,0,"channel-content"],[12],[1,"\\n        "],[10,0],[15,0,[29,["h-category-detail ",[52,[30,0,["lastMessage"]],"aw"]]]],[12],[1,"\\n          "],[10,"h2"],[14,0,"channel-name"],[12],[1,"\\n            "],[1,[28,[35,5],[[30,0,["channel","name"]],"strict"],null]],[1,"\\n          "],[13],[1,"\\n          "],[10,0],[15,0,[29,["welcome-text ",[52,[30,0,["unreadCount"]],"unreadMessage"]]]],[12],[1,"\\n"],[41,[30,0,["enabledAgentTypingIndicator"]],[[[1,"              "],[8,[39,6],null,[["@channelId"],[[30,0,["channel","channelId"]]]],null],[1,"\\n"]],[]],null],[1,"            "],[10,0],[14,0,"message-text"],[12],[1,"\\n"],[41,[30,0,["isNonWelcomeMessage"]],[[[41,[28,[37,7],[[30,0,["USER"]],[30,0,["lastMessage","messageUserType"]]],null],[[[1,"                  "],[10,"i"],[14,0,"icon-ic_reply"],[12],[13],[1,"\\n"]],[]],null],[1,"                "],[10,0],[14,0,"last-msg-preview"],[12],[1,"\\n                  "],[8,[39,8],null,[["@message","@isListView"],[[30,0,["lastMessage"]],true]],null],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[41,[30,0,["channel","welcomeMessage","messageFragments","length"]],[[[1,"                "],[10,0],[14,0,"last-msg-preview"],[12],[1,"\\n                  "],[8,[39,8],null,[["@message","@isListView"],[[30,0,["channel","welcomeMessage"]],true]],null],[1,"\\n                "],[13],[1,"\\n              "]],[]],null]],[]]],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,0],[14,0,"h-conv-user"],[12],[1,"\\n"],[41,[30,0,["lastMessage"]],[[[1,"            "],[10,0],[14,0,"time-stamp"],[12],[1,"\\n              "],[1,[28,[35,9],[[30,0,["lastMessage","createdMillis"]],"LT"],null]],[1,"\\n            "],[13],[1,"\\n"],[41,[30,0,["unreadCount"]],[[[1,"              "],[10,0],[15,0,[29,["h-notify ",[52,[28,[37,10],[[30,0,["unreadCount"]],9],null],"large-count"]]]],[15,"aria-label",[30,0,["getAriaLabel"]]],[12],[1,"\\n                "],[10,1],[14,"aria-hidden","true"],[12],[1,"\\n"],[41,[28,[37,10],[[30,0,["unreadCount"]],9],null],[[[1,"                    "],[1,[28,[35,2],["common.numbers.nine"],null]],[1,"+\\n"]],[]],[[[1,"                    "],[1,[30,0,["unreadCount"]]],[1,"\\n"]],[]]],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],null]],[]],null],[1,"        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n\\n  "],[13],[1,"\\n"]],[]]]]]],[],false,["link-to","if","t","choose-theme","avatar-content","sanitize-html","ui-agent-typing-indicator","eq","ui-unity-message-fragment","format-time","gt"]]',
                moduleName: "hotline-web/components/app-channel/template.hbs",
                isStrictMode: !1
            });
            t.default = g
        },
        73278: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(90603)),
                o = r(n(33470));

            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/app-channel/template", (function() {
                return i.default
            })), window.define("hotline-web/components/app-channel/component", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "tWNiBpkU",
                block: '[[[10,0],[14,0,"channel-section animated fadeInUp delay faster h-categories"],[12],[1,"\\n  "],[10,0],[14,0,"channel-title"],[12],[1,"\\n    "],[10,0],[14,0,"list-sub-title"],[14,"role","heading"],[14,"aria-level","1"],[12],[1,"\\n      "],[1,[30,0,["headerTitle"]]],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n  "],[10,"ul"],[14,0,"channel-list"],[12],[1,"\\n"],[42,[28,[37,1],[[28,[37,1],[[30,0,["displayChannels"]]],null]],null],null,[[[1,"      "],[10,"li"],[12],[1,"\\n        "],[8,[39,2],null,[["@channel","@update"],[[30,1],[30,0,["session","didMessage"]]]],null],[1,"\\n        "],[10,0],[14,0,"border-bottom"],[12],[13],[1,"\\n      "],[13],[1,"\\n"]],[1]],null],[1,"  "],[13],[1,"\\n"],[13]],["channel"],false,["each","-track-array","app-channel"]]',
                moduleName: "hotline-web/components/app-channels-list/template.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        914: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(20830)),
                o = l(n(31052)),
                r = l(n(96389)),
                s = l(n(45697)),
                a = l(n(19136));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/sanitize-html", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return r.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return s.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return a.default
            }));
            var u = (0, Ember.HTMLBars.template)({
                id: "KBP4qYPf",
                block: '[[[41,[30,0,["isCategoriesPresent"]],[[[1,"  "],[10,0],[15,0,[29,["faq-list animated fadeInUp delay faster ",[52,[30,0,["isShowMoreCategories"]],"show-more"]]]],[12],[1,"\\n    "],[10,0],[14,0,"faq-header"],[12],[1,"\\n      "],[10,0],[14,0,"title-header"],[12],[1,"\\n        "],[10,0],[14,0,"list-sub-title"],[14,"role","heading"],[14,"aria-level","1"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","faq"]],[[[1,"            "],[1,[28,[35,1],[[30,0,["session","config","content","headers","faq"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"            "],[1,[28,[35,2],["faqs.faq_title"],null]],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n      "],[13],[1,"\\n      "],[11,0],[24,0,"search-category"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,2],["aria_labels.search_faq"],null]],[4,[38,3],[[30,0],"goToCategory"],null],[12],[1,"\\n        "],[10,"i"],[14,0,"icon-ic_search"],[12],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n    "],[10,0],[14,0,"faq-categories"],[12],[1,"\\n      "],[10,"ul"],[14,0,"categories-list"],[12],[1,"\\n"],[42,[28,[37,5],[[28,[37,5],[[30,0,["sliceCategories"]]],null]],null],null,[[[1,"          "],[11,"li"],[24,"tabindex","0"],[4,[38,3],[[30,0],"selectCategory",[30,1]],null],[12],[1,"\\n            "],[10,0],[14,0,"category-item"],[12],[1,"\\n              "],[10,0],[14,0,"category-icon"],[12],[1,"\\n"],[41,[30,1,["icon"]],[[[1,"                  "],[10,"img"],[15,"src",[30,1,["icon"]]],[14,0,"img-circle avatar-image"],[15,"alt",[28,[37,2],["alt.category_icon"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"                  "],[10,1],[15,0,[29,["category-content-wrap ",[28,[37,6],[[30,1,["title"]]],null]]]],[12],[1,"\\n                    "],[1,[28,[35,7],[[30,1,["title"]]],null]],[1,"\\n                  "],[13],[1,"\\n"]],[]]],[1,"              "],[13],[1,"\\n              "],[10,0],[14,0,"category-name"],[12],[1,"\\n                "],[10,0],[14,0,"faq-title"],[14,"role","heading"],[14,"aria-level","2"],[12],[1,"\\n                  "],[1,[28,[35,1],[[30,1,["title"]],"strict"],null]],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n\\n"],[41,[28,[37,8],[[30,0,["hotline","ui","lastSelectedCategoryId"]],[30,1,["categoryId"]]],null],[[[1,"                "],[10,"img"],[14,0,"faq-loader"],[15,"src",[30,0,["images","UploadingNew"]]],[15,"alt",[28,[37,2],["alt.loading_icon"],null]],[12],[13],[1,"\\n"]],[]],null],[1,"            "],[13],[1,"\\n            "],[10,0],[14,0,"border-bottom"],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[1,2]],null],[1,"      "],[13],[1,"\\n"],[41,[30,0,["isShowMoreCategories"]],[[[1,"        "],[11,0],[24,0,"see_more_faqs"],[24,"role","button"],[24,"tabindex","0"],[4,[38,3],[[30,0],"goToCategory"],null],[12],[1,"\\n          "],[1,[28,[35,2],["faqs.show_more_categories"],null]],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],["obj","index"],false,["if","sanitize-html","t","action","each","-track-array","choose-theme","avatar-content","eq"]]',
                moduleName: "hotline-web/components/app-faq-list/template.hbs",
                isStrictMode: !1
            });
            t.default = u
        },
        52669: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = h(n(31052)),
                o = h(n(73278)),
                r = h(n(82169)),
                s = h(n(914)),
                a = h(n(5420)),
                l = h(n(53957)),
                u = h(n(86292)),
                c = h(n(87917)),
                d = h(n(24175));

            function h(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/app-channels-list/template", (function() {
                return o.default
            })), window.define("hotline-web/components/app-channels-list/component", (function() {
                return r.default
            })), window.define("hotline-web/components/app-faq-list/template", (function() {
                return s.default
            })), window.define("hotline-web/components/app-faq-list/component", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-rate-limit-error/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-rate-limit-error/component", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-footer-note/template", (function() {
                return c.default
            })), window.define("hotline-web/components/ui-footer-note/component", (function() {
                return d.default
            }));
            var f = (0, Ember.HTMLBars.template)({
                id: "PUTrQ6uZ",
                block: '[[[10,0],[14,0,"home-content"],[12],[1,"\\n  "],[10,0],[14,0,"h-header"],[12],[1,"\\n    "],[10,0],[15,0,[29,["title fadeIn ",[52,[30,0,["isRoutedFromFAQ"]],"home-header"]," ",[30,0,["hotline","ui","config","headerProperty","headerStyle"]]]]],[12],[1,"\\n      "],[10,0],[14,0,"logo"],[12],[1,"\\n"],[41,[30,0,["hotline","ui","config","widgetLogoUrl"]],[[[1,"          "],[10,"img"],[15,0,[52,[30,0,["isRoutedFromFAQ"]],"home-logo","animated zoomIn faster"]],[15,"src",[30,0,["hotline","ui","config","widgetLogoUrl"]]],[15,"alt",[28,[37,1],["alt.logo"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"          "],[10,"img"],[15,0,[52,[30,0,["isRoutedFromFAQ"]],"home-logo","animated zoomIn faster"]],[15,"src",[30,0,["images","HomeIcon"]]],[15,"alt",[28,[37,1],["alt.product_name"],null]],[12],[13],[1,"\\n"]],[]]],[1,"      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n  "],[10,0],[15,0,[29,["body sections faq-body ",[52,[30,0,["hidePoweredBy"]],"no-footer"]]]],[12],[1,"\\n"],[1,"    "],[10,0],[15,0,[29,["dummy-bar ",[30,0,["hotline","ui","config","headerProperty","headerStyle"]]," ",[52,[30,0,["isRoutedFromFAQ"]],"dummyBar"]]]],[12],[13],[1,"\\n    "],[10,0],[14,0,"card-layout scroll-section"],[12],[1,"\\n"],[1,"      "],[8,[39,2],null,null,null],[1,"\\n"],[41,[30,0,["isFAQAvailable"]],[[[1,"        "],[8,[39,3],null,null,null],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["isRateLimited"]],[[[1,"        "],[8,[39,4],null,[["@retryAfter","@retryCallback","@isRateLimitExceededOnScroll","@retryingRateLimitedUrl"],[[30,0,["retryRateLimitedUrlIn"]],[28,[37,5],[[30,0],"retryCallbackOnRateLimit"],null],"true",[30,0,["hotline","ui","retryingRateLimitedUrl"]]]],null],[1,"\\n"]],[]],null],[1,"\\n      "],[10,0],[14,0,"bottom-gradient"],[12],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"],[13],[1,"\\n"],[41,[51,[30,0,["hidePoweredBy"]]],[[[1,"  "],[8,[39,7],null,[["@hidePoweredBy"],[[30,0,["hidePoweredBy"]]]],null],[1,"\\n"]],[]],null]],[],false,["if","t","app-channels-list","app-faq-list","ui-rate-limit-error","action","unless","ui-footer-note"]]',
                moduleName: "hotline-web/components/app-home/template.hbs",
                isStrictMode: !1
            });
            t.default = f
        },
        45370: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, o = (i = n(31052)) && i.__esModule ? i : {
                default: i
            };
            window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "S7WUDywq",
                block: '[[[11,0],[16,0,[29,["ui-agent-typing-indicator ",[52,[51,[30,0,["isAgentTyping"]]],"hidden"]]]],[16,"aria-label",[28,[37,1],["aria_labels.agent_typing"],null]],[17,1],[12],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n"],[13],[1,"\\n"]],["&attrs"],false,["unless","t"]]',
                moduleName: "hotline-web/components/ui-agent-typing-indicator/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        87917: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, o = (i = n(31052)) && i.__esModule ? i : {
                default: i
            };
            window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "g4hHCMZj",
                block: '[[[11,0],[16,0,[29,["footer-note animated slideInUp faster ",[52,[30,1],"hide-footer"]]]],[17,2],[12],[1,"\\n"],[41,[51,[30,1]],[[[1,"    "],[1,[28,[35,2],["by_in_powered_by"],null]],[1,"  "],[10,"img"],[14,0,"icon"],[15,"src",[30,0,["images","Logo"]]],[15,"alt",[28,[37,2],["alt.powered_by"],null]],[12],[13],[1,"  \\n"],[1,"    "],[10,3],[14,6,"https://www.freshworks.com/live-chat-software/powered-by-freshchat/"],[14,0,"product"],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n      "],[1,[28,[35,2],["freshchat"],null]],[1,"\\n    "],[13],[1,"\\n"]],[]],[[[1,"    "],[10,"img"],[14,"src","data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="],[14,"width","0"],[14,"height","0"],[15,"alt",[28,[37,2],["alt.product_name"],null]],[12],[13],[1,"\\n"]],[]]],[13],[1,"\\n"]],["@hidePoweredBy","&attrs"],false,["if","unless","t"]]',
                moduleName: "hotline-web/components/ui-footer-note/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        87986: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "Y+fKQKsX",
                block: '[[[46,[28,[37,1],null,null],null,null,null]],[],false,["component","-outlet"]]',
                moduleName: "hotline-web/templates/home.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        50122: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(52669)),
                o = r(n(56183));

            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/app-home/template", (function() {
                return i.default
            })), window.define("hotline-web/components/app-home/component", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "ItfW6C1z",
                block: '[[[8,[39,0],null,[["@model"],[[30,0,["model"]]]],null]],[],false,["app-home"]]',
                moduleName: "hotline-web/templates/home/index.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        4754: function(e, t, n) {
            "use strict";
            t.Z = n.p + "uploading_new.98b10ec655025f35a4f07a99ec6e6de9.gif"
        }
    }
]);