<html>

<head>
  <title>Fixed Float - <?php echo $__env->yieldContent('title'); ?></title>
  <?php $__env->startSection('meta'); ?>
  <meta charset="UTF-8" />
  <meta name="_token" value="<?php echo e(csrf_token()); ?>">

  <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" />
  <link rel="preload" href="<?php echo e(asset('assets/fonts/icons/icons.woff2')); ?>" as="font" type="font/woff2" crossorigin />
  <link rel="preload" href="<?php echo e(asset('assets/fonts/opensans/regular/opensans-regular-latin.woff2')); ?>" as="font" type="font/woff2" crossorigin />
  <link rel="preload" href="<?php echo e(asset('assets/fonts/opensans/semibold/opensans-semibold-latin.woff2')); ?>" as="font" type="font/woff2" crossorigin />
  <link rel="preload" href="<?php echo e(asset('assets/fonts/opensans/light/opensans-light-latin.woff2')); ?>" as="font" type="font/woff2" crossorigin />
  <link rel="preload" href="<?php echo e(asset('assets/fonts/opensans/bold/opensans-bold-latin.woff2')); ?>" as="font" type="font/woff2" crossorigin />
  <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('assets/images/apple-touch-icon-57x57.png')); ?>" />
  <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('assets/images/apple-touch-icon-60x60.png')); ?>" />
  <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('assets/images/apple-touch-icon-72x72.png')); ?>" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('assets/images/apple-touch-icon-76x76.png')); ?>" />
  <link rel="apple-touch-icon" sizes="117x117" href="<?php echo e(asset('assets/images/apple-touch-icon-117x117.png')); ?>" />
  <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('assets/images/apple-touch-icon-120x120.png')); ?>" />
  <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('assets/images/apple-touch-icon-144x144.png')); ?>" />
  <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('assets/images/apple-touch-icon-152x152.png')); ?>" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/images/apple-touch-icon-180x180.png')); ?>" />


  <link rel="preload" as="style" href="<?php echo e(asset('assets/css/svg_min.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/svg_min.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/min.css')); ?>" />


  <script type="text/javascript" src="<?php echo e(asset('assets/js/polyfill.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/matter.min.js')); ?>" defer></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/squaregame.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/moment.min.js')); ?>" defer></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/jsqr.js')); ?>" defer></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/webln.min.js')); ?>" defer></script>
  
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag("js", new Date());
    gtag("config", "UA-125458753-1");

  </script>
  <script id="freshchat-js-sdk" async src="<?php echo e(asset('assets/js/widget.js')); ?>"></script>

  <?php echo $__env->yieldSection(); ?>
</head>

<body>
  <?php echo $__env->yieldContent('content'); ?>

  <?php $__env->startSection('script'); ?>

  <?php echo $__env->yieldSection(); ?>
</body>

</html>
<?php /**PATH D:\KYD\Clone-FixedFloat\v2\resources\views/layouts/default.blade.php ENDPATH**/ ?>