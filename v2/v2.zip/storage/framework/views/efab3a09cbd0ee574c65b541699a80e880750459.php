<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>

  <div class="visible-print text-center">
    <h1> Laravel QR Cod<img src="https://chart.googleapis.com/chart?chs=222x222&amp;cht=qr&amp;chl=Hello%20world&amp;choe=UTF-8" alt="QR code">e Generator Example </h1>

    
  </div>

</body>
</html>
<?php /**PATH D:\KYD\Clone-FixedFloat\v2\resources\views/qr-code.blade.php ENDPATH**/ ?>